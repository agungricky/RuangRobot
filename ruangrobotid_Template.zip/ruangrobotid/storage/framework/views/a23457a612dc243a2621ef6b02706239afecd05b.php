<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo $__env->yieldContent('title'); ?> &mdash; RUANG ROBOT</title>

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="" />
  
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/fontawesome/css/all.min.css')); ?>">
  

  
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.dataTables.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
  
  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
  <?php echo $__env->yieldPushContent('styles'); ?>

  
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
  <div id="app">
    <div class="main-wrapper">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
          </ul>
        </form>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
            <img style="width: 30px;height: 30px;object-fit: cover;" alt="image" src="<?php echo e(Auth::user()->profile_pict ? url('profile_pict/'.Auth::user()->profile_pict) : url('assets/img/avatar/avatar-1.png')); ?>" class="rounded-circle mr-1">
            <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(Auth::user()->nama_siswa); ?></div></a>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="<?php echo e(route('siswa.profil')); ?>" class="dropdown-item has-icon">
                  <i class="fas fa-cog"></i> Edit Profil
                </a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(route('siswa.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item has-icon text-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
              <form id="logout-form" action="<?php echo e(route('siswa.logout')); ?>" method="GET" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            </div>
          </li>
        </ul>
      </nav>
      <!-- Sidebar outter -->
    <div class="main-sidebar"> 
        <!-- sidebar wrapper -->
        <aside id="sidebar-wrapper">
        <!-- sidebar brand -->
        <div class="sidebar-brand">
            <a href=""><img src="<?php echo e(asset('images/ruangrobot.png')); ?>" alt="" width="120px"></a>
        </div>
        <!-- sidebar menu -->
        <ul class="sidebar-menu">
            <!-- menu header -->
            <li class="menu-header">Dashboard</li>
            <!-- menu item -->
            <li>
            <a href="<?php echo e(route('siswa.dashboard')); ?>"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <!-- menu header -->
            <li class="menu-header">Kelas</li>
            <!-- menu item -->
            <li>
              <a href="<?php echo e(route('siswa.daftarkelas')); ?>"><i class="fas fa-book-open"></i><span>Kelas Saya</span></a>
          </li>
          <li>
              <a href="<?php echo e(route('siswa.jadwal')); ?>"><i class="fas fa-calendar-alt"></i><span>Jadwal Kelas</span></a>
          </li>
            <!-- menu header -->
            <li class="menu-header">Pembayaran</li>
            <li>
                <a href="<?php echo e(route('siswa.pembayaran')); ?>"><i class="fas fa-money-bill-alt"></i><span>Pembayaran</span><div class="badge badge-pill badge-warning text-dark"><?php echo e(Ceksiswa::cek_pembayaran_siswa()); ?></div></a>
            </li>
            <!-- menu header -->
            <li class="menu-header">Sertifikat</li>
            <li>
                <a href="<?php echo e(route('siswa.sertifikat')); ?>"><i class="fas fa-certificate"></i><span>Sertifikat Saya</span></a>
            </li>
        </ul>
        </aside>
    </div>

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
          </div>

          <div class="section-body">
              <?php echo $__env->yieldContent('content'); ?>
          </div>
        </section>
        <?php echo $__env->yieldContent('modal'); ?>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> RUANG ROBOT
        </div>
      </footer>
    </div>
  </div>
  
   <!-- General JS Scripts -->
   <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
   <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
   <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
   <script src="<?php echo e(asset('assets/js/jquery.nicescroll.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/sweetalert2.js')); ?>"></script>

   <!-- JS Libraies -->

   <!-- Template JS File -->
   <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

   
   <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

   <!-- Page Specific JS File -->
   <?php echo $__env->yieldPushContent('scripts'); ?>
 </body>
 </html>
<?php /**PATH /home/ruangro2/public_html/base_file/resources/views/siswa/template/mainsiswa.blade.php ENDPATH**/ ?>
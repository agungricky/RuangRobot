<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Detail Profil</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="" />

    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/fontawesome/css/all.min.css')); ?>">
    

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <div class="bg-white text-dark">
        <div class="container">
            <img src="<?php echo e(asset('images/ruangrobot.png')); ?>" alt="" style="padding: 20px 0px;width: 150px;">
        </div>
    </div>
    <div class="container mt-5">
        <a class="btn btn-primary bnt-lg mb-3" href="<?php echo e(url()->previous()); ?>" onclick=""><i
                class="fas fa-arrow-left"></i> Kembali</a>

        <?php if($users == 'siswa'): ?>
            <div class="row">
                <div class="col-md-7">
                    <div class="card author-box card-primary">
                        <div class="card-body">
                            <h5 class="text-dark text-center mt-1">PROFIL SISWA</h5>
                            <hr>
                            <div class="author-box-left">
                                <img style="width: 100px;height: 100px;object-fit: cover;" alt="image"
                                    src="<?php echo e($siswa->profile_pict ? url('profile_pict/' . $siswa->profile_pict) : url('assets/img/avatar/avatar-1.png')); ?>"
                                    class="rounded-circle author-box-picture">
                                <div class="clearfix"></div>
                            </div>
                            <div class="author-box-details">
                                <div class="author-box-name">
                                    <a href="#"><?php echo e(ucwords($siswa->nama_siswa)); ?></a>
                                </div>
                                <div class="author-box-job mt-3"><i class="fas fa-user"></i> Siswa</div>
                                <div class="author-box-job mt-3"><i class="fas fa-birthday-cake"></i> <?php
                                    $lahir = new DateTime($siswa->tgl_lahir);
                                    $today = new DateTime();
                                    $umur = $today->diff($lahir);
                                    echo $umur->y;
                                    echo ' Tahun';
                                ?>
                                </div>
                                
                                <div class="author-box-job mt-3 mb-5"><i class="fas fa-address-card"></i>
                                    <?php echo e($siswa->bio); ?></div>
                                <h4 class="mb-3">LEVEL : <?php echo e(floor($kelas->count() <= 1 ? 1 : $kelas->count() / 2)); ?>

                                </h4>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">
                                        <?php echo e($kelas->count()); ?></div>
                                    <div class="font-weight-bold mb-1">EXP</div>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar"
                                            data-width="<?php echo e($kelas->count()); ?>%" aria-valuenow="<?php echo e($kelas->count()); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($kelas->count()); ?>%;"><?php echo e($kelas->count()); ?></div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
                                    <div class="font-weight-bold mb-1">MEKANIK</div>
                                    <div class="progress">
                                        <div class="progress-bar bg-success text-dark" role="progressbar"
                                            data-width="<?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>%"
                                            aria-valuenow="<?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>%;">
                                            <?php echo e($mekanik); ?></div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
                                    <div class="font-weight-bold mb-1">ELEKTRONIK</div>
                                    <div class="progress">
                                        <div class="progress-bar bg-warning text-dark" role="progressbar"
                                            data-width="<?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>%"
                                            aria-valuenow="<?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>%;">
                                            <?php echo e($elektronik); ?></div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
                                    <div class="font-weight-bold mb-1">PEMROGRAMAN</div>
                                    <div class="progress">
                                        <div class="progress-bar bg-danger text-dark" role="progressbar"
                                            data-width="<?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>%"
                                            aria-valuenow="<?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>%;">
                                            <?php echo e($pemrograman); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="card card-success">
                        <div class="card-header">
                            <h4 class="card-title">Kelas yang telah diikuti</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled list-unstyled-border">
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media">
                                        <div class="media-body">
                                            <div class="mt-0 mb-1 font-weight-bold"><?php echo e($item->nama_kelas); ?></div>
                                            <div class="text-success text-small font-600-bold">
                                                <?php if(Ceksiswa::get_grade($id, $item->id) == 'A'): ?>
                                                    <i class="fas fa-star"></i> Sangat Baik
                                                <?php else: ?>
                                                    <i class="fas fa-star"></i> Baik
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-7">
                    <div class="card author-box card-primary">
                        <div class="card-body">
                            <h5 class="text-dark text-center mt-2">PROFIL PENGAJAR</h5>
                            <hr>
                            <div class="author-box-left">
                                <img style="width: 100px;height: 100px;object-fit: cover;" alt="image"
                                    src="<?php echo e($pengajar->profile_pict ? url('profile_pict/' . $pengajar->profile_pict) : url('assets/img/avatar/avatar-1.png')); ?>"
                                    class="rounded-circle author-box-picture">
                                <div class="clearfix"></div>
                            </div>
                            <div class="author-box-details">
                                <div class="author-box-name">
                                    <a href="#"><?php echo e(ucwords($pengajar->nama_pengajar)); ?></a>
                                </div>
                                <div class="author-box-job mt-3"><i class="fas fa-user"></i> Pengajar</div>
                                <div class="author-box-job mt-3"><i class="fas fa-map-marker"></i>
                                    <?php echo e(ucwords($pengajar->alamat)); ?></div>
                                <div class="author-box-job mt-3"><i class="fas fa-phone"></i> <?php echo e($pengajar->notlep); ?>

                                </div>
                                <div class="author-box-job mt-3 mb-3"><i class="fas fa-address-card"></i>
                                    <?php echo e($pengajar->bio); ?></div>
                                <h4 class="mb-3">LEVEL : <?php echo e(floor($kelas->count() <= 1 ? 1 : $kelas->count() / 2)); ?>

                                </h4>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">
                                        <?php echo e($kelas->count()); ?></div>
                                    <div class="font-weight-bold mb-1">EXP</div>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar"
                                            data-width="<?php echo e($kelas->count()); ?>%"
                                            aria-valuenow="<?php echo e($kelas->count()); ?>" aria-valuemin="0"
                                            aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($kelas->count()); ?>%;"><?php echo e($kelas->count()); ?></div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
                                    <div class="font-weight-bold mb-1">MEKANIK</div>
                                    <div class="progress">
                                        <div class="progress-bar bg-success text-dark" role="progressbar"
                                            data-width="<?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>%"
                                            aria-valuenow="<?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>%;">
                                            <?php echo e($mekanik); ?></div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
                                    <div class="font-weight-bold mb-1">ELEKTRONIK</div>
                                    <div class="progress">
                                        <div class="progress-bar bg-warning text-dark" role="progressbar"
                                            data-width="<?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>%"
                                            aria-valuenow="<?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>%;">
                                            <?php echo e($elektronik); ?></div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
                                    <div class="font-weight-bold mb-1">PEMROGRAMAN</div>
                                    <div class="progress">
                                        <div class="progress-bar bg-danger text-dark" role="progressbar"
                                            data-width="<?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>%"
                                            aria-valuenow="<?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>"
                                            style="width: <?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>%;">
                                            <?php echo e($pemrograman); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="card card-success">
                        <div class="card-header">
                            <h4 class="card-title">Kelas yang diajar</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled list-unstyled-border">
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media">
                                        <div class="media-body">
                                            <div class="mt-0 mb-1 font-weight-bold"><?php echo e($item->nama_kelas); ?></div>
                                            <div class="text-success text-small font-600-bold">
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('assets/js/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert2.js')); ?>"></script>

    <!-- JS Libraies -->

    <!-- Template JS File -->
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/athoul/Web/ruangrobot/resources/views/profile.blade.php ENDPATH**/ ?>
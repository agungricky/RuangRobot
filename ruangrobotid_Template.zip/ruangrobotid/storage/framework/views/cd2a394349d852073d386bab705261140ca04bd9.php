<?php $__env->startSection('title','Pembayaran'); ?>
<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="card">
            <div class="card-body">
              <div class="table-responsive">
                <style>
                  .asd{
                    word-wrap: break-word !important;white-space: normal !important;width: 250px;
                  }
                </style>
                <table class="table table-striped table-hover asd" id="tabelData">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th class="asd">Nama Kelas</th>
                      <th>Nama Siswa</th>
                      <th>Pembayaran</th>
                      <th>Status Lunas</th>
                      <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody></tbody>
              </table>
              </div>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(function () {
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
      });

      var table = $('#tabelData').DataTable({
        processing: true,
          serverSide: true,
          paging:   true,
          ordering: true,
          searching: true,
          ajax: "<?php echo e(route('admin.pembayaran')); ?>",
          columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                {data: 'nama_kelas', name: 'nama_kelas'},
                {data: 'nama_siswa', name: 'nama_siswa'},
                {data: 'pembayaran', name: 'pembayaran'},
                {data: 'lunas', name: 'lunas'},
                // {data: 'gajipeg', name: 'gajipeg',render: $.fn.dataTable.render.number('.', '.', 0, '')},
                {data: 'action', name: 'action', orderable: false, searchable: false},
          ]
      });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/athoul/ruangrobot/resources/views/admin/pembayaran.blade.php ENDPATH**/ ?>
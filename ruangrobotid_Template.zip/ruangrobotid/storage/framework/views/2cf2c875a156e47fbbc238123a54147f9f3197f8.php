<?php $__env->startSection('title', 'Edit Profil'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-sm-4">
        <div class="col-12 col-md-12 col-lg-7">
            <div class="card">
                <form method="post" class="needs-validation" novalidate="" method="post"
                    action="<?php echo e(route('admin.editprofilsave')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-header">
                        <h4>Edit Profile</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12 col-12">
                                <label>Nama</label>
                                <input type="text" class="form-control" name="nama" value="<?php echo e(Auth::user()->nama); ?>"
                                    required="">
                                <div class="invalid-feedback">
                                    Please fill in the first name
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12 col-12">
                                <label>Username</label>
                                <input type="text" class="form-control" name="username"
                                    value="<?php echo e(Auth::user()->username); ?>" required="">
                                <div class="invalid-feedback">
                                    Please fill in the username
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12 col-12">
                                <label>Password (kosongkan jika tidak ingin merubah password)</label>
                                <input type="password" class="form-control" name="password">
                                <div class="invalid-feedback">
                                    Please fill in the username
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php if(\Session::has('success')): ?>
        <script>
            $(function() {
                swal.fire({
                    icon: 'success',
                    title: "Berhasil Update Profil",
                    timer: 1000,
                    showConfirmButton: false
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/ruangrobot/resources/views/admin/editprofil.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Feedback Siswa'); ?>
<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="card">
            <div class="card-body">
              <div class="table-responsive">
                <style>
                  .asd{
                    word-wrap: break-word !important;white-space: normal !important;width: 250px;
                  }
                </style>
                <table class="table table-striped table-hover asd" id="tabelData">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Nama Siswa</th>
                      <th>Nama Kelas</th>
                      <th>Stars</th>
                      <th>Feedback</th>
                      <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody></tbody>
              </table>
              </div>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(function () {
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
      });

      var table = $('#tabelData').DataTable({
        processing: true,
          serverSide: true,
          paging:   true,
          ordering: true,
          searching: true,
          ajax: "<?php echo e(route('admin.feedback')); ?>",
          columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                {data: 'nama_siswa', name: 'nama_siswa'},
                {data: 'nama_kelas', name: 'nama_kelas'},
                {data: 'stars', name: 'stars'},
                {data: 'isi_feedback', name: 'isi_feedback'},
                {data: 'aksi', name: 'aksi'},
                // {data: 'gajipeg', name: 'gajipeg',render: $.fn.dataTable.render.number('.', '.', 0, '')},
                // {data: 'action', name: 'action', orderable: false, searchable: false},
          ]
      });
  });
</script>
    <script>
        $(document).ready(function() {
           $('#tabelData').DataTable();
            $('body').on('click', '.delete', function(e) {
            e.preventDefault();
            swal.fire({
                title: 'Apakah Anda Yakin?',
                icon : 'question',
                showCancelButton: true,
                confirmButtonText: "Ya",
                cancelButtonText: "Batal"
            }).then((result) => {
                if(result.value){
                    var url = $(this).attr('href');
                    window.location.href = url;
                }
            });
        });
        });
    </script>
        <?php if(\Session::has('success')): ?>
        <script>
          $(function(){
            swal.fire({
              icon: 'success',
              title: "Berhasil Menghapus Feedback",
              timer: 1000,
              showConfirmButton: false
            });
          });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/athoul/ruangrobot/resources/views/admin/feedback.blade.php ENDPATH**/ ?>
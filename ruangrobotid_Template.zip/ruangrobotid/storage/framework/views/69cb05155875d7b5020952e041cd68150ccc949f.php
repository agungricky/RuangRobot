<?php $__env->startSection('title', 'Siswa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('admin.siswacreate')); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i>
                        Tambah Siswa</a>
                    <br><br>
                    <div class="table-responsive">
                        <style>
                            .asdd td,
                            .asdd th {
                                font-size: 13px;
                            }
                        </style>
                        <table class="table table-striped asdd" id="tabelData">
                            <thead>
                                <tr>
                                    <th> No. </th>
                                    <th> Nama Siswa </th>
                                    <th>Nomor Telfon</th>
                                    <th> Alamat </th>
                                    <th> Sekolah </th>
                                    <th> Tanggal Lahir </th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th style="width:50px;"> Opsi </th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="inputForm">
                            <input type="hidden" name="id" id="id">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="jadwal">Nama siswa</label>
                                    <input type="text" class="form-control" id="jadwal" placeholder="Nama siswa"
                                        name="jadwal">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-gradient-info" id="saveBtn"><i
                                        class="mdi mdi-file-check btn-icon-append"></i> Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- modal -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#tabelData').DataTable({
                processing: true,
                serverSide: true,
                paging: true,
                ordering: true,
                searching: true,
                ajax: "<?php echo e(route('siswa.index')); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'nama_siswa',
                        name: 'nama_siswa'
                    },
                    {
                        data: 'notlep',
                        name: 'notlep'
                    },
                    {
                        data: 'alamat',
                        name: 'alamat'
                    },
                    {
                        data: 'sekolah',
                        name: 'sekolah'
                    },
                    {
                        data: 'tgl_lahir',
                        name: 'tgl_lahir'
                    },
                    {
                        data: 'username',
                        name: 'username'
                    },
                    {
                        data: 'password_real',
                        name: 'password_real'
                    },

                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

            $('#addData').click(function() {
                $('#id').val('');
                $('#jadwal').val('');
                $('#saveBtn').html('Simpan');
                $('#ajaxModal').trigger('reset');
                $('.modal-title').html('Tambah siswa');
                $('#ajaxModal').modal('show');
            });

            $('#saveBtn').click(function(e) {
                e.preventDefault();
                $(this).html('Menyimpan..');
                $.ajax({
                    data: $('#inputForm').serialize(),
                    url: "<?php echo e(route('siswa.store')); ?>",
                    type: 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#ajaxModal').trigger('reset');
                        $('#ajaxModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil menyimpan',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        table.draw();
                    },
                    error: function(data) {
                        console.log('Error: ', data);
                        $('#saveBtn').html('Simpan');
                    }
                });
            });

            $('body').on('click', '.delete', function() {
                var id = $(this).data('id');

                Swal.fire({
                    title: 'Ingin menghapus data?',
                    text: "Data yang terhapus tidak dapat dikembalikan",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Hapus!'
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            type: 'DELETE',
                            url: "<?php echo e(route('siswa.store')); ?>" + '/' + id,
                            success: function(data) {
                                table.draw();
                            },
                            error: function(data) {
                                console.log('Error: ', data);
                            }
                        });
                        Swal.fire({
                            icon: 'success',
                            title: 'Data telah dihapus',
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                })
            });

            $('body').on('click', '.edit', function() {
                var id = $(this).data('id');
                $.get("<?php echo e(route('siswa.index')); ?>" + '/' + id + '/edit', function(data) {
                    $('#ajaxModal').modal('show');
                    $('.modal-title').html('Edit siswa');
                    $('#id').val(data.id);
                    $('#jadwal').val(data.jadwal);
                    $('#saveBtn').val('edit');
                    $('#saveBtn').html('Simpan');
                })
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/ruangrobotid/resources/views/admin/siswa.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Manage Pengajar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <div class="add-items d-flex">
                        <button class="add btn btn-primary mb-3 font-weight-bold todo-list-add-btn" id="addData"><i class="fas fa-plus"></i> Tambah pengajar</button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped" id="tabelData">
                            <thead>
                            <tr>
                                <th> No. </th>
                                <th> Nama pengajar </th>
                                <th> Nomor Telfon </th>
                                <th> Alamat </th>
                                <th> Username </th>
                                <th> Password </th>
                                <th> Opsi </th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
             <!-- modal -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form id="inputForm">
        <input type="hidden" name="id" id="id">
        <div class="modal-body">
            <div class="form-group">
                <label for="pengajar">Nama pengajar</label>
                <input required type="text" class="form-control" id="nama_pengajar" placeholder="Nama pengajar" name="nama_pengajar">
            </div>
                    <div class="form-group">
                        <label for="pengajar">Alamat</label>
                        <input required type="text" class="form-control" id="alamat" placeholder="Alamat" name="alamat">
                    </div>
                        <div class="form-group">
                            <label for="pengajar">Nomor Telfon</label>
                            <input required type="text" class="form-control" id="notlep" placeholder="Nomor Telfon" name="notlep">
                        </div>
                        <div class="form-group">
                            <label for="pengajar">Username</label>
                            <input required type="text" class="form-control" placeholder="Username" id="username" name="username">
                        </div>
                        <div class="form-group" id="pwhide">
                            <label for="pengajar">Password</label>
                            <input type="text" class="form-control" placeholder="Password" id="password" name="password">
                        </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" id="saveBtn">Simpan</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.min.js"></script>
<script type="text/javascript">
    $(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
      });
      
      var table = $('#tabelData').DataTable({
          processing: true,
          serverSide: true,
          // paging:   false,
          // ordering: false,
          // searching: false,
          ajax: "<?php echo e(route('pengajar.index')); ?>",
          columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                {data: 'nama_pengajar', name: 'nama_pengajar'},
                {data: 'notlep', name: 'notlep'},
                {data: 'alamat', name: 'alamat'},
                {data: 'username', name: 'username'},
                {data: 'real_passwd', name: 'real_passwd'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
          ]
      });

      $('#addData').click(function() {
        $('#pwhide').hide();
          $('#id').val('');
          $('#nama_pengajar').val('');
          $('#alamat').val('');
          $('#notlep').val('');
          $('#username').val('');
          $('#password').hide();
          $('#saveBtn').html('Simpan');
          $('#ajaxModal').trigger('reset');
          $('.modal-title').html('Tambah pengajar');
          $('#ajaxModal').modal('show');
      });

      $('#saveBtn').click(function(e) {
            e.preventDefault();
            let formnya = $('#inputForm').valid();
          if (formnya) {
          $(this).html('Menyimpan..');
          $.ajax({
              data: $('#inputForm').serialize(),
              url: "<?php echo e(route('pengajar.store')); ?>",
              type: 'POST',
              dataType: 'json',
              success: function(data) {
                $('#ajaxModal').trigger('reset');
                $('#ajaxModal').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil menyimpan',
                    showConfirmButton: false,
                    timer: 1500
                });
                table.draw();
              },
              error: function(data) {
                  alert('Username Sudah Ada');
                  $('#saveBtn').html('Simpan');
              }
          });
          }
      });

    $('body').on('click', '.delete', function() {
        var id = $(this).data('id');

        Swal.fire({
        title: 'Ingin menghapus data?',
        text: "Data yang terhapus tidak dapat dikembalikan",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    type: 'DELETE',
                    url: "<?php echo e(route('pengajar.store')); ?>"+'/'+id,
                    success: function(data) {
                        table.draw();
                    },
                    error: function(data) {
                    console.log('Error: ', data);
                    }
                });
                Swal.fire({
                    icon: 'success',
                    title: 'Data telah dihapus',
                    showConfirmButton: false,
                    timer: 1500
                });
            }
        })
      });

    $('body').on('click', '.edit', function() {
        var id = $(this).data('id');
        $('#pwhide').show();
        $.get("<?php echo e(route('pengajar.index')); ?>" +'/' + id +'/edit', function (data) {
            $('#ajaxModal').modal('show');
            $('.modal-title').html('Edit pengajar');
            $("#inputForm").validate().resetForm();
            $('#id').val(data.id);
            $('#nama_pengajar').val(data.nama_pengajar);
            $('#username').val(data.username);
            $('#password').val(data.real_passwd);
            // $('#username').attr('disabled','true');
            // $('#username').removeAttr('required');
            $('#notlep').val(data.notlep);
            $('#alamat').val(data.alamat);
            $('#saveBtn').val('edit');
            $('#saveBtn').html('Simpan');
        })
    });

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/athoul/ruangrobot/resources/views/admin/pengajar.blade.php ENDPATH**/ ?>
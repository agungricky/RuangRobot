<?php $__env->startSection('title', 'Gaji Saya'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Total Gaji</h6>
                    <hr>
                    <h2 class="text-center">Rp <?php echo e(number_format($gajis)); ?></h2>
                </div>
            </div>
        </div>
        <?php $__currentLoopData = $gajisaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gajisayas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card card-success">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($gajisayas->nama_kelas); ?></h6>
                        <hr>
                        <p class="card-description"><i class="fas fa-clipboard-check mr-2"></i>
                            &nbsp;&nbsp;<?php echo e(Ceksiswa::get_hadir($gajisayas->uuid)); ?></p>
                        <p class="card-description"><i class="fas fa-money-bill-alt mr-2"></i> Rp
                            <?php echo e(number_format($gajisayas->gajipeg)); ?> per pertemuan</p>
                        <p class="card-description"><i class="fas fa-check mr-2"></i>
                            <?php if($gajisayas->sudah_digaji == 0): ?>
                                <span class="badge badge-warning">Belum Menerima</span>
                            <?php else: ?>
                                <span class="badge badge-success">Sudah Diterima</span>
                                <a href="<?php echo e(route('pengajar.gajisayacetak', $gajisayas->id)); ?>"
                                    class="btn btn-block btn-primary btn-lg mt-4"><i class="fas fa-print"></i> Unduh
                                    Invoice</a>
                            <?php endif; ?>
                        </p>
                        <hr>
                        <h2 class="text-center">Rp
                            <?php echo e(number_format(Ceksiswa::get_gaji($gajisayas->uuid, $gajisayas->gajipeg))); ?></h2>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengajar.template.mainpengajar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/athoul/Web/ruangrobot/resources/views/pengajar/gajisaya.blade.php ENDPATH**/ ?>
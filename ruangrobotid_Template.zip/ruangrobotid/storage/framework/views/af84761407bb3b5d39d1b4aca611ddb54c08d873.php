<?php $__env->startSection('title', 'Edit Siswa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 grid-margin">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.editsiswaaksi')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                        <div class="form-group">
                            <label>Nama</label>
                            <input name="nama" type="text" class="form-control" placeholder="Nama" aria-label="Nama"
                                value="<?php echo e($siswa->nama_siswa); ?>">
                        </div>
                        <div class="form-group">
                            <label>Sekolah</label>
                            <input name="sekolah" type="text" class="form-control" placeholder="Sekolah"
                                aria-label="Sekolah" value="<?php echo e($siswa->sekolah); ?>">
                        </div>
                        <div class="form-group">
                            <label>Tanggal Lahir</label>
                            <input name="tgl_lahir" type="date" class="form-control" placeholder="Tanggal Lahir"
                                aria-label="Tanggal Lahir" value="<?php echo e($siswa->tgl_lahir); ?>">
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                            <input name="alamat" type="text" class="form-control" placeholder="Tanggal Lahir"
                                aria-label="Tanggal Lahir" value="<?php echo e($siswa->alamat); ?>">
                        </div>
                        <div class="form-group">
                            <label>Nomor Telfon</label>
                            <input name="notlep" type="text" class="form-control" placeholder="Tanggal Lahir"
                                aria-label="Tanggal Lahir" value="<?php echo e($siswa->notlep); ?>">
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input name="username" type="text" class="form-control" placeholder="Username"
                                aria-label="Username" value="<?php echo e($siswa->username); ?>">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input name="password" type="text" class="form-control" placeholder="Password"
                                aria-label="Password" value="<?php echo e($siswa->password_real); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            var max_fields = 1000;
            var wrapper = $(".input_fields_wrap");
            var add_button = $(".add_field_button");

            var x = 1;
            $(add_button).click(function(e) {
                e.preventDefault();
                if (x < max_fields) {
                    x++;
                    $(wrapper).append(
                        '<div class="row mb-3"><div class="col-md-4"><input name="nama[]" type="text" class="form-control" placeholder="Nama"></div><div class="col-md-4"><input name="sekolah[]" type="text" class="form-control" placeholder="Sekolah"></div><div class="col-md-4"><input name="tgllahir[]" type="date" class="form-control" placeholder="Tanggal Lahir"></div><a href="#" class="remove_field  col-md-3"><i class="text-danger mdi mdi-close-circle"></i></a></div>'
                        ); //add input box
                }
            });

            $(wrapper).on("click", ".remove_field", function(e) {
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/ruangrobotid/resources/views/admin/editsiswa.blade.php ENDPATH**/ ?>
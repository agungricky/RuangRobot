<?php $__env->startSection('title', 'Profil Saya'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mt-sm-4">
        <div class="col-12 col-md-12 col-lg-5">
            <div class="card profile-widget">
                <div class="profile-widget-header">
                    <img style="width: 100px;height: 100px;object-fit: cover;" alt="image"
                        src="<?php echo e(Auth::user()->profile_pict ? url('profile_pict/' . Auth::user()->profile_pict) : url('assets/img/avatar/avatar-1.png')); ?>"
                        class="rounded-circle profile-widget-picture">
                    <div class="profile-widget-items">
                        <button class="btn btn-primary btn-sm m-3" data-toggle="modal" data-target="#exampleModal"><i
                                class="fas fa-pencil-alt"></i> Ganti Foto Profil</button>
                    </div>
                </div>
                <div class="profile-widget-description">
                    <div class="profile-widget-name"><?php echo e(ucwords(Auth::user()->nama_siswa)); ?> <div
                            class="text-muted d-inline font-weight-normal">
                            <div class="slash"></div> Siswa
                        </div>
                    </div>
                    <p><i class="fas fa-user-lock"></i> <?php echo e(Auth::user()->username); ?></p>
                    <p><i class="fas fa-map-marker"></i> <?php echo e(Auth::user()->alamat); ?></p>
                    <p><i class="fas fa-birthday-cake"></i> <?php echo e(date('d-m-Y', strtotime(Auth::user()->tgl_lahir))); ?></p>
                    <p><i class="fas fa-phone"></i> <?php echo e(Auth::user()->notlep); ?></p>
                    <p><i class="fas fa-address-card"></i> <?php echo e(Auth::user()->bio); ?></p>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-12 col-lg-7">
            <div class="card">
                <form method="post" class="needs-validation" novalidate="">
                    <?php echo csrf_field(); ?>
                    <div class="card-header">
                        <h4>Edit Profile</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('siswa.profil_save')); ?>" method="post">
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Nama</label>
                                    <input name="nama_siswa" type="text" class="form-control"
                                        value="<?php echo e(Auth::user()->nama_siswa); ?>" required="">
                                    <div class="invalid-feedback">
                                        Please fill in the first name
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Nomor Telfon</label>
                                    <input name="notlep" type="text" class="form-control"
                                        value="<?php echo e(Auth::user()->notlep); ?>" required="">
                                    <div class="invalid-feedback">
                                        Please fill in the first name
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Alamat</label>
                                    <input name="alamat" type="text" class="form-control"
                                        value="<?php echo e(Auth::user()->alamat); ?>" required="">
                                    <div class="invalid-feedback">
                                        Please fill in the first name
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Sekolah</label>
                                    <input name="sekolah" type="text" class="form-control"
                                        value="<?php echo e(Auth::user()->sekolah); ?>" required="">
                                    <div class="invalid-feedback">
                                        Please fill in the first name
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Tanggal Lahir</label>
                                    <input name="tgl_lahir" type="date" class="form-control"
                                        value="<?php echo e(Auth::user()->tgl_lahir); ?>" required="">
                                    <div class="invalid-feedback">
                                        Please fill in the first name
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-12">
                                    <label>Bio</label>
                                    <textarea name="bio" class="form-control summernote-simple" style="height: 200px;"><?php echo e(Auth::user()->bio); ?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Username</label>
                                    <input disabled type="text" class="form-control"
                                        value="<?php echo e(Auth::user()->username); ?>" required="">
                                    <div class="invalid-feedback">
                                        Please fill in the username
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label>Password (kosongkan jika tidak ingin merubah password)</label>
                                    <input name="password" type="password" class="form-control">
                                    <div class="invalid-feedback">
                                        Please fill in the username
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ganti Foto Profil</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('siswa.profil_save_pict')); ?>" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <label class="btn btn-primary">
                            Pilih Gambar... <input type="file" accept="image/*" style="display: none;"
                                name="profil_pict">
                        </label>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php if(\Session::has('success')): ?>
        <script>
            $(function() {
                swal.fire({
                    icon: 'success',
                    title: "Profil Berhasil Diubah",
                    timer: 1000,
                    showConfirmButton: false
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('siswa.template.mainsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/ruangrobot/resources/views/siswa/profil.blade.php ENDPATH**/ ?>
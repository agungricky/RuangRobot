<?php $__env->startSection('title', 'Detail Pembayaran ' . $kelas->nama_kelas . ' - ' . ucwords($siswa->nama_siswa)); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col"><a href="<?php echo e(route('admin.pembayaran')); ?>" class="btn btn-primary mb-3"><i
                    class="fas fa-arrow-left"></i> Kembali</a></div>
    </div>
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Harga Kelas</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e(number_format($kelas->program_belajar->harga)); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Sudah Dibayar</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e(number_format($list_bayar->where('status', 'Pembayaran Diterima')->sum('jumlah'))); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                    <i class="far fa-flag"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Status Lunas</h4>
                    </div>
                    <div class="card-body">
                        <p style="font-size: 14px;font-weight:bold;">
                            <?php echo e($kelas_bayar->sudahbayar == 0 ? 'BELUM LUNAS' : 'SUDAH LUNAS'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Jatuh Tempo</h4>
                    </div>
                    <div class="card-body">
                        <p style="font-size: 14px;font-weight:bold;"><?php echo e(date('d-m-Y', strtotime($slice))); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th style="width:100px;">Pembayaran Ke</th>
                                <th>Waktu Pembayaran</th>
                                <th>Status</th>
                                <th style="width:100px;">Bukti Pembayaran</th>
                                <th>Jumlah</th>
                                <th>Aksi</th>
                            </tr>
                            <?php if($list_bayar->count() == 0): ?>
                                <tr>
                                    <td colspan="5">Belum Ada Pembayaran</td>
                                </tr>
                            <?php else: ?>
                                <?php
                                    $byr = $a = 0;
                                ?>
                                <?php $__currentLoopData = $list_bayar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $a++;
                                    ?>
                                    <tr>
                                        <td><?php echo e($a); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($bayar->tanggal_bayar))); ?></td>
                                        <td>
                                            <?php if($bayar->status == 'Menunggu Konfirmasi'): ?>
                                                <span
                                                    class="text-dark badge badge-warning badge-pill"><?php echo e($bayar->status); ?></span>
                                            <?php elseif($bayar->status == 'Pembayaran Diterima'): ?>
                                                <?php
                                                    $byr += $bayar->jumlah;
                                                ?>
                                                <span class="badge badge-success badge-pill"><?php echo e($bayar->status); ?></span>
                                            <?php elseif($bayar->status == 'Pembayaran Ditolak'): ?>
                                                <span class="badge badge-danger badge-pill"><?php echo e($bayar->status); ?></span>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <center>
                                                <?php if($bayar->manual == 'N'): ?>
                                                    <img style="width: 50px;height:50px;cursor:pointer;border-radius:50%;"
                                                        class="show-bukti"
                                                        data-src="<?php echo e(url('/data_file/' . $bayar->bukti_pembayaran)); ?>"
                                                        style="cursor:pointer"
                                                        src="<?php echo e(url('/data_file/' . $bayar->bukti_pembayaran)); ?>"
                                                        alt="">
                                                <?php else: ?>
                                                    <span class="badge badge-primary">Manual (Admin)</span>
                                                <?php endif; ?>
                                            </center>
                                        </td>
                                        <td>Rp. <?php echo e(number_format($bayar->jumlah)); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('admin.update-pembayaran')); ?>" method="post"
                                                id="pembayaran-update-form<?php echo e($key); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($bayar->id); ?>">
                                                <input type="hidden" name="status" id="statusnya<?php echo e($key); ?>">
                                            </form>
                                            <div class="dropdown">
                                                <a href="#" data-toggle="dropdown" aria-expanded="false"><i
                                                        class="fas fa-ellipsis-h"></i></a>
                                                <div class="dropdown-menu" x-placement="bottom-start"
                                                    style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 20px, 0px);">
                                                    <div class="dropdown-title">Options</div>
                                                    <a onclick="event.preventDefault();document.getElementById('statusnya<?php echo e($key); ?>').value = 'Pembayaran Diterima'; document.getElementById('pembayaran-update-form<?php echo e($key); ?>').submit();"
                                                        href="#" class="dropdown-item has-icon"><i
                                                            class="fas fa-check text-success"></i> Terima</a>
                                                    <a onclick="event.preventDefault();document.getElementById('statusnya<?php echo e($key); ?>').value = 'Pembayaran Ditolak'; document.getElementById('pembayaran-update-form<?php echo e($key); ?>').submit();"
                                                        href="#" class="dropdown-item has-icon"><i
                                                            class="fas fa-times text-danger"></i> Tolak</a>
                                                    <div class="dropdown-divider"></div>
                                                    <a style="cursor: pointer"
                                                        onclick="confirmation('<?php echo e(route('admin.delete-pembayaran', $bayar->id)); ?>')"
                                                        class="dropdown-item has-icon text-danger hapus-record"><i
                                                            class="fas fa-trash-alt"></i> Hapus</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php
                                        if ($byr == 0 || $kelas->program_belajar->harga == 0) {
                                            $total = 0;
                                            $kurang = 0;
                                        } else {
                                            $total = round(($byr / $kelas->program_belajar->harga) * 100);
                                            $kurang = $kelas->program_belajar->harga - $byr;
                                        }
                                        
                                    ?>
                                    <td colspan="4" class="text-right font-weight-bold">Grand Total</td>
                                    <td><b>Rp. <?php echo e(number_format($byr)); ?></b><br>(<?php echo e($total > 100 ? 100 : $total); ?>% dari
                                        Total Yang Harus Dibayarkan)</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-right font-weight-bold">Total Yang Harus Dibayarkan</td>
                                    <td><b>Rp . <?php echo e(number_format($kelas->program_belajar->harga)); ?></b></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-right font-weight-bold text-danger">Kurang</td>
                                    <td class="font-weight-bold text-danger"> Rp .
                                        <?php echo e(number_format($kelas->program_belajar->harga - $byr)); ?></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-right  font-weight-bold">Status Pembayaran</td>
                                    <td>
                                        <?php if($kelas_bayar->sudahbayar == 0): ?>
                                            <span class="badge badge-warning text-dark">Belum Lunas</span>
                                        <?php else: ?>
                                            <span class="badge badge-success">Sudah Lunas</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <br>
                                        <form action="<?php echo e(route('admin.update-lunas')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($kelas_bayar->id); ?>">
                                            <div class="form-group">
                                                <div class="form-check">
                                                    <label class="form-check-label  font-weight-bold">
                                                        <input name="lunas" value="lunas" type="checkbox"
                                                            class="form-check-input"> Tandai Lunas <i
                                                            class="input-helper"></i></label>
                                                </div>
                                                <button class="btn btn-success btn-sm btn-block mt-3">Update</button>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <?php
                    $harga_kurang = $list_bayar->count() == 0 ? number_format($kelas->program_belajar->harga) : number_format($kelas->program_belajar->harga - $byr);
                    $string = 'Assalamualaikum wr wb menginformasikan pembayaran 
'.$kelas->nama_kelas.'

*Nama : '.$siswa->nama_siswa.'*
*Sekolah : '.$siswa->sekolah.'*
*Total : '.number_format(($kelas->program_belajar->harga ?? 0)).'*
*Lunas : '.number_format(($byr ?? 0)).'*
*Kekurangan : '.$harga_kurang.'*

Pembayaran bisa LUNAS atau DIANGSUR. Menerima transfer ke

Mandiri
a/n Julian Sahertian
1710003410076

BRI
a/n Julian Sahertian
796801007806535

Konfirmasi ke nomor 085655770506 apabila transfer
Terimakasih, Hormat Kami Ruang Robot';
                ?>
                
                <div class="card-footer bg-whitesmoke">
                    <a href="<?php echo e(route('admin.pembayaran_cetak', [$id, date('d-m-Y', strtotime($slice))])); ?>"
                        class="btn btn-primary"><i class="fas fa-print"></i> Cetak Invoice</a>
                    <a href="https://wa.me/<?php echo e($siswa->notlep); ?>?text=<?php echo e(urlencode($string)); ?>"
                        class="btn btn-success ml-3"><i class="fab fa-whatsapp"></i> Hubungi Melalui Whatsapp</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Pembayaran Manual</h4>
                </div>
                <div class="card-body">
                    <div class="col-md-4">
                        <form action="<?php echo e(route('admin.pembayaran_manual_admin')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_selected_class" value="<?php echo e($kelas_bayar->id); ?>">
                            <div class="form-group">
                                <label for="jumlah">Nominal (Rp)</label>
                                <input id="jumlah" type="text" class="form-control " name="jumlah"
                                    tabindex="1" value="" required="">
                            </div>
                            <div class="form-group">
                                <label for="jumlah">Tanggal Bayar</label>
                                <input id="tanggal" type="date" class="form-control " name="tanggal_bayar"
                                    tabindex="1" value="<?php echo e(date('Y-m-d')); ?>" required="">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-block"><i class="fas fa-save"></i>
                                    Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Bukti Pembayaran</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img class="img-fluid" id="buktiiii" src="" alt="">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            $('body').on('click', '.show-bukti', function() {
                $('#buktiiii').attr('src', $(this).data('src'));
                $('#ajaxModal').modal('show');
            });
        });

        function confirmation(text) {
            Swal.fire({
                title: 'Yakin Ingin Menghapus?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    location.href = text;
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/ruangrobot/resources/views/admin/pembayaran-detail.blade.php ENDPATH**/ ?>
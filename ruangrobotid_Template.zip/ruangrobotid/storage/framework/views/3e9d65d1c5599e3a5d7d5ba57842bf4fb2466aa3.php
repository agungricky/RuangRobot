<?php $__env->startSection('title','Detail Kelas - '.$kelas->nama_kelas); ?>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('siswa.daftarkelas')); ?>" class="btn btn-primary btn-lg mb-4"><i class="fa fa-arrow-left"></i> Kembali</a>
<div class="row">
  <div class="col">
    <div class="hero text-white hero-bg-image" style="background-image: url(<?php echo e(url('/banner/'.$kelas->banner)); ?>);padding:35px;">
        <div class="hero-inner">
          <h5><?php echo e(ucwords($kelas->nama_kelas)); ?></h5>
          <?php if($kelas->jenis_kelas == 'Kelas Privat'): ?>
              <span class="badge badge-danger"><?php echo e($kelas->jenis_kelas); ?></span>
          <?php elseif($kelas->jenis_kelas == 'Kelas Regular'): ?> 
              <span class="badge badge-primary"><?php echo e($kelas->jenis_kelas); ?></span>
          <?php elseif($kelas->jenis_kelas == 'Kelas Ekskul'): ?>
              <span class="badge badge-warning text-dark"><?php echo e($kelas->jenis_kelas); ?></span>
          <?php elseif($kelas->jenis_kelas == 'Kelas Lomba'): ?>
              <span class="badge badge-info"><?php echo e($kelas->jenis_kelas); ?></span>
          <?php elseif($kelas->jenis_kelas == 'Kelas Online'): ?>
              <span class="badge badge-success"><?php echo e($kelas->jenis_kelas); ?></span>
          <?php elseif($kelas->jenis_kelas == 'Kelas Mandiri'): ?>
              <span class="badge text-light" style="background:#9b59b6;"><?php echo e($kelas->jenis_kelas); ?></span>
          <?php endif; ?>
          <p class="lead"><?php echo e($kelas->program_belajar->nama_program_belajar); ?></p>
        </div>
      </div>
              <div class="card card-hero">
                <div class="card-body p-0">
                  <div class="tickets-list">
                    <a href="#" class="ticket-item">
                      <div class="ticket-info">
                        <div><?php echo e($kelas->program_belajar->deskripsi); ?></div>
                      </div>
                    </a>
                    <a href="#" class="ticket-item">
                      <div class="ticket-title">
                        <h4><i class="fas fa-play-circle mr-3"></i> <?php echo e($slot_kelas->count()); ?> Pertemuan</h4>
                      </div>
                    </a>
                    <a href="<?php echo e(route('profileall',['pengajar',$kelas->pengajar->id])); ?>" class="ticket-item">
                      <div class="ticket-title">
                        <h4><i class="fas fa-chalkboard-teacher mr-3"></i> <?php echo e($kelas->pengajar->nama_pengajar); ?></h4>
                      </div>
                    </a>
                    <a href="#" class="ticket-item">
                      <div class="ticket-title">
                        <h4><i class="	fas fa-layer-group mr-3"></i> <?php if($kelas->program_belajar->level == 'mudah'): ?> Level
                        <span style="font-size:10px !important" class="badge badge-success"><b>Mudah</b></span>
                        <?php elseif($kelas->program_belajar->level == 'sedang'): ?>
                        <span style="font-size:10px !important" class="badge badge-warning"><b>Sedang</b></span>
                        <?php elseif($kelas->program_belajar->level == 'sulit'): ?>
                        <span style="font-size:10px !important" class="badge badge-danger"><b>Sulit</b></span>
                        <?php endif; ?></h4>
                      </div>
                    </a>
                    <a href="#" class="ticket-item">
                      <div class="ticket-title">
                        <h4><i class="	fas fa-star mr-3"></i> Poin Max</h4>
                      </div>
                      <ul class="list-star">
                        <li>Mekanik : <span style="font-weight:bold" class="text-info">+<?php echo e($kelas->program_belajar->mekanik); ?></span></li>
                        <li>Elektronik : <span style="font-weight:bold" class="text-success">+<?php echo e($kelas->program_belajar->elektronik); ?></span></li>
                        <li>Pemrograman : <span style="font-weight:bold" class="text-danger">+<?php echo e($kelas->program_belajar->pemrograman); ?></span></li>
                      </ul>
                    </a>
                    <a href="#" class="ticket-item">
                      <div class="ticket-title">
                        <h4><i class="	fas fa-flag mr-3"></i> Status Kelas
                        <?php if(Ceksiswa::cek_selesai($kelas->id) == 'true'): ?>
                        <div style="font-size:10px !important" class="badge badge-success ml-auto">Finished</div>
                        <?php else: ?>
                        <div style="font-size:10px !important" class="badge badge-primary ml-auto">On Going</div>
                      <?php endif; ?></h4>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
</div>
<h2 class="section-title">Aktifitas</h2>

<div class="row">
  <div class="col-12">
    <div class="activities">
      <?php
          $no = 1;
      ?>
      <?php $__currentLoopData = $slot_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertemuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $daftar_hari = array(
              'Sunday' => 'Minggu',
              'Monday' => 'Senin',
              'Tuesday' => 'Selasa',
              'Wednesday' => 'Rabu',
              'Thursday' => 'Kamis',
              'Friday' => 'Jumat',
              'Saturday' => 'Sabtu'
            );
            $namahari = date('l', strtotime($pertemuan->tanggal));
        ?>
        <?php if(Ceksiswa::isdate_terlewat(date('d-m-Y',strtotime($pertemuan->tanggal)),$pertemuan->materi) == 'Tidak Absen'): ?>
        <div class="activity">
          <div class="activity-icon bg-danger text-light shadow-primary">
            <i class="fas fa-times"></i>
          </div>
          <div class="activity-detail w-100">
            <div class="mb-2">
              <span class="text-job text-danger"><?php echo e($daftar_hari[$namahari]); ?>, <?php echo e(date('d-m-Y',strtotime($pertemuan->tanggal))); ?></span>
            </div>
            <p class="text-danger font-weight-bold">Kelas Kosong</p>
            <hr>
            <span class="font-weight-bold text-small"># Pertemuan Ke <?php echo e($no++); ?></span>
          </div>
        </div>
          <?php elseif(Ceksiswa::isdate_terlewat(date('d-m-Y',strtotime($pertemuan->tanggal)),$pertemuan->materi) == 'Silahkan Absen Sekarang'): ?>
          <div class="activity">
          <div class="activity-icon bg-primary text-light shadow-primary">
            <i class="fas fa-calendar-alt"></i>
          </div>
          <div class="activity-detail w-100">
            <div class="mb-2">
              <span class="text-job text-primary"><?php echo e($daftar_hari[$namahari]); ?>, <?php echo e(date('d-m-Y',strtotime($pertemuan->tanggal))); ?></span>
            </div>
            <p class="text-primary font-weight-bold">Kelas Hari Ini</p>
            <hr>
            <span class="font-weight-bold text-small"># Pertemuan Ke <?php echo e($no++); ?></span>
          </div>
        </div>
          <?php elseif(Ceksiswa::isdate_terlewat(date('d-m-Y',strtotime($pertemuan->tanggal)),$pertemuan->materi) == 'Sudah Absen' || Ceksiswa::isdate_terlewat(date('d-m-Y',strtotime($pertemuan->tanggal)),$pertemuan->materi) == 'Sudah Absen hi'): ?>
          <div class="activity">
          <div class="activity-icon bg-success text-light shadow-primary">
            <i class="fas fa-check"></i>
          </div>
          <div class="activity-detail w-100">
            <div class="mb-2">
              <span class="text-job text-success"><?php echo e($daftar_hari[$namahari]); ?>, <?php echo e(date('d-m-Y',strtotime($pertemuan->tanggal))); ?></span>
            </div>
            <p class="mb-2" style="font-size: 15px;"><?php echo e($pertemuan->materi != '' ? $pertemuan->materi : '-'); ?></p>
            
            <span class="font-weight-bold text-small"># Pertemuan Ke <?php echo e($no++); ?></span><br>
            <?php if(Ceksiswa::ceksiswahadir(Auth::user()->id,$pertemuan->id) == 'hadir'): ?>
            <a class="text-job badge badge-success text-light mt-2" href="#">Hadir</a>
            <?php else: ?>
            <a class="text-job badge badge-danger text-light mt-2" href="#">Tidak Hadir</a>
            <?php endif; ?>
          </div>
        </div>
          <?php else: ?> 
          <div class="activity">
          <div class="activity-icon bg-warning text-dark shadow-primary">
            <i class="fas fa-clock"></i>
          </div>
          <div class="activity-detail w-100">
            <div class="mb-2">
              <span class="text-job text-warning"><?php echo e($daftar_hari[$namahari]); ?>, <?php echo e(date('d-m-Y',strtotime($pertemuan->tanggal))); ?></span>
            </div>
            <p><?php echo e($pertemuan->materi != '' ? $pertemuan->materi : '-'); ?></p>
            <hr>
            <span class="font-weight-bold text-small"># Pertemuan Ke <?php echo e($no++); ?></span>
          </div>
        </div>
        <?php endif; ?>
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<h2 class="section-title">Poin Yang Didapatkan</h2>
<?php if(Ceksiswa::cek_selesai($kelas->id) == 'true'): ?>
<div class="card card-statistic-2">
  <div class="card-icon shadow-primary bg-primary">
    <i class="fas fa-cogs"></i>
  </div>
  <div class="card-wrap">
    <div class="card-header">
      <h4>Mekanik</h4>
    </div>
    <div class="card-body">
      +<?php echo e(Ceksiswa::cek_get_poin($kelas->id,'mekanik')); ?>

    </div>
  </div>
</div>
<div class="card card-statistic-2">
  <div class="card-icon shadow-success bg-success">
    <i class="fas fa-microchip"></i>
  </div>
  <div class="card-wrap">
    <div class="card-header">
      <h4>Elektronik</h4>
    </div>
    <div class="card-body">
      +<?php echo e(Ceksiswa::cek_get_poin($kelas->id,'elektronik')); ?>

    </div>
  </div>
</div>
<div class="card card-statistic-2">
  <div class="card-icon shadow-danger bg-danger">
    <i class="fas fa-code"></i>
  </div>
  <div class="card-wrap">
    <div class="card-header">
      <h4>Pemrograman</h4>
    </div>
    <div class="card-body">
      +<?php echo e(Ceksiswa::cek_get_poin($kelas->id,'pemrograman')); ?>

    </div>
  </div>
</div>

<h2 class="section-title">Beri Testimoni</h2>
<?php if($feedback->count() > 0): ?>
<div class="alert alert-success alert-has-icon">
  <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
  <div class="alert-body">
    <div class="alert-title">Kamu sudah memberi Testimoni</div>
  </div>
</div>
<?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <div class="card-header"><h4>Testimoni Kamu</h4></div>
    <div class="card-body">
      <?php for($i = 0; $i < $item->stars; $i++): ?>
      <i class="fas fa-star text-warning"></i>
      <?php endfor; ?>
      <blockquote class="blockquote mt-3">
        <p class="mb-0">"<?php echo e($item->isi_feedback); ?>"</p>
        <footer class="blockquote-footer">Testimoni dari <cite title="Source Title"><?php echo e(Auth::user()->nama_siswa); ?></cite></footer>
      </blockquote>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="alert alert-primary alert-has-icon">
  <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
  <div class="alert-body">
    <div class="alert-title">Beri Testimoni</div>
    Beri Testimoni untuk kelas ini.
  </div>
</div>
<div class="card">
  <div class="card-body">
    <form action="<?php echo e(route('siswa.feedback_save')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id_kelas" value="<?php echo e($kelas->id); ?>">
    <div class="row justify-content-center">
      <div class="col-md-12 mt-2"><center>
        <input 
          type="radio" name="emotion" 
          id="angry" class="input-hidden" value="1" />
        <label for="angry" class="angry">
        </label>

        <input 
          type="radio" name="emotion" 
          id="angry1" class="input-hidden" value="2" />
        <label for="angry1" class="angry1">
        </label>

        <input 
          type="radio" name="emotion" 
          id="netral" class="input-hidden" value="3" />
        <label for="netral" class="netral">
        </label>

        <input 
          type="radio" name="emotion" 
          id="smile" class="input-hidden" value="4" />
        <label for="smile" class="smile">
        </label>

        <input 
          type="radio" name="emotion" 
          id="smile1" class="input-hidden" value="5" />
        <label for="smile1" class="smile1">
        </label>
      </center></div>
      <div class="col-md-12 mt-2" id="kolom" style="display: none;">
        <div class="form-group col-12">
          <label for="alamat">Masukan/Testimoni</label>
          <textarea style="height:220px;" name="isi_feedback" id="isi_feedback" class="form-control summernote-simple" required></textarea>
          <button type="submit" class="btn btn-primary mt-3">
            Kirim
          </button>
        </div>
      </div>
    </form>
    </div>
  </div>
  <?php endif; ?>
<?php else: ?>
<h3>Kelas Belum Selesai</h3>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<style>
  .input-hidden {
    position: absolute;
    left: -9999px;
  }

  input[type=radio]:checked + label {
    /* border: 1px solid #fff;
    box-shadow: 0 0 3px 3px #090; */
  }

  /* Stuff after this is only to make things more pretty */
  input[type=radio] + label {
    margin-right: 0px;
    width: 40px;
    height: 40px;
    cursor:pointer;
  }

  input[type=radio] + .angry {
    background: url('<?php echo e(asset('assets/reaction/1.png')); ?>');
    background-size:100% 100%;
  }
  input[type=radio]:checked + .angry {
    background: url('<?php echo e(asset('assets/reaction/1.gif')); ?>');
    background-size:100% 100%;
  }

  input[type=radio] + .angry1 {
    background: url('<?php echo e(asset('assets/reaction/2.png')); ?>');
    background-size:100% 100%;
  }
  input[type=radio]:checked + .angry1 {
    background: url('<?php echo e(asset('assets/reaction/2.gif')); ?>');
    background-size:100% 100%;
  }

    input[type=radio] + .netral {
    background: url('<?php echo e(asset('assets/reaction/3.png')); ?>');
    background-size:100% 100%;
    }
    input[type=radio]:checked + .netral {
    background: url('<?php echo e(asset('assets/reaction/3.gif')); ?>');
    background-size:100% 100%;
    }

    input[type=radio] + .smile {
    background: url('<?php echo e(asset('assets/reaction/4.png')); ?>');
    background-size:100% 100%;
    }
    input[type=radio]:checked + .smile {
    background: url('<?php echo e(asset('assets/reaction/4.gif')); ?>');
    background-size:100% 100%;
    }

    input[type=radio] + .smile1 {
    background: url('<?php echo e(asset('assets/reaction/5.png')); ?>');
    background-size:100% 100%;
    }
    input[type=radio]:checked + .smile1 {
    background: url('<?php echo e(asset('assets/reaction/5.gif')); ?>');
    background-size:100% 100%;
    }

</style>
<script>
  $(function() {
    $('input:radio').change(function(){
        if ($(this).is(':checked')) {
          $('#kolom').removeAttr('style');
        }
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('siswa.template.mainsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/base_file/resources/views/siswa/detail-siswa.blade.php ENDPATH**/ ?>
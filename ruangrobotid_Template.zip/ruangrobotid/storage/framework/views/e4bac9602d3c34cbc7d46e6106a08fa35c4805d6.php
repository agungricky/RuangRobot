<?php $__env->startSection('title','Kelas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="add-items d-flex">
                        <button class="add btn btn-primary mb-3" id="addData"><i class="fas fa-plus"></i> Tambah kelas</button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped" id="tabelData">
                            <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama kelas</th>
                                <th>Jenis</th>
                                <th>Tanggal Dibuat</th>
                                <th>Status</th>
                                <th>Detail Kelas</th>
                                <th>Opsi</th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
             <!-- modal -->
             <?php $__env->startSection('modal'); ?>
             <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="inputForm">
                    <input type="hidden" name="id" id="id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="jadwal">Nama kelas</label>
                            <input type="text" class="form-control" id="nama_kelas" placeholder="Nama kelas" name="nama_kelas">
                        </div>
                        <div class="form-group">
                            <label for="jeniskelas">Jenis Kelas</label>
                            <select name="jenis_kelas" id="jeniskelas" class="form-control">
                                <option value="Kelas Privat">Kelas Privat</option>
                                <option value="Kelas Regular">Kelas Regular</option>
                                <option value="Kelas Ekskul">Kelas Ekskul</option>
                                <option value="Kelas Lomba">Kelas Lomba</option>
                                <option value="Kelas Online">Kelas Online</option>
                                <option value="Kelas Mandiri">Kelas Mandiri</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="program_belajar">Program Belajar</label>
                            <select name="program_belajar_id" id="program_belajar" class="form-control">
                                <?php $__currentLoopData = $program_belajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pb->id); ?>"><?php echo e($pb->nama_program_belajar); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="pengajar">Pengajar</label>
                            <select name="pengajar_id" id="pengajar" class="form-control">
                                <?php $__currentLoopData = $pengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pb->id); ?>"><?php echo e($pb->nama_pengajar); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="jadwal">Gaji/Pertemuan</label>
                            <input type="text" class="form-control" id="gaji" placeholder="Gaji" name="gaji">
                        </div>
                        <hr>
                        <div class="form-group">
                            <div class="input_fields_wrap">
                                <label for="date" class="font-weight-bold">Sesi 1 :</label>
                                <input name="tanggal[]" type="date" class="form-control" placeholder="Tanggal">
                                <div class="row">
                                    <div class="col-md-6 mt-2">
                                        <span>Jam Mulai</span>
                                        <input name="jamm[]" type="text" class="form-control mt-2 timepicker" placeholder="Jam Mulai / Jam Selesai">
                                    </div>
                                    <div class="col-md-6 mt-2">
                                        <span>Jam Selesai</span>
                                        <input name="jams[]" type="text" class="form-control mt-2 timepicker" placeholder="Jam Mulai / Jam Selesai">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                              <a href="javascript:void(0)" class="add_field_button btn btn-primary btn-sm">Tambah Sesi</a>
                            </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" id="saveBtn"><i class="fas fa-save btn-icon-append"></i> Simpan</button>
                    </div>
                    </form>
                    </div>
                </div>
            </div>
             <?php $__env->stopSection(); ?>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('timepicki/bootstrap-clockpicker.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('timepicki/bootstrap-clockpicker.min.js')); ?>"></script>
<style type="text/css">
    .popover{border: 1px solid #ccc;}
</style>
<script>
$(function(){
    // $('.timepicker').timepicki();
    $(document).on('focus', '.timepicker', function(){
        $(this).clockpicker({       
  placement: 'top',
  align: 'left',
  autoclose: true,
  default: 'now',
  donetext: "Select"});
    });
});
</script>
<script>
    $(document).ready(function() {
        var max_fields      = 1000;
        var wrapper   		= $(".input_fields_wrap");
        var add_button      = $(".add_field_button");
    
        var x = 1;
        $(add_button).click(function(e){
            e.preventDefault();
            if(x < max_fields){
                x++;
                $(wrapper).append('<div class="form-group mt-3"><div><label for="date">Sesi '+x+' :</label><input name="tanggal[]" type="date" class="form-control" placeholder="Tanggal"><div class="row"><div class="col-md-6 mt-2"><span>Jam Mulai</span><input name="jamm[]" type="text" class="form-control mt-2 timepicker" placeholder="Jam Mulai / Jam Selesai"></div><div class="col-md-6 mt-2"><span>Jam Selesai</span><input name="jams[]" type="text" class="form-control mt-2 timepicker" placeholder="Jam Mulai / Jam Selesai"></div></div></div><a href="#" class="remove_field"><i class="text-danger fas fa-times"></i></a></div>'); //add input box
            }
        });
    
        $(wrapper).on("click",".remove_field", function(e){
            e.preventDefault(); $(this).parent('div').remove(); x--;
        })
    });
    </script>
<script type="text/javascript">
    $(function () {
       
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
      });
      
      var table = $('#tabelData').DataTable({
          processing: true,
          serverSide: true,
          paging:   true,
          ordering: true,
          searching: true,
          ajax: "<?php echo e(route('kelas.index')); ?>",
          columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                {data: 'nama_kelas', name: 'nama_kelas',render:function(nama_kelas){return '<b>'+nama_kelas+'</b>';}},
                {data: 'jenis_kelas', name: 'jenis_kelas'},
                {data: 'created_at', name: 'created_at'},
                {data: 'status', name: 'status'},
                {data: 'selengkapnya', name: 'selengkapnya', orderable: false, searchable: false},
                {data: 'action', name: 'action', orderable: false, searchable: false},
          ]
      });
      
      $('#addData').click(function() {
          $('#id').val('');
          $('#nama_kelas').val('');
          $("#program_belajar").prop("selectedIndex", 0);
          $("#pengajar").prop("selectedIndex", 0);
          $('#gaji').val('');
          $('#saveBtn').html('Simpan');
          $('#ajaxModal').trigger('reset');
          $('.modal-title').html('Tambah kelas');
          $('#ajaxModal').modal('show');
      });

      $('#saveBtn').click(function(e) {
          e.preventDefault();
          $(this).html('Menyimpan..');
          $.ajax({
              data: $('#inputForm').serialize(),
              url: "<?php echo e(route('kelas.store')); ?>",
              type: 'POST',
              dataType: 'json',
              success: function(data) {
                $('#ajaxModal').trigger('reset');
                $('#ajaxModal').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil menyimpan',
                    showConfirmButton: false,
                    timer: 1500
                });
                table.draw();
              },
              error: function(data) {
                  console.log('Error: ', data);
                  $('#saveBtn').html('Simpan');
              }
          });
      });

    $('body').on('click', '.delete', function() {
        var id = $(this).data('id');

        Swal.fire({
        title: 'Ingin menghapus kelas?',
        text: "Data yang terhapus tidak dapat dikembalikan",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    type: 'DELETE',
                    url: "<?php echo e(route('kelas.store')); ?>"+'/'+id,
                    success: function(data) {
                        table.draw();
                    },
                    error: function(data) {
                    console.log('Error: ', data);
                    }
                });
                Swal.fire({
                    icon: 'success',
                    title: 'Data telah dihapus',
                    showConfirmButton: false,
                    timer: 1500
                });
            }
        })
      });

    $('body').on('click', '.edit', function() {
        var id = $(this).data('id');
        $.get("<?php echo e(route('kelas.index')); ?>" +'/' + id +'/edit', function (data) {
            $('#ajaxModal').modal('show');
            $('.modal-title').html('Edit kelas');
            $('#id').val(data.id);
            $('#nama_kelas').val(data.nama_kelas);
            $("#program_belajar").val(data.program_belajar_id);
            $("#gaji").val(data.gajipeg);
            $("#pengajar").val(data.pengajar_id);
            $("#slot").val(data.slot);
            $('#saveBtn').val('edit');
            $('#saveBtn').html('Simpan');
        })
    });

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/base_file/resources/views/admin/kelas.blade.php ENDPATH**/ ?>
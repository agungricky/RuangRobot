<?php $__env->startSection('title', 'Daftar Kelas Saya'); ?>
<?php $__env->startSection('content'); ?>

    <h2 class="section-title">On Going</h2>
    <div class="row">
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <a href="<?php echo e(route('pengajar.detailkelas', $kls->id)); ?>" class="linklistkelas">
                    <div class="hero text-white hero-bg-image"
                        style="background-image: url('<?php echo e($kls->banner != '' ? url('/banner/' . $kls->banner) : 'https://www.gstatic.com/classroom/themes/img_videogaming.jpg'); ?>');padding:20px;">
                        <div class="hero-inner">
                            <h5 style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
                                <?php echo e(ucwords($kls->nama_kelas)); ?></h5>
                            <?php if($kls->jenis_kelas == 'Kelas Privat'): ?>
                                <span class="badge badge-danger"><?php echo e($kls->jenis_kelas); ?></span>
                            <?php elseif($kls->jenis_kelas == 'Kelas Regular'): ?>
                                <span class="badge badge-primary"><?php echo e($kls->jenis_kelas); ?></span>
                            <?php elseif($kls->jenis_kelas == 'Kelas Ekskul'): ?>
                                <span class="badge badge-warning text-dark"><?php echo e($kls->jenis_kelas); ?></span>
                            <?php elseif($kls->jenis_kelas == 'Kelas Lomba'): ?>
                                <span class="badge badge-info"><?php echo e($kls->jenis_kelas); ?></span>
                            <?php elseif($kls->jenis_kelas == 'Kelas Online'): ?>
                                <span class="badge badge-success"><?php echo e($kls->jenis_kelas); ?></span>
                            <?php elseif($kls->jenis_kelas == 'Kelas Mandiri'): ?>
                                <span class="badge text-light" style="background:#9b59b6;"><?php echo e($kls->jenis_kelas); ?></span>
                            <?php endif; ?>
                            <p class="lead"><?php echo e($kls->program_belajar->nama_program_belajar); ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h2 class="section-title">Complete <button style="font-size: 12px;border:0;padding: 8px 15px !important;"
            class="badge badge-primary" type="button" data-toggle="collapse" data-target="#collapseExample"
            aria-expanded="false" aria-controls="collapseExample">
            Lihat (<?php echo e($kelas2->count()); ?>)</button></h2>
    <div class="collapse" id="collapseExample">
        <div class="row">
            <?php $__currentLoopData = $kelas2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <a href="<?php echo e(route('pengajar.detailkelas', $kls->id)); ?>" class="linklistkelas">
                        <div class="hero text-white hero-bg-image"
                            style="background-image: url('<?php echo e($kls->banner != '' ? url('/banner/' . $kls->banner) : 'https://www.gstatic.com/classroom/themes/img_videogaming.jpg'); ?>');padding:20px;">
                            <div class="hero-inner">
                                <h5 style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
                                    <?php echo e(ucwords($kls->nama_kelas)); ?></h5>
                                <?php if($kls->jenis_kelas == 'Kelas Privat'): ?>
                                    <span class="badge badge-danger"><?php echo e($kls->jenis_kelas); ?></span>
                                <?php elseif($kls->jenis_kelas == 'Kelas Regular'): ?>
                                    <span class="badge badge-primary"><?php echo e($kls->jenis_kelas); ?></span>
                                <?php elseif($kls->jenis_kelas == 'Kelas Ekskul'): ?>
                                    <span class="badge badge-warning text-dark"><?php echo e($kls->jenis_kelas); ?></span>
                                <?php elseif($kls->jenis_kelas == 'Kelas Lomba'): ?>
                                    <span class="badge badge-info"><?php echo e($kls->jenis_kelas); ?></span>
                                <?php elseif($kls->jenis_kelas == 'Kelas Online'): ?>
                                    <span class="badge badge-success"><?php echo e($kls->jenis_kelas); ?></span>
                                <?php elseif($kls->jenis_kelas == 'Kelas Mandiri'): ?>
                                    <span class="badge text-light"
                                        style="background:#9b59b6;"><?php echo e($kls->jenis_kelas); ?></span>
                                <?php endif; ?>
                                <p class="lead"><?php echo e($kls->program_belajar->nama_program_belajar); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style media="screen">
        .linklistkelas:hover {
            text-decoration: none !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pengajar.template.mainpengajar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/athoul/Web/ruangrobot/resources/views/pengajar/kelassaya.blade.php ENDPATH**/ ?>
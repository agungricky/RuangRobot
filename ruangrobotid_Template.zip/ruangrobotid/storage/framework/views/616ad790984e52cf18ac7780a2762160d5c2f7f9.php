<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Ruang Robot - Tempatnya Belajar Robotik</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="">

    <!-- all css here -->

    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/bootstrap.min.css')); ?>">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/owl.transitions.css')); ?>">
    <!-- Animate css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/animate.css')); ?>">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/meanmenu.min.css')); ?>">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/flaticon.css')); ?>">
    <!-- venobox css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/venobox.css')); ?>">
    <!-- venobox css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/venobox.css')); ?>">
    <!-- magnific css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/magnific.min.css')); ?>">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/style.css')); ?>">
    <!-- responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('lopard-live/css/responsive.css')); ?>">
    
    <style>
        html {
            scroll-behavior: smooth;
        }
    </style>
    <!-- modernizr css -->
    <script src="<?php echo e(asset('lopard-live/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
</head>

<body>

    <!--[if lt IE 8]>
   <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->

    <div id="preloader"></div>
    <header class="header-one">
        <!-- Start top bar -->
        <div class="topbar-area fix hidden-xs">
            <div class="container">
                <div class="row">
                    <div class=" col-md-9 col-sm-9">
                        <div class="topbar-left">
                            <ul>
                                <li><a href="#"><i class="fa fa-envelope"></i> info@ruangrobot.id</a></li>
                                <li><a href="#"><i class="fa fa-phone-square"></i> +6285655770506</a></li>
                                <li><a href="#"><i class="fa fa-clock-o"></i> Senin - Jumat: 10:00 - 18:00</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3">
                        <div class="top-social">
                            <ul>
                                <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-google"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End top bar -->
        <!-- header-area start -->
        <div id="sticker" class="header-area hidden-xs">
            <div class="container">
                <div class="row">
                    <!-- logo start -->
                    <div class="col-md-3 col-sm-3">
                        <div class="logo">
                            <!-- Brand -->
                            <a class="navbar-brand " href="">
                                <img style="width:150px;" src="<?php echo e(asset('images/ruangrobot.png')); ?>" alt="">
                            </a>
                        </div>
                        <!-- logo end -->
                    </div>
                    <div class="col-md-9 col-sm-9">
                        <!-- mainmenu start -->
                        <nav class="navbar navbar-default">
                            <div class="collapse navbar-collapse" id="navbar-example">
                                <div class="main-menu">
                                    
                                </div>
                            </div>
                        </nav>
                        <!-- mainmenu end -->
                    </div>
                </div>
            </div>
        </div>
        <!-- header-area end -->
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area hidden-lg hidden-md hidden-sm">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mobile-menu">
                            <div class="logo">
                                <a href=""><img src="<?php echo e(asset('images/ruangrobot.png')); ?>" alt="" /></a>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile-menu-area end -->
    </header>
    <!-- header end -->
    <!-- Start Slider Area -->
    <div class="intro-area intro-home">
        <div class="bg-wrapper">
            <img src="<?php echo e(asset('lopard-live/img/background/bg.jpg')); ?>" alt="">
        </div>
        <div class="intro-content">
            <div class="slider-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="slide-all-text">
                                <!-- layer 1 -->
                                <div class="layer-1 wow fadeInUp" data-wow-delay="0.3s">
                                    <h2 class="title2">Selamat Datang di
                                        Ruang Robot</h2>
                                </div>
                                <!-- layer 2 -->
                                <div class="layer-2 wow fadeInUp" data-wow-delay="0.5s">
                                    <p>Kembangkan Skill Robotik dan Pemrograman Kamu, Mulai Buat Project Pertamamu
                                        Sekarang.</p>
                                </div>
                                <!-- layer 3 -->
                                <div class="layer-3 wow fadeInUp" data-wow-delay="0.7s">
                                    <a href="<?php echo e(route('login')); ?>" class="ready-btn">Login</a>
                                    <a href="https://wa.me/6285655770506?text=<?php echo e(urlencode('Halo Ruang Robot.
                                    Saya Mau daftar.
                                    
                                    Nama Lengkap:
                                    Nomor Telfon:
                                    Sekolah:
                                    Tanggal Lahir:
                                    Alamat:
                                    
                                    Terimakasih.')); ?>"
                                        class="ready-btn">Register</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 hidden-xs">
                            <div class="slide-images-inner wow fadeInUp" data-wow-delay="0.5s">
                                <div class="slide-images">
                                    <img src="<?php echo e(asset('lopard-live/img/slider/s1.png')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Slider Area -->
    <!-- Start Brand Area -->
    

    <!-- all js here -->

    <!-- jquery latest version -->
    <script src="<?php echo e(asset('lopard-live/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('lopard-live/js/bootstrap.min.js')); ?>"></script>
    <!-- owl.carousel js -->
    <script src="<?php echo e(asset('lopard-live/js/owl.carousel.min.js')); ?>"></script>
    <!-- venobox js -->
    <script src="<?php echo e(asset('lopard-live/js/venobox.min.js')); ?>"></script>
    <!-- magnific js -->
    <script src="<?php echo e(asset('lopard-live/js/magnific.min.js')); ?>"></script>
    <!-- wow js -->
    <script src="<?php echo e(asset('lopard-live/js/wow.min.js')); ?>"></script>
    <!-- meanmenu js -->
    <script src="<?php echo e(asset('lopard-live/js/jquery.meanmenu.js')); ?>"></script>
    <!-- Form validator js -->
    <script src="<?php echo e(asset('lopard-live/js/form-validator.min.js')); ?>"></script>
    <!-- plugins js -->
    <script src="<?php echo e(asset('lopard-live/js/plugins.js')); ?>"></script>
    <!-- main js -->
    <script src="<?php echo e(asset('lopard-live/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/ruangro2/ruangrobotid/resources/views/landing.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Dashboard Admin'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                    <i class="fas fa-users"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Siswa</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($siswa); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Pengajar</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($pengajar); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                    <i class="far fa-newspaper"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Kelas</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($kelas); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                    <i class="fas fa-money-bill-alt"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Income</h4>
                    </div>
                    <div class="card-body">
                        <p style="font-size: 16px;color:green;font-weight:bold;">Rp <?php echo e(number_format($pembayarana)); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4>Pembayaran Terbaru</h4>
                    <div class="card-header-action">
                        <a href="<?php echo e(route('admin.pembayaran')); ?>" class="btn btn-danger">Selengkapnya <i
                                class="fas fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive table-invoice">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <th>Nama Siswa</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Jumlah</th>
                                </tr>
                                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a class="font-weight-bold"
                                                href="<?php echo e(route('admin.detail-pembayaran', $item->id_selected_class)); ?>"><?php echo e(Ceksiswa::cek_nama_siswa($item->id_selected_class)); ?></a>
                                        </td>
                                        <td>
                                            <?php if($item->status == 'Menunggu Konfirmasi'): ?>
                                                <span
                                                    class="text-dark badge badge-warning badge-pill"><?php echo e($item->status); ?></span>
                                            <?php elseif($item->status == 'Pembayaran Diterima'): ?>
                                                <span class="badge badge-success badge-pill"><?php echo e($item->status); ?></span>
                                            <?php elseif($item->status == 'Pembayaran Ditolak'): ?>
                                                <span class="badge badge-danger badge-pill"><?php echo e($item->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <th><?php echo e(date('d-m-Y', strtotime($item->tanggal_bayar))); ?></th>
                                        <td class="font-weight-bold text-success">+<?php echo e(number_format($item->jumlah)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4>Laporan Keuangan</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="tabelpemb">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Pendapatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pembayaran_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="font-weight-bold">
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($item->month . ' / ' . $item->year); ?></td>
                                        <td class="text-success">Rp <?php echo e(number_format($item->data)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-md-4">
            <div class="card card-hero">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="far fa-question-circle"></i>
                    </div>
                    <h4>Absen Terbaru</h4>
                </div>
                <div class="card-body p-0">
                    <div class="tickets-list">
                        <?php $__currentLoopData = $sesi_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.listsiswa', \App\Kelas::where(['uuid' => $item->id_kelas])->first()->id)); ?>"
                                class="ticket-item">
                                <div class="ticket-title">
                                    <h4><?php echo e($item->materi); ?></h4>
                                </div>
                                <div class="ticket-info">
                                    <div><?php echo e(Ceksiswa::get_kelas($item->id_kelas)->nama_kelas); ?></div>
                                    <div class="bullet"></div>
                                    <div><?php echo e(Ceksiswa::get_kelas($item->id_kelas)->pengajar->nama_pengajar); ?></div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $('#tabelpemb').DataTable({
                paging: true,
                ordering: true,
                searching: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/ruangrobotid/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>
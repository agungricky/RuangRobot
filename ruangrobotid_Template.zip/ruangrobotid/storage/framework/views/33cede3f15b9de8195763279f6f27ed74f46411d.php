<?php $__env->startSection('title', 'Program Belajar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <div class="add-items d-flex">
                        <button class="add btn btn-primary mb-3 font-weight-bold todo-list-add-btn" id="addData"><i
                                class="fas fa-plus"></i> Tambah program belajar</button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped" id="tabelData">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Program Belajar</th>
                                    <th>Harga</th>
                                    <th style="width: 240px;">Deskripsi</th>
                                    <th>Level</th>
                                    <th style="width: 110px;">Poin</th>
                                    <th style="width: 130px;">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- modal -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="inputForm">
                    <input type="hidden" name="id" id="id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="programbelajar">Nama programbelajar</label>
                            <input type="text" class="form-control" id="programbelajar"
                                placeholder="Nama program belajar" name="program_belajar">
                        </div>
                        <div class="form-group">
                            <label for="jadwal">harga</label>
                            <input type="text" class="form-control" id="harga" placeholder="Harga" name="harga">
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea style="height: 150px;" class="form-control" id="deskripsi" name="deskripsi" cols="30" rows="10"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Bobot Nilai Mekanik</label><br>
                            <div class="row col-md-12">
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="mekanik" id="mekanik1"
                                                value="3"> +3 Poin<i class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="mekanik" id="mekanik2"
                                                value="2"> +2 Poin<i class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="mekanik" id="mekanik3"
                                                value="1"> +1 Poin<i class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="mekanik" id="mekanik4"
                                                value="0"> +0 Poin<i class="input-helper"></i></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Bobot Nilai Elektronik</label><br>
                            <div class="row col-md-12">
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="elektronik"
                                                id="elektronik1" value="3"> +3 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="elektronik"
                                                id="elektronik2" value="2"> +2 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="elektronik"
                                                id="elektronik3" value="1"> +1 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="elektronik"
                                                id="elektronik4" value="0"> +0 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Bobot Nilai Pemrograman</label><br>
                            <div class="row col-md-12">
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="pemrograman"
                                                id="pemrograman1" value="3"> +3 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="pemrograman"
                                                id="pemrograman2" value="2"> +2 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="pemrograman"
                                                id="pemrograman3" value="1"> +1 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check form-check-info">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="pemrograman"
                                                id="pemrograman4" value="0"> +0 Poin<i
                                                class="input-helper"></i></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="level">Level</label>
                            <select class="form-control" name="level" id="level">
                                <option value="mudah">Mudah</option>
                                <option value="sedang">Sedang</option>
                                <option value="sulit">Sulit</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" id="saveBtn"><i
                                class="fas fa-save btn-icon-append"></i> Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#tabelData').DataTable({
                processing: true,
                serverSide: true,
                // paging:   false,
                // ordering: false,
                // searching: false,
                ajax: "<?php echo e(route('programbelajar.index')); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'nama_program_belajar',
                        name: 'nama_program_belajar'
                    },
                    {
                        data: 'harga',
                        name: 'harga'
                    },
                    {
                        data: 'deskripsi',
                        name: 'deskripsi'
                    },
                    {
                        data: 'level',
                        name: 'level'
                    },
                    {
                        data: 'poin',
                        name: 'poin'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

            $('#addData').click(function() {
                $('#id').val('');
                $('#programbelajar').val('');
                $('#harga').val('');
                $('#deskripsi').val('');
                $('#level').val('mudah');
                $('#saveBtn').html('Simpan');
                $('#ajaxModal').trigger('reset');
                $('.modal-title').html('Tambah program belajar');
                $('#ajaxModal').modal('show');
            });

            $('#saveBtn').click(function(e) {
                e.preventDefault();
                $(this).html('Menyimpan..');
                $.ajax({
                    data: $('#inputForm').serialize(),
                    url: "<?php echo e(route('programbelajar.store')); ?>",
                    type: 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#ajaxModal').trigger('reset');
                        $('#ajaxModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil menyimpan',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        table.draw();
                    },
                    error: function(data) {
                        console.log('Error: ', data);
                        $('#saveBtn').html('Simpan');
                    }
                });
            });

            $('body').on('click', '.delete', function() {
                var id = $(this).data('id');

                Swal.fire({
                    title: 'Ingin menghapus data?',
                    text: "Data yang terhapus tidak dapat dikembalikan",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Hapus!'
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            type: 'DELETE',
                            url: "<?php echo e(route('programbelajar.store')); ?>" + '/' + id,
                            success: function(data) {
                                table.draw();
                            },
                            error: function(data) {
                                console.log('Error: ', data);
                            }
                        });
                        Swal.fire({
                            icon: 'success',
                            title: 'Data telah dihapus',
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                })
            });

            $('body').on('click', '.edit', function() {
                var id = $(this).data('id');
                $.get("<?php echo e(route('programbelajar.index')); ?>" + '/' + id + '/edit', function(data) {
                    $('#ajaxModal').modal('show');
                    $('.modal-title').html('Edit program belajar');
                    $('#id').val(data.id);
                    $('#programbelajar').val(data.nama_program_belajar);
                    $('#harga').val(data.harga);
                    $('#deskripsi').val(data.deskripsi);
                    $('#level').val(data.level);
                    if (data.mekanik == 3) {
                        $('#mekanik1').prop("checked", true);
                    } else if (data.mekanik == 2) {
                        $('#mekanik2').prop("checked", true);
                    } else if (data.mekanik == 1) {
                        $('#mekanik3').prop("checked", true);
                    } else if (data.mekanik == 0) {
                        $('#mekanik4').prop("checked", true);
                    }

                    if (data.elektronik == 3) {
                        $('#elektronik1').prop("checked", true);
                    } else if (data.elektronik == 2) {
                        $('#elektronik2').prop("checked", true);
                    } else if (data.elektronik == 1) {
                        $('#elektronik3').prop("checked", true);
                    } else if (data.elektronik == 0) {
                        $('#elektronik4').prop("checked", true);
                    }

                    if (data.pemrograman == 3) {
                        $('#pemrograman1').prop("checked", true);
                    } else if (data.pemrograman == 2) {
                        $('#pemrograman2').prop("checked", true);
                    } else if (data.pemrograman == 1) {
                        $('#pemrograman3').prop("checked", true);
                    } else if (data.pemrograman == 0) {
                        $('#pemrograman4').prop("checked", true);
                    }
                    $('#saveBtn').val('edit');
                    $('#saveBtn').html('Simpan');
                })
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/ruangrobotid/resources/views/admin/programbelajar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Tambah Siswa'); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="card">
            <div class="card-body">
            <form action="<?php echo e(route('admin.siswacreateaksi')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="input_fields_wrap">
              <div class="row mb-3">
                <div class="col-md-4 mb-3">
                  <span style="padding-bottom:5px;display:block;">Nama</span>
                  <input name="nama[]" type="text" class="form-control" placeholder="Nama" required>
                </div>
                  <div class="col-md-4 mb-3">
                    <span style="padding-bottom:5px;display:block;">Username</span>
                    <input required name="username[]" type="text" class="form-control" placeholder="Username" onkeyup="cekusername(this)">
                  </div>
                <div class="col-md-4 mb-3">
                  <span style="padding-bottom:5px;display:block;">Nomor Telfon</span>
                  <input required name="notlep[]" type="text" class="form-control" placeholder="Nomor Telfon">
                </div>
                <div class="col-md-4 mb-3">
                  <span style="padding-bottom:5px;display:block;">Sekolah</span>
                  <input required name="sekolah[]" type="text" class="form-control" placeholder="Sekolah">
                </div>
                <div class="col-md-4 mb-3">
                  <span style="padding-bottom:5px;display:block;">Tanggal Lahir</span>
                  <input required name="tgllahir[]" type="date" class="form-control" placeholder="Tanggal Lahir">
                </div>
                <div class="col-md-4 mb-3">
                  <span style="padding-bottom:5px;display:block;">Alamat</span>
                  <input required name="alamat[]" type="text" class="form-control" placeholder="Alamat">
                </div>
              </div>
              </div>

              <div class="row">
              <div class="col-md-3">
                <button class="add_field_button btn btn-success btn-fw btn-sm">Tambah Field</button>
              </div>
              </div>
                <hr>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </form>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
	var max_fields      = 1000;
	var wrapper   		= $(".input_fields_wrap");
	var add_button      = $(".add_field_button");

	var x = 1;
	$(add_button).click(function(e){
		e.preventDefault();
		if(x < max_fields){
			x++;
			$(wrapper).append('<div class="row"><div class="col-md-12"><hr></div><div class="col-md-4 mb-3"><span style="padding-bottom:5px;display:block;">Nama</span><input required name="nama[]" type="text" class="form-control" placeholder="Nama"></div><div class="col-md-4 mb-3"><span style="padding-bottom:5px;display:block;">Username</span><input required name="username[]" type="text" class="form-control" placeholder="Username" onkeyup="cekusername(this)"></div><div class="col-md-4 mb-3"><span style="padding-bottom:5px;display:block;">Nomor Telfon</span><input required name="notlep[]" type="text" class="form-control" placeholder="Nomor Telfon"></div><div class="col-md-4 mb-3"><span style="padding-bottom:5px;display:block;">Sekolah</span><input required name="sekolah[]" type="text" class="form-control" placeholder="Sekolah"></div><div class="col-md-4 mb-3"><span style="padding-bottom:5px;display:block;">Tanggal Lahir</span><input required name="tgllahir[]" type="date" class="form-control" placeholder="Tanggal Lahir"></div><div class="col-md-4 mb-3"><span style="padding-bottom:5px;display:block;">Alamat</span><input required name="alamat[]" type="text" class="form-control" placeholder="Alamat"></div><a href="#" class="remove_field  col-md-4 mb-3"><i class="text-danger fas fa-times"></i></a></div>'); //add input box
		}
	});

	$(wrapper).on("click",".remove_field", function(e){
		e.preventDefault(); $(this).parent('div').remove(); x--;
	})
});
function cekusername(tagnya){
  $.ajax({
      data: {username : tagnya.value},
      url: "<?php echo e(route('admin.cekusernameada')); ?>",
      success: function(data) {
        if (data == 'ada') {
          tagnya.classList.add("is-invalid");
        } else {
          tagnya.classList.remove("is-invalid");
        }
      }
  });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/base_file/resources/views/admin/addsiswa.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="" style="color: #666;font-size:15px;">
                            <?php echo e(Ceksiswa::get_detail_pembayaran($item->id, 'nama')); ?></h4>
                        <hr>
                        <p>Harga : <?php echo e('Rp. ' . number_format(Ceksiswa::get_detail_pembayaran($item->id, 'pb'))); ?></p>
                        <p>Status : <?php if($item->sudahbayar == 0): ?>
                                <span class="badge badge-warning text-dark">Belum Lunas</span>
                            <?php else: ?>
                                <span class="badge badge-success">Lunas</span>
                            <?php endif; ?>
                        </p>
                        

                        <a href="<?php echo e(route('siswa.uploadbukti', $item->id)); ?>" class="btn btn-lg btn-block btn-primary"><i
                                class="fas fa-arrow-right mr-2"></i>Selengkapnya</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa.template.mainsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/ruangrobot/resources/views/siswa/pembayaran.blade.php ENDPATH**/ ?>
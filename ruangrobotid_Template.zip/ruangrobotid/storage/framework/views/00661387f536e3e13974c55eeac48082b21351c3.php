<?php $__env->startSection('title','Upload Bukti Pembayaran '.$kelas->nama_kelas); ?>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('siswa.pembayaran')); ?>" class="btn btn-primary btn-lg mb-2"><i class="fa fa-arrow-left"></i> Kembali</a>


<h2 class="section-title">Detail Pembayaran</h2>
<div class="row">
  <div class="col-md-12">
    <div class="card card-statistic-2">
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-dollar-sign"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Harga Kelas</h4>
        </div>
        <div class="card-body">
          Rp <?php echo e(number_format($kelas->program_belajar->harga)); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card card-statistic-2">
      <div class="card-icon shadow-success bg-success">
        <i class="fas fa-dollar-sign"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Sudah Dibayar</h4>
        </div>
        <div class="card-body">
          <p class="font-weight-bold">Rp <?php echo e(number_format($list_bayar->where("status", "Pembayaran Diterima")->sum('jumlah'))); ?> <br>
          <span style="font-size: 16px;"><?php echo e(round(($list_bayar->where("status", "Pembayaran Diterima")->sum('jumlah')/$kelas->program_belajar->harga) * 100)); ?>%</span>
        </p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card card-statistic-2">
      <div class="card-icon shadow-warning bg-warning text-dark">
        <i class="fas fa-dollar-sign"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Kekurangan</h4>
        </div>
        <div class="card-body">
          Rp <?php echo e(number_format($kelas->program_belajar->harga - $list_bayar->where("status", "Pembayaran Diterima")->sum('jumlah'))); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card card-statistic-2">
      <div class="card-icon shadow-info bg-info">
        <i class="fas fa-flag"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Status Lunas</h4>
        </div>
        <div class="card-body">
          <?php echo e(($kelas_bayar->sudahbayar == 0) ? "BELUM LUNAS" : "SUDAH LUNAS"); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card card-statistic-2">
      <div class="card-icon shadow-danger bg-danger">
        <i class="fas fa-clock"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Jatuh Tempo</h4>
        </div>
        <div class="card-body">
          <?php echo e(date('d-m-Y',strtotime($slice))); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <?php if($kelas_bayar->sudahbayar == 0): ?>
    <div class="col-md-6">
      <button onclick="uploadbukti()" class="btn btn-block btn-lg btn-success mb-3"><i class="fas fa-upload"></i> Upload Bukti</button>
    </div>
    <?php endif; ?>
    <div class="col-md-6">
      <a class="btn btn-block btn-lg btn-primary" href="<?php echo e(route('siswa.pembayaran_cetak',[$id,date('d-m-Y',strtotime($slice))])); ?>"><i class="fas fa-print"></i> Unduh Invoice</a>
      </div>
</div>
<h2 class="section-title">Histori Pembayaran</h2>
<div class="row">
  <div class="col-12">
    <div class="activities">
      <?php $__currentLoopData = $list_bayar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="activity">
        <div class="activity-icon bg-primary text-white shadow-primary">
        #<?php echo e($key+1); ?>

        </div>
        <div class="activity-detail w-100">
          <div class="mb-2">
            <span class="text-job"><?php echo e(date('d-m-Y',strtotime($bayar->tanggal_bayar))); ?></span>
            <span class="bullet"></span>
            <?php if($bayar->manual == 'N'): ?>
            <button data-src="<?php echo e(url('/data_file/'.$bayar->bukti_pembayaran)); ?>" style="border: 0px;border-radius: 5px;background: #6777ef;color: #fff;padding: 3px 10px;" class="text-job" onclick="detail(this)">Detail</button>
            <?php else: ?>
            <button style="border: 0px;border-radius: 5px;background: #47c363;color: #fff;padding: 3px 10px;" class="text-job">Manual (Admin)</span>                               
            <?php endif; ?>
          </div>
          <p style="font-size: 19px;font-weight:bold;" class="mb-3">Rp. <?php echo e(number_format($bayar->jumlah)); ?></p>
                <?php if($bayar->status  == 'Menunggu Konfirmasi'): ?>
                <span class="text-dark badge badge-warning badge-pill"><?php echo e($bayar->status); ?></span>
                <?php elseif($bayar->status  == 'Pembayaran Diterima'): ?>
                <span class="badge badge-success badge-pill"><?php echo e($bayar->status); ?></span>
                <?php elseif($bayar->status  == 'Pembayaran Ditolak'): ?>
                <span class="badge badge-danger badge-pill"><?php echo e($bayar->status); ?></span>
                <?php endif; ?>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Bukti Pembayaran</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img class="img-fluid" id="buktiiii" src="" alt="">
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalupload" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload Bukti Pembayaran</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('siswa.uploadbuktiaction')); ?>" enctype="multipart/form-data" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="id_selected_class" value="<?php echo e($kelas_bayar->id); ?>">
          <div>
            <div class="form-group">
              <label for="">Jumlah Pembayaran (Rp)</label>
            <input type="number" name="jumlah" class="form-control" placeholder="Jumlah Pembayaran" required>
            </div>
            <div class="form-group">
              <label for="">Bukti Pembayaran</label>
            <input type="file" name="image" class="form-control" accept="image/*" required>
            </div>
          <button class="btn btn-sm btn-primary" id="saveBtn"><i class="fa fa-upload"></i>  Upload</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
      function detail(thisnya) {
        $('#buktiiii').attr('src',$(thisnya).data('src'));
        $('#ajaxModal').modal('show');
      };
      function uploadbukti() {
        $('#modalupload').modal('show');
      };
    </script>
    <?php if(\Session::has('success')): ?>
    <script>
      $(function(){
        swal.fire({
          icon: 'success',
          title: "Pembayaran Berhasil",
          timer: 1000,
          showConfirmButton: false
        });
      });
    </script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('siswa.template.mainsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/athoul/ruangrobot/resources/views/siswa/uploadbukti.blade.php ENDPATH**/ ?>
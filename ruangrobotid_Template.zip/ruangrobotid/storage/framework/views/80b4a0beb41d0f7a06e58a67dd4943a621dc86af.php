<?php $__env->startSection('title','Dashboard Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12 col-sm-12 col-lg-12">
    <div class="card author-box card-primary">
      <div class="card-body">
        <div class="author-box-left">
          <img style="width: 100px;height: 100px;object-fit: cover;" alt="image" src="<?php echo e(Auth::user()->profile_pict ? url('profile_pict/'.Auth::user()->profile_pict) : url('assets/img/avatar/avatar-1.png')); ?>" class="rounded-circle author-box-picture">
          <div class="clearfix"></div>
        </div>
        <div class="author-box-details">
          <div class="author-box-name">
            <a href="<?php echo e(route('profileall',['siswa',Auth::user()->id])); ?>"><?php echo e(ucwords(Auth::user()->nama_siswa)); ?> <div class="badge badge-pill badge-primary">SISWA</div></a>
          </div>
          <div class="author-box-job mt-3"><i class="fas fa-map-marker"></i> <?php echo e(ucwords(Auth::user()->alamat)); ?></div>
                <div class="author-box-job mt-3"><i class="fas fa-birthday-cake"></i> <?php echo e(Auth::user()->tgl_lahir); ?></div>
                <div class="author-box-job mt-3"><i class="fas fa-phone"></i> <?php echo e(Auth::user()->notlep); ?></div>
                <div class="author-box-job mt-3"><i class="fas fa-school"></i> <?php echo e(Auth::user()->sekolah); ?></div>
                <div class="author-box-job mt-3 mb-5"><i class="fas fa-address-card"></i> <?php echo e(Auth::user()->bio); ?></div>
          <h4 class="mb-3">LEVEL : <?php echo e(floor($kelas <= 1 ? 1 : $kelas / 2)); ?></h4>
          <div class="mb-4">
            <div class="text-small float-right font-weight-bold text-muted"><?php echo e($kelas); ?></div>
            <div class="font-weight-bold mb-1">EXP</div>
            <div class="progress">
              <div class="progress-bar" role="progressbar" data-width="<?php echo e($kelas); ?>%" aria-valuenow="<?php echo e($kelas); ?>" aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>" style="width: <?php echo e($kelas); ?>%;"><?php echo e($kelas); ?></div>
            </div>
          </div>
          <div class="mb-4">
            <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
            <div class="font-weight-bold mb-1">MEKANIK</div>
            <div class="progress">
              <div class="progress-bar bg-success text-dark" role="progressbar" data-width="<?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>%" aria-valuenow="<?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>" aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>" style="width: <?php echo e($mekanik > 0 ? ($mekanik / 99) * 100 : 0); ?>%;"><?php echo e($mekanik); ?></div>
            </div>
          </div>
          <div class="mb-4">
            <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
            <div class="font-weight-bold mb-1">ELEKTRONIK</div>
            <div class="progress">
              <div class="progress-bar bg-warning text-dark" role="progressbar" data-width="<?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>%" aria-valuenow="<?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>" aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>" style="width: <?php echo e($elektronik > 0 ? ($elektronik / 99) * 100 : 0); ?>%;"><?php echo e($elektronik); ?></div>
            </div>
          </div>
          <div class="mb-4">
            <div class="text-small float-right font-weight-bold text-muted">MAX : 99</div>
            <div class="font-weight-bold mb-1">PEMROGRAMAN</div>
            <div class="progress">
              <div class="progress-bar bg-danger text-dark" role="progressbar" data-width="<?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>%" aria-valuenow="<?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>" aria-valuemin="0" aria-valuemax="<?php echo e(99); ?>" style="width: <?php echo e($pemrograman > 0 ? ($pemrograman / 99) * 100 : 0); ?>%;"><?php echo e($pemrograman); ?></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('siswa.template.mainsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/base_file/resources/views/siswa/dashboard.blade.php ENDPATH**/ ?>
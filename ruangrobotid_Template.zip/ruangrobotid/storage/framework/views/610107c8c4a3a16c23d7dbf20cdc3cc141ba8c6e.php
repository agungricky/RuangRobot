<?php $__env->startSection('title','Gaji Pengajar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Gaji Per Pengajar</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Pengajar</th>
                                    <th>Gaji yang belum dibayarkan</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $dataperpengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($key); ?></td>
                                    <td class="font-weight-bold text-success">Rp <?php echo e(number_format($items)); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Gaji Per Kelas</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped " id="tabelData">
                                <thead>
                                  <tr>
                                      <th>#</th>
                                      <th>Nama Pengajar</th>
                                      <th>Kelas</th>
                                      <th>Kehadiran</th>
                                      <th>Gaji Per Pertemuan</th>
                                      <th>Gaji Total</th>
                                      <th style="width: 190px;">Aksi</th>
                                  </tr>
                                </thead>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td class="font-weight-bold"><?php echo e($item->pengajar->nama_pengajar); ?></td>
                                        <td><?php echo e($item->nama_kelas); ?></td>
                                        <td><?php echo e(Ceksiswa::get_hadir($item->uuid)); ?></td>
                                        <td>Rp <?php echo e(number_format($item->gajipeg)); ?></td>
                                        <td class="text-success font-weight-bold">Rp <?php echo e(number_format(Ceksiswa::get_gaji($item->uuid,$item->gajipeg))); ?></td>
                                        <td>
                                            <?php if($item->sudah_digaji == 1): ?>
                                                <span class="badge badge-primary"><i class="fas fa-check"></i> Sudah Diterima</span>
                                            <?php else: ?>
                                            <form action="<?php echo e(route('admin.gajipengajaraction')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id_kelas" value="<?php echo e($item->id); ?>">
                                                <button type="submit" class="btn btn-sm btn-success tombol-gaji"><i class="fas fa-check"></i> Tandai Menerima</button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
           $('#tabelData').DataTable();
            $('body').on('click', '.tombol-gaji', function(e) {
            e.preventDefault();
            swal.fire({
                title: 'Apakah Anda Yakin?',
                icon : 'question',
                showCancelButton: true,
                confirmButtonText: "Ya",
                cancelButtonText: "Batal"
            }).then((result) => {
                if(result.value){
                    var form = $(this).parents('form');
                    form.submit();
                }
            });
        });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/base_file/resources/views/admin/gajipengajar.blade.php ENDPATH**/ ?>
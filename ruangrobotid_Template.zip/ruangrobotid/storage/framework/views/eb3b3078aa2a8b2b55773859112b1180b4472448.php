<?php $__env->startSection('title', 'Daftar Sertifikat'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="" style="color: #666;font-size:15px;"><?php echo e(ucwords($item->nama_kelas)); ?></h4>
                        <?php if(Ceksiswa::get_grade(Auth::user()->id, $item->id) == 'A'): ?>
                            <span class="badge badge-success"><i class="fas fa-star"></i> Sangat Baik</span>
                        <?php else: ?>
                            <span class="badge badge-info"><i class="fas fa-star"></i> Baik</span>
                        <?php endif; ?>
                        <hr>
                        <a href="<?php echo e(route('siswa.sertifikat_cetak', $item->id)); ?>"
                            class="btn btn-lg btn-block btn-primary"><i class="fas fa-print mr-2"></i>Download
                            Sertifikat</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa.template.mainsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/ruangrobot/resources/views/siswa/sertifikat.blade.php ENDPATH**/ ?>
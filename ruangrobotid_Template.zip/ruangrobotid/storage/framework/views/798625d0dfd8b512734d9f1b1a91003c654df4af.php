<?php $__env->startSection('title', 'Detail Kelas - ' . $kls->nama_kelas); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <button class="btn btn-primary editkelas mb-4 mr-3"><i class="fas fa-edit"></i> Edit Kelas</button>
            <button id="gantibanner" class="btn btn-warning mb-4 mr-3"><i class="fas fa-images"></i> Ganti Banner</button>
            <a href="<?php echo e(route('admin.report_cetak', $id)); ?>" class="btn btn-success mb-4 mr-3"><i class="fas fa-file"></i>
                Generate Report</a>
            <a href="<?php echo e(route('admin.selesaikelas', [$id, $kls->status])); ?>" class="btn btn-info mb-4 mr-3"><i
                    class="fas fa-check"></i> Tandai Kelas Selesai</a>
            <a href="<?php echo e(route('admin.generatecert', $id)); ?>" class="btn btn-success mb-4"><i class="fas fa-print"></i>
                Generate Sertifikat</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="hero text-white hero-bg-image"
                style="background-image: url('<?php echo e($kls->banner != '' ? url('/banner/' . $kls->banner) : url('/img_videogaming.jpg')); ?>');padding:35px;">
                <div class="hero-inner">
                    <h5><?php echo e($kls->nama_kelas); ?></h5>
                    <?php if($kls->jenis_kelas == 'Kelas Privat'): ?>
                        <span class="badge badge-danger"><?php echo e($kls->jenis_kelas); ?></span>
                    <?php elseif($kls->jenis_kelas == 'Kelas Regular'): ?>
                        <span class="badge badge-primary"><?php echo e($kls->jenis_kelas); ?></span>
                    <?php elseif($kls->jenis_kelas == 'Kelas Ekskul'): ?>
                        <span class="badge badge-warning text-dark"><?php echo e($kls->jenis_kelas); ?></span>
                    <?php elseif($kls->jenis_kelas == 'Kelas Lomba'): ?>
                        <span class="badge badge-info"><?php echo e($kls->jenis_kelas); ?></span>
                    <?php elseif($kls->jenis_kelas == 'Kelas Online'): ?>
                        <span class="badge badge-success"><?php echo e($kls->jenis_kelas); ?></span>
                    <?php elseif($kls->jenis_kelas == 'Kelas Mandiri'): ?>
                        <span class="badge text-light" style="background:#9b59b6;"><?php echo e($kls->jenis_kelas); ?></span>
                    <?php endif; ?>
                    <?php if($kls->status == '1'): ?>
                        <span class="ml-2 badge badge-success">Complete</span>
                    <?php else: ?>
                        <span class="ml-2 badge badge-primary">On going</span>
                    <?php endif; ?>
                    <p class="lead"><?php echo e($kls->program_belajar->nama_program_belajar); ?></p>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <p class="card-description"><?php echo e($kls->program_belajar->deskripsi); ?></p>
                    <div class="row">
                        <div class="col-md-6">
                            <ul class="list-group list-group-unbordered">
                                <li class="list-group-item">
                                    <b><i class="fas fa-play-circle"></i> Pertemuan Kelas</b>
                                    <div class="profile-desc-item pull-right"><?php echo e($slot_kelas->count()); ?> Pertemuan</div>
                                </li>
                                <li class="list-group-item">
                                    <b><i class="fas fa-users"></i> Jumlah Siswa</b>
                                    <div class="profile-desc-item pull-right"><?php echo e($siswa->count()); ?> Siswa</div>
                                </li>
                                <li class="list-group-item">
                                    <b><i class="fas fa-user"></i> Pengajar </b>
                                    <div class="profile-desc-item pull-right"><a class="font-weight-bold"
                                            href="<?php echo e(route('profileall', ['pengajar', $kls->pengajar->id])); ?>"><?php echo e($kls->pengajar->nama_pengajar); ?></a>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <b><i class="fas fa-layer-group"></i> Level </b>
                                    <div class="profile-desc-item pull-right">

                                        <?php if($kls->program_belajar->level == 'mudah'): ?>
                                            <span class="badge badge-success"><b>Mudah</b></span>
                                        <?php elseif($kls->program_belajar->level == 'sedang'): ?>
                                            <span class="badge badge-warning"><b>Sedang</b></span>
                                        <?php elseif($kls->program_belajar->level == 'sulit'): ?>
                                            <span class="badge badge-danger"><b>Sulit</b></span>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-group">
                                <li class="list-group-item">
                                    <b><i class="fas fa-dollar-sign"></i> Harga Kelas </b>
                                    <div class="profile-desc-item pull-right text-success">Rp.
                                        <?php echo e(number_format($kls->program_belajar->harga)); ?></div>
                                </li>
                                <li class="list-group-item">
                                    <b><i class="fas fa-dollar-sign"></i> Gaji Pengajar </b>
                                    <div class="profile-desc-item pull-right">Rp. <?php echo e(number_format($kls->gajipeg)); ?> /
                                        Pertemuan</div>
                                </li>
                                <li class="list-group-item">
                                    <b><i class="fas fa-star"></i> Poin Yang Akan Didapatkan </b>
                                    <div class="profile-desc-item pull-right">
                                        <ul class="list-star">
                                            <li>Mekanik : <span style="font-weight:bold"
                                                    class="text-info">+<?php echo e($kls->program_belajar->mekanik); ?></span></li>
                                            <li>Elektronik : <span style="font-weight:bold"
                                                    class="text-success">+<?php echo e($kls->program_belajar->elektronik); ?></span>
                                            </li>
                                            <li>Pemrograman : <span style="font-weight:bold"
                                                    class="text-danger">+<?php echo e($kls->program_belajar->pemrograman); ?></span>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Sesi Kelas</h4>
                </div>
                <div class="card-body">
                    <a href="javascript:void(0)" id="tambah_sesi_kelas" class="btn btn-primary mb-3"><i
                            class="fa fa-plus"></i> Tambah Sesi</a>
                    <div class="table-responsive">
                        <table class="table table-striped table-md" id="table_sesi_kelas">
                            <thead>
                                <tr>
                                    <th style="width: 130px;">Pertemuan Ke</th>
                                    <th>Materi</th>
                                    <th>Tanggal</th>
                                    <th>Jam</th>
                                    <th style="width: 160px;">Selengkapnya</th>
                                    <th style="width: 160px;">Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Siswa</h4>
                </div>
                <div class="card-body">
                    <a href="javascript:void(0)" class="btn btn-primary mb-3 tambahsiswakelas"><i class="fa fa-plus"></i>
                        Tambah Siswa</a>
                    <div class="table-responsive">
                        <table class="table table-striped" id="tabelsiswa">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">No</th>
                                    <th>Nama</th>
                                    <th>Sekolah</th>
                                    <th>Presentase Kehadiran</th>
                                    <th>Poin</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><a class="font-weight-bold"
                                            href="<?php echo e(route('profileall', ['siswa', $users->id])); ?>"><?php echo e($users->nama_siswa); ?></a>
                                    </td>
                                    <td><?php echo e($users->sekolah); ?></td>
                                    <td>
                                        <div class="progress mb-2" data-height="4">
                                            <div class="progress-bar bg-gradient-success" role="progressbar"
                                                style="width: <?php echo e(Ceksiswa::cek_percentage($users->id, $kls->uuid, $slot_kelas->count())); ?>"
                                                aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <?php echo e(Ceksiswa::cek_percentage($users->id, $kls->uuid, $slot_kelas->count())); ?>

                                    </td>
                                    <td style="font-size: 11px;">
                                        <?php echo Ceksiswa::get_poin($users->id, $id); ?>

                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.listsiswadelete')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id_kelas" value="<?php echo e($id); ?>">
                                            <input type="hidden" name="id_siswa" value="<?php echo e($users->id); ?>">
                                            <button type="submit" onclick=""
                                                class="btn btn-danger btn-sm removesiswa" data-toggle="tooltip"
                                                data-placement="top" title="Hapus Siswa Dari Kelas"><i
                                                    class="fas fa-trash"></i> Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="edit_banner" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title">Edit Banner</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="" action="<?php echo e(route('admin.uploadbanneraction')); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_kelas" value="<?php echo e($id); ?>">
                        <input type="hidden" name="old_image" value="<?php echo e($kls->banner); ?>">
                        <input type="file" class="form-control" name="banner_gambar">
                        <button type="submit" name="button" class="btn btn-primary mt-3"><i class="fas fa-save"></i>
                            Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="tambah_tanggal_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title">Tambah Sesi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" id="form_tambah_sesi">
                        <input type="hidden" name="id_kelas" value="<?php echo e($kls->uuid); ?>">
                        <input type="date" name="tanggal_sesinya" class="form-control">
                        <div class="row">
                            <div class="col-md-6 mt-2">
                                <span>Jam Mulai</span>
                                <input name="jamm" type="text" class="form-control mt-2 timepicker"
                                    placeholder="Jam Mulai">
                            </div>
                            <div class="col-md-6 mt-2">
                                <span>Jam Selesai</span>
                                <input name="jams" type="text" class="form-control mt-2 timepicker"
                                    placeholder="Jam Selesai">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3" id="simpan_tambah_sesi">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="edit_tanggal_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title-edit-tanggal">Edit Sesi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" id="form_edit_sesi">
                        <input type="hidden" name="id_sesinya" id="id_sesinya">
                        <input type="date" name="tanggal_sesinya" id="tanggal_sesinya" class="form-control">
                        <div class="row">
                            <div class="col-md-6 mt-2">
                                <span>Jam Mulai</span>
                                <input id="jamm" name="jamm" type="text" class="form-control mt-2 timepicker"
                                    placeholder="Jam Mulai">
                            </div>
                            <div class="col-md-6 mt-2">
                                <span>Jam Selesai</span>
                                <input id="jams" name="jams" type="text" class="form-control mt-2 timepicker"
                                    placeholder="Jam Selesai">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3" id="simpan_edit_sesi">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-fullscreen" id="detailmodal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail Kelas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <b><i class="fas fa-user"></i> Pengajar </b>
                            <div class="profile-desc-item pull-right">
                                <?php echo e($kls->pengajar->nama_pengajar); ?>

                            </div>
                        </li>
                        <li class="list-group-item">
                            <b><i class="fas fa-clock"></i> Waktu Pertemuan </b>
                            <div class="profile-desc-item pull-right">
                                <span id="gettanggalnya"></span>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <b><i class="fas fa-book"></i> Materi </b>
                            <div class="profile-desc-item pull-right">
                                <b class="isimateri"></b>
                            </div>
                        </li>
                    </ul>
                    <h6 class="mt-3 mb-3">Siswa Yang Hadir :</h6>
                    <div class="inimasuksiswahadir"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="ajaxModall" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog mw-100 w-50" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Siswa Kedalam Kelas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="p-3">
                            <table class="table table-striped" id="tabelData2">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Sekolah</th>
                                        <th>Tanggal Lahir</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                            <hr>
                            <form id="form-tambahkelas" action="<?php echo e(route('admin.listsiswasave')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_kelas" value="<?php echo e($id); ?>">
                                <div id="dalamidnya"></div>
                                <button id="tambahkelastombol" type="submit" class="btn btn-primary">Tambahkan Ke
                                    Kelas</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="inputForm">
                    <input type="hidden" name="id_kelas" id="id_kelas">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="jadwal">Nama kelas</label>
                            <input type="text" class="form-control" id="nama_kelas" placeholder="Nama kelas"
                                name="nama_kelas">
                        </div>
                        <div class="form-group">
                            <label for="jeniskelas">Jenis Kelas</label>
                            <select name="jenis_kelas" id="jeniskelas" class="form-control">
                                <option value="Kelas Privat">Kelas Privat</option>
                                <option value="Kelas Regular">Kelas Regular</option>
                                <option value="Kelas Ekskul">Kelas Ekskul</option>
                                <option value="Kelas Lomba">Kelas Lomba</option>
                                <option value="Kelas Online">Kelas Online</option>
                                <option value="Kelas Mandiri">Kelas Mandiri</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="jadwal">Program Belajar</label>
                            <select name="program_belajar_id" id="program_belajar" class="form-control">
                                <?php $__currentLoopData = $program_belajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pb->id); ?>"><?php echo e($pb->nama_program_belajar); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="pengajar">Pengajar</label>
                            <select name="pengajar_id" id="pengajar" class="form-control">
                                <?php $__currentLoopData = $pengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pb->id); ?>"><?php echo e($pb->nama_pengajar); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="jadwal">Gaji/Pertemuan</label>
                            <input type="text" class="form-control" id="gaji" placeholder="Gaji"
                                name="gaji">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" id="saveBtn"><i
                                class="fas fa-save btn-icon-append"></i> Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-fs-modal.min.css')); ?>">
    <style>
        .labela {
            width: 100%;
        }

        .card-input-element+.card {
            -webkit-box-shadow: none;
            box-shadow: none;
            border-left: 4px solid #f8f8f8;
            /* border-radius: 4px; */
        }

        .card-input-element+.card:hover {
            cursor: pointer;
        }

        .card-input-element:checked+.card {
            border-left: 4px solid #28a745 !important;
            -webkit-transition: border .3s;
            -o-transition: border .3s;
            transition: border .3s;
        }

        .card-input-element+.card i {
            color: #f8f8f8;
        }

        .card-input-element:checked+.card i {
            color: #28a745 !important;
        }

        @-webkit-keyframes fadeInCheckbox {
            from {
                opacity: 0;
                -webkit-transform: rotateZ(-20deg);
            }

            to {
                opacity: 1;
                -webkit-transform: rotateZ(0deg);
            }
        }

        @keyframes  fadeInCheckbox {
            from {
                opacity: 0;
                transform: rotateZ(-20deg);
            }

            to {
                opacity: 1;
                transform: rotateZ(0deg);
            }
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('timepicki/bootstrap-clockpicker.min.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('timepicki/bootstrap-clockpicker.min.js')); ?>"></script>
    <style type="text/css">
        .popover {
            border: 1px solid #ccc;
        }
    </style>
    <script>
        $(function() {
            // $('.timepicker').timepicki();
            $(document).on('focus', '.timepicker', function() {
                $(this).clockpicker({
                    placement: 'left',
                    align: 'left',
                    autoclose: true,
                    default: 'now',
                    donetext: "Select"
                });
            });
        });
    </script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select.dataTables.min.css')); ?>">
    <script src="<?php echo e(asset('assets/js/dataTables.select.min.js')); ?>"></script>
    <script>
        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $('#tabelsiswa').DataTable({
                paging: true,
                ordering: true,
                searching: true,
            });
            var table23 = $('#table_sesi_kelas').DataTable({
                processing: true,
                serverSide: true,
                paging: false,
                ordering: true,
                searching: false,
                ajax: "<?php echo e(route('admin.listsiswasesiajax', $id)); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'materi',
                        name: 'materi'
                    },
                    {
                        data: 'hari_tanggal',
                        name: 'hari_tanggal'
                    },
                    {
                        data: 'jam',
                        name: 'jam'
                    },
                    {
                        data: 'selengkapnya',
                        name: 'selengkapnya'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });
            $('#gantibanner').click(function() {
                $('#edit_banner').modal('show');
            })
            $('#tambah_sesi_kelas').click(function() {
                $('#tambah_tanggal_modal').modal('show');
            });
            $('#simpan_tambah_sesi').click(function(e) {
                e.preventDefault();
                $(this).html('Menyimpan..');
                $.ajax({
                    data: $('#form_tambah_sesi').serialize(),
                    url: "<?php echo e(route('admin.savetambahedsesi')); ?>",
                    type: 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#tambah_tanggal_modal').trigger('reset');
                        $('#tambah_tanggal_modal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil menambah sesi',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        table23.draw();
                    },
                    error: function(data) {
                        console.log('Error: ', data);
                        $('#simpan_tambah_sesi').html('Simpan');
                    }
                })
            });

            $('body').on('click', '.edit_tanggal_btn', function() {
                $('#id_sesinya').val($(this).data('id'));
                $('#tanggal_sesinya').val($(this).data('tanggal'));
                $('#jamm').val($(this).data('jamm'));
                $('#jams').val($(this).data('jams'));
                $('#edit_tanggal_modal').modal('show');
            });
            $('#simpan_edit_sesi').click(function(e) {
                e.preventDefault();
                $(this).html('Menyimpan..');
                $.ajax({
                    data: $('#form_edit_sesi').serialize(),
                    url: "<?php echo e(route('admin.saveeditedsesi')); ?>",
                    type: 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#edit_tanggal_modal').trigger('reset');
                        $('#edit_tanggal_modal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil mengupdate sesi',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        table23.draw();
                    },
                    error: function(data) {
                        console.log('Error: ', data);
                        $('#simpan_edit_sesi').html('Simpan');
                    }
                });
            });

            $('body').on('click', '.selesait', function(e) {
                e.preventDefault();
                let id = $(this).data('id');
                let id_kelas = $(this).data('kelas');
                let nama = $(this).data('nama');
                Swal.fire({
                    title: 'Selesaikan ' + nama + '?',
                    text: "Dengan Klik YA Siswa Dianggap Menyelesaikan Kelas",
                    icon: 'warning',
                    html: '<div class="form-group row d-flex justify-content-center align-items-center"><h4 class="col-md-12">Nilai :</h4><div class="col-md-2"><div class="form-check"><label class="form-check-label"><input type="radio" class="form-check-input" name="poinsiswa" id="radionilai1" value="A" checked=""> A <i class="input-helper"></i></label></div></div><div class="col-md-2"><div class="form-check"><label class="form-check-label"><input type="radio" class="form-check-input" name="poinsiswa" id="radionilai2" value="B"> B <i class="input-helper"></i></label></div></div></div>',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Selesai!',
                    cancelButtonText: "Batal!",
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            type: 'POST',
                            url: "<?php echo e(route('admin.selesaisiswa')); ?>",
                            data: {
                                id_siswa: id,
                                id_kelas: id_kelas,
                                nilai: $('input[name=poinsiswa]:checked').val(),
                            },
                            success: function(data) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Data telah diupdate',
                                    showConfirmButton: false,
                                    timer: 1500
                                });
                                window.location.reload();
                            },
                            error: function(data) {
                                console.log('Error: ', data);
                            }
                        })
                    }
                })
            })

            $('body').on('click', '.detailbutton', function() {
                $('#detailmodal').modal('show');
                $('#gettanggalnya').html($(this).data('hari') + ', ');
                $('#gettanggalnya').append($(this).data('tanggal'));
                $('.isimateri').html($(this).data('materi'));
                let id_sesi = $(this).data('id');
                $.ajax({
                    url: '<?php echo e(route('admin.getdetailsesi')); ?>',
                    type: 'GET',
                    data: {
                        id: id_sesi,
                        id_kelas: <?php echo e($id); ?>

                    },
                    success: function(data) {
                        $('.inimasuksiswahadir').html(data);
                    }
                })
            })

            var table2 = $('#tabelData2').DataTable({
                "autoWidth": false,
                columnDefs: [{
                    orderable: false,
                    targets: 0
                }],
                select: {
                    style: 'multi'
                },
                order: [
                    [1, 'asc']
                ],
                processing: true,
                serverSide: true,
                paging: true,
                ordering: false,
                searching: true,
                ajax: "<?php echo e(route('siswa.index')); ?>",
                columns: [
                    // {data: 'id', name: 'id'},
                    {
                        data: 'nama_siswa',
                        name: 'nama_siswa'
                    },
                    {
                        data: 'sekolah',
                        name: 'sekolah'
                    },
                    {
                        data: 'tgl_lahir',
                        name: 'tgl_lahir'
                    },
                ]
            });
            $('body').on('click', '.tambahsiswakelas', function() {
                $('#ajaxModall').modal('show');
                table2.draw();
            });
            $('body').on('click', '#tabelData2 tbody tr', function() {
                let forme = $('#form-tambahkelas #dalamidnya');
                let data2 = table2.rows({
                    selected: true
                }).data();
                $(forme).empty();
                $.each(data2, function name(index, id) {
                    $(forme).append(
                        $('<input>').attr('type', 'hidden').attr('name', 'id[]').val(data2[
                            index].id)
                    )
                });
            });
            $('body').on('click', '.editkelas', function() {
                $.get("<?php echo e(route('kelas.index')); ?>" + '/' + <?php echo e($id); ?> + '/edit', function(data) {
                    $('#ajaxModal').modal('show');
                    $('.modal-title').html('Edit kelas');
                    $('#id_kelas').val(data.id);
                    $('#nama_kelas').val(data.nama_kelas);
                    $('#jeniskelas').val(data.jenis_kelas);
                    $("#program_belajar").val(data.program_belajar_id);
                    $("#gaji").val(data.gajipeg);
                    $("#pengajar").val(data.pengajar_id);
                    $("#slot").val(data.slot);
                    $('#saveBtn').val('edit');
                    $('#saveBtn').html('Simpan');
                })
            });
            $('#saveBtn').click(function(e) {
                e.preventDefault();
                $(this).html('Menyimpan..');
                $.ajax({
                    data: $('#inputForm').serialize(),
                    url: "<?php echo e(route('kelas.storetwo')); ?>",
                    type: 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#ajaxModal').trigger('reset');
                        $('#ajaxModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil menyimpan',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        window.location.reload();
                    },
                    error: function(data) {
                        console.log('Error: ', data);
                        $('#saveBtn').html('Simpan');
                    }
                });
            });
            $('body').on('click', '.removesiswa', function(e) {
                e.preventDefault();
                swal.fire({
                    title: 'Hapus siswa dari Kelas?',
                    text: 'Data yang dihapus tidak bisa dikembalikan',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: "Ya",
                    confirmButtonColor: "#e74c3c",
                    cancelButtonText: "Batal"
                }).then((result) => {
                    if (result.value) {
                        var form = $(this).parents('form');
                        form.submit();
                    }
                });
            });
            $('body').on('click', '.deleteslot', function(e) {
                e.preventDefault();
                swal.fire({
                    title: 'Hapus sesi Kelas?',
                    text: 'Data yang dihapus tidak bisa dikembalikan',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: "Ya",
                    confirmButtonColor: "#e74c3c",
                    cancelButtonText: "Batal"
                }).then((result) => {
                    if (result.value) {
                        // var form = $(this).parents('form');
                        // form.submit();
                        window.location.href = $(this).attr('href');
                    }
                });
            });

        });
    </script>
    <?php if(\Session::has('success')): ?>
        <script>
            $(function() {
                swal.fire({
                    icon: 'success',
                    title: "<?php echo e(Session::get('success')); ?>",
                    timer: 1500,
                    showConfirmButton: false
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.mainadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ruangro2/public_html/ruangrobot/resources/views/admin/listsiswa.blade.php ENDPATH**/ ?>
<?php

use Illuminate\Database\Seeder;
use App\Pengajar;
class PengajarTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Pengajar::create([
            'nama_pengajar'=>Str::random(10),
            'gaji'=>5000,
            'username'=>'pengajar@app.com',
            'password'=>bcrypt('password')
            ]);
    }
}

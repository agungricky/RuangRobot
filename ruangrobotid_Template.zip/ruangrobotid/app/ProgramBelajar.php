<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramBelajar extends Model
{
    protected $table = 'program_belajar';
    protected $fillable = ['nama_program_belajar','harga','deskripsi','level','mekanik','elektronik','pemrograman'];
    public function kelas()
    {
        return $this->hasOne('App\Kelas');
    }
}

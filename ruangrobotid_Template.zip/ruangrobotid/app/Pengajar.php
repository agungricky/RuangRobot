<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pengajar extends Model
{
    protected $table = 'pengajar';
    protected $fillable = ['nama_pengajar','alamat','notlep','username','password','real_passwd'];
    public function kelas()
    {
        return $this->hasOne('App\Kelas');
    }
}

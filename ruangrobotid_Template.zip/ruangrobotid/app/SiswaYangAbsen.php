<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiswaYangAbsen extends Model
{
    protected $table = 'siswa_yang_absen';
    protected $fillable = ['id','id_sesi','uuid','id_siswa','nama','sekolah'];
    public $timestamps = false;
}

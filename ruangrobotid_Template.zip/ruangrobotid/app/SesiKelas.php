<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SesiKelas extends Model
{
    protected $table = 'sesi_kelas';
    protected $fillable = ['id','id_kelas','materi','tanggal','jamm','jams'];
    public $timestamps = false;
}

<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Siswa extends Authenticatable
{
    protected $guard = 'siswa';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'siswa';
    protected $fillable = [
        'nama_siswa', 'alamat', 'notlep', 'email', 'password','password_real',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
   }
<?php

namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Pengajar extends Authenticatable
{
    protected $guard = 'pengajar';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'pengajar';
    protected $fillable = [
        'nama_pengajar','gaji','username', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'real_passwd','password', 'remember_token',
    ];
}

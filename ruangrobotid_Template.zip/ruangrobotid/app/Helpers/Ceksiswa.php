<?php

namespace App\Helpers;

use Illuminate\Support\Facades\DB;
use App\SelectedClass;
use App\Kelas;
use App\Siswa;
use Auth;

class Ceksiswa
{
    public static function cek_konfirmasi()
    {
        return DB::table('pembayaran')->where(['status' => 'Menunggu Konfirmasi'])->count();
    }
    public static function get_detail_pembayaran($id, $apa)
    {
        $user = DB::table('selected_class')->where(['id' => $id])->first();
        $kelas = Kelas::with(['program_belajar'])->where('id', $user->id_kelas)->first();
        // dd($kelas);
        if ($apa == 'nama') {
            return $kelas['nama_kelas'];
        } else if ($apa == 'pb') {
            return $kelas['program_belajar']['harga'];
        } else if ($apa == 'nama_siswa') {
            $s = DB::table('siswa')->where(['id' => $user->id_siswa])->first();
            return $s->nama_siswa ?? "";
        } else if ($apa == 'mk') {
            $s = DB::table('pembayaran')->where(['id_selected_class' => $id, 'status' => 'Menunggu Konfirmasi'])->count();
            return $s;
        } else if ($apa == 'mk2') {
            $s = DB::table('pembayaran')->where(['id_selected_class' => $id])->count();
            return $s;
        }
    }
    public static function get_status($user_id, $class_id)
    {
        $user = DB::table('selected_class')->where(['id_siswa' => $user_id, 'id_kelas' => $class_id])->first();
        return $user->selesai;
    }
    public static function cek_selesai($id_kelas)
    {
        $selected = SelectedClass::where(['id_siswa' => Auth::user()->id, 'id_kelas' => $id_kelas])->first();
        return $selected->selesai;
    }
    public static function cek_score($id_siswa, $id_kelas)
    {
        $sesi_hadir = DB::table('selected_class')->where(['id_kelas' => $id_kelas, 'id_siswa' => $id_siswa])->first('nilai')->nilai;
        return $sesi_hadir;
    }
    public static function cek_percentage($id_siswa, $uuid, $slot)
    {
        $sesi_hadir = DB::table('siswa_yang_absen')->where(['uuid' => $uuid, 'id_siswa' => $id_siswa])->count();
        if ($sesi_hadir == 0 || $slot == 0) {
            return "0%";
        }
        return (round(($sesi_hadir / $slot) * 100)) . '%';
    }
    public static function cek_percentage2($id_siswa, $id_kelas)
    {
        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id_kelas);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->count();
        $sesi_hadir = DB::table('siswa_yang_absen')->where(['uuid' => $kelas->uuid, 'id_siswa' => $id_siswa])->count();
        return (round(($sesi_hadir / $slot_kelas) * 100)) . '%';
    }

    public static function get_poin($user_id, $class_id)
    {
        $user = DB::table('selected_class')->where(['id_siswa' => $user_id, 'id_kelas' => $class_id])->first();
        if ($user->selesai == 'false') {
            return '<b style="color:orange;">Kelas Belum Selesai</b>';
        } else {
            return '<b style="color:green;">M : +' . $user->mekanik . ' <span class="bullet"></span> E : +' . $user->elektronik . ' <span class="bullet"></span> P : +' . $user->pemrograman . '</b>';
        }
    }
    public static function cekpoint_all($user_id)
    {
        $user = SelectedClass::where(['id_siswa' => $user_id, 'selesai' => true])->get();
        $mekanik = $elektronik = $pemrograman = 0;
        foreach ($user as $poin) {
            $mekanik      += $poin->mekanik;
            $pemrograman  += $poin->pemrograman;
            $elektronik  += $poin->elektronik;
        }
        return $mekanik + $elektronik + $pemrograman;
    }
    public static function cek_pembayaran_siswa()
    {
        return SelectedClass::where(['id_siswa' => Auth::user()->id, 'sudahbayar' => '0'])->count();
    }
    public static function check_point($user_id, $mana)
    {
        $user = SelectedClass::where(['id_siswa' => $user_id, 'selesai' => true])->get();
        $mekanik = $elektronik = $pemrograman = 0;
        foreach ($user as $poin) {
            $mekanik      += $poin->mekanik;
            $pemrograman  += $poin->pemrograman;
            $elektronik  += $poin->elektronik;
        }
        if ($mana == 'mekanik') {
            return $mekanik;
        } else if ($mana == 'pemrograman') {
            return $pemrograman;
        } else {
            return $elektronik;
        }
    }
    public static function ceksiswahadir($id_siswa, $id_sesi)
    {
        // $arr = SelectedClass::where('id_kelas', $id_kelas)->pluck('id_siswa')->toArray();
        $sesihadir = DB::table('siswa_yang_absen')->where('id_sesi', $id_sesi)->pluck('id_siswa')->toArray();
        if (in_array($id_siswa, $sesihadir)) {
            return 'hadir';
        } else {
            return 'thadir';
        }
    }
    public static function isdate_terlewat($date, $materi)
    {
        $current = strtotime(date("d-m-Y"));
        $date    = strtotime($date);
        $datediff = $date - $current;
        $difference = floor($datediff / (60 * 60 * 24));

        if ($difference < 0 && $materi == '') {
            return 'Tidak Absen';
        } else if ($difference > 0 && $materi == '') {
            return 'Belum Waktunya';
        } else if ($difference < 0 && $materi != '') {
            return 'Sudah Absen';
        } else if ($difference == 0 && $materi != '') {
            return 'Sudah Absen hi';
        } else if ($difference == 0 && $materi == '') {
            return 'Silahkan Absen Sekarang';
        }
    }
    public static function cek_pembayaran($id_siswa, $id_kelas)
    {
        $user = DB::table('selected_class')->where(['id_siswa' => $id_siswa, 'id_kelas' => $id_kelas])->first();
        if ($user->sudahbayar == 0) {
            return 'Belum Bayar';
        } else if ($user->sudahbayar == 1) {
            return 'Lunas';
        } else if ($user->sudahbayar == 2) {
            return 'Nyicil';
        }
    }
    public static function get_id($id_siswa, $id_kelas)
    {
        $user = DB::table('selected_class')->where(['id_siswa' => $id_siswa, 'id_kelas' => $id_kelas])->first();
        return $user->id;
    }
    public static function get_hadir($uuid)
    {
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $uuid)->orderBy('tanggal')->get();
        $hadir = 0;
        foreach ($slot_kelas as $sesi) {
            if ($sesi->materi != NULL) {
                $hadir++;
            }
        }
        return $hadir . ' dari ' . $slot_kelas->count() . ' Pertemuan';
    }
    public static function get_gaji($uuid, $gajipeg)
    {
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $uuid)->orderBy('tanggal')->get();
        $gaji = 0;
        foreach ($slot_kelas as $sesi) {
            if ($sesi->materi != NULL) {
                $gaji = $gaji + $gajipeg;
            }
        }
        return $gaji;
    }
    public static function get_grade($id_siswa, $id_kelas)
    {
        $user = DB::table('selected_class')->where(['id_siswa' => $id_siswa, 'id_kelas' => $id_kelas, 'selesai' => 'true'])->first();
        return $user->nilai;
    }
    public static function cekabsenaa($id_siswa, $id_sesi)
    {
        $sesihadir = DB::table('siswa_yang_absen')->where('id_sesi', $id_sesi)->pluck('id_siswa')->toArray();
        if (in_array($id_siswa, $sesihadir)) {
            echo '<td style="background:green"></td>';
        } else {
            echo '<td style="background:red"></td>';
        }
    }
    public static function getabsennya($id, $id_kelas)
    {
        $arr = SelectedClass::where('id_kelas', $id_kelas)->pluck('id_siswa')->toArray();
        $siswa = Siswa::whereIn('id', $arr)->get();

        $sesihadir = DB::table('siswa_yang_absen')->where('id_sesi', $id)->pluck('id_siswa')->toArray();
        foreach ($siswa as $hadir) {
            if (in_array($hadir->id, $sesihadir)) {
                echo '<tr>
                <td>' . $hadir->nama_siswa . '</td>
                <td>HADIR</td>
                </tr>';
            } else {
                echo '<tr>
                <td>' . $hadir->nama_siswa . '</td>
                <td>TIDAK HADIR</td>
                </tr>';
            }
        }
    }
    public static function cek_nama_siswa($id)
    {
        $sel = DB::table('selected_class')->where('id', $id)->first();
        return Siswa::where('id', $sel->id_siswa)->first('nama_siswa')->nama_siswa ?? "";
    }
    public static function get_kelas($id_kelas)
    {
        return Kelas::with('pengajar')->where('uuid', $id_kelas)->first();
    }
    public static function cek_get_poin($id_kelas, $where)
    {
        $selected = SelectedClass::where(['id_siswa' => Auth::user()->id, 'id_kelas' => $id_kelas])->first();
        if ($where == 'mekanik') {
            return $selected->mekanik;
        } else if ($where == 'elektronik') {
            return $selected->elektronik;
        } else if ($where == 'pemrograman') {
            return $selected->pemrograman;
        }
    }
}

<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Kelas;
use App\Pengajar;
use App\Siswa;
use App\ProgramBelajar;
use App\SelectedClass;
use Auth;
use DB;
use GDText\Box;
use GDText\Color;
use App\Helpers\Ceksiswa;
use Hash;
use PDF;
use Carbon\Carbon;
use Image;

class SiswaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:siswa');
    }
    public function index()
    {
        $user = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => true])->get();
        $mekanik = $elektronik = $pemrograman = 0;
        foreach ($user as $poin) {
            $mekanik      += $poin->mekanik;
            $pemrograman  += $poin->pemrograman;
            $elektronik  += $poin->elektronik;
        }
        $max = max($mekanik, $elektronik, $pemrograman);

        $selected = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => 'true'])->pluck('id_kelas')->toArray();
        $selected2 = SelectedClass::where(['id_siswa' => Auth::user()->id])->pluck('id_kelas')->toArray();
        $kelas = Kelas::whereIn('id', $selected)->count();
        $kelas2 = Kelas::whereIn('id', $selected2)->count();

        return view('siswa.dashboard', compact('kelas', 'kelas2', 'mekanik', 'elektronik', 'pemrograman', 'max'));
    }
    public function jadwal()
    {
        // sesi
        $selectedaa = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => 'false'])->pluck('id_kelas')->toArray();
        $kelas_sesi = Kelas::whereIn('id', $selectedaa)->pluck('uuid')->toarray();

        // $kemarin = strtotime('-1 day', strtotime(now()));
        $jadwal = DB::table('sesi_kelas')->selectRaw('date(tanggal) tanggal')
            ->whereIn('id_kelas', $kelas_sesi)
            ->where('tanggal', '>=', Carbon::yesterday())
            ->groupBy(DB::raw('date(tanggal)'))
            ->orderBy('tanggal', 'ASC')->get();
        $perhari = [];
        foreach ($jadwal as $key => $valuess) {
            $aa = [];
            $users = DB::table('sesi_kelas')->whereIn('id_kelas', $kelas_sesi)->whereRaw("date(tanggal) = '$valuess->tanggal'")->get();
            foreach ($users as $key => $value) {
                $nama_kelas = Kelas::where('uuid', $value->id_kelas)->first('nama_kelas')->nama_kelas;
                $aa = array_merge($aa, [$nama_kelas . '*' . $value->jamm . ' - ' . $value->jams]);
            }
            $perhari = array_merge($perhari, [$valuess->tanggal => $aa]);
        }
        return view('siswa.jadwal', compact('perhari'));
    }
    public function daftarkelas()
    {
        $selected = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => 'false'])->pluck('id_kelas')->toArray();
        $selected2 = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => 'true'])->where('nilai', '!=', 'C')->pluck('id_kelas')->toArray();
        $selected3 = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => 'true'])->where('nilai', 'C')->pluck('id_kelas')->toArray();

        $kelasongoing = Kelas::with('pengajar', 'program_belajar')->whereIn('id', $selected)->get();
        $kelascomplete = Kelas::with('pengajar', 'program_belajar')->whereIn('id', $selected2)->get();
        $kelasgagal = Kelas::with('pengajar', 'program_belajar')->whereIn('id', $selected3)->get();
        return view('siswa.daftarkelas', compact('kelasongoing', 'kelascomplete', 'kelasgagal'));
    }
    public function detail_kelas($id)
    {
        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();
        $feedback = DB::table('feedback_siswa')->where(['id_kelas' => $id, 'id_siswa' => Auth::user()->id])->get();
        return view('siswa.detail-siswa', compact('kelas', 'slot_kelas', 'feedback'));
    }
    public function feedback_save(Request $request)
    {
        DB::table('feedback_siswa')->insert([
            'id_kelas' => $request->id_kelas,
            'id_siswa' => Auth::user()->id,
            'isi_feedback' => $request->isi_feedback,
            'stars' => $request->emotion,
        ]);
        return redirect()->back()->with('status', 'Berhasil Mengirim Feedback');
    }
    public function pembayaran()
    {
        // $selected = SelectedClass::where(['id_siswa'=>Auth::user()->id])->pluck('id_kelas')->toArray();

        $kelas = SelectedClass::where(['id_siswa' => Auth::user()->id])->orderBy('id', 'desc')->get();
        return view('siswa.pembayaran', compact('kelas'));
    }
    public function upload_bukti($id)
    {
        $kelas_bayar = DB::table('selected_class')->where(['id' => $id])->first();
        $list_bayar = DB::table('pembayaran')->where(['id_selected_class' => $id])->get();
        $kelas = Kelas::with('program_belajar')->find($kelas_bayar->id_kelas);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get('tanggal')->toArray();

        $totalComentarios = count($slot_kelas);
        $mitadComentarios = (int)ceil($totalComentarios / 2);
        $slice = array_slice($slot_kelas, $mitadComentarios - 1, 1);
        $slice = $slice[0]->tanggal;
        return view('siswa.uploadbukti', compact('kelas_bayar', 'list_bayar', 'kelas', 'slot_kelas', 'slice', 'id'));
    }
    public function upload_bukti_action(Request $request)
    {
        $file = $request->file('image');

        $nama_file = time() . "_" . $file->getClientOriginalName();

        $destinationPath = './data_file';
        $img = Image::make($file->getRealPath());
        $img->resize(200, 200, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath . '/' . $nama_file);
        // $tujuan_upload = 'data_file';
        // $file->move($tujuan_upload,$nama_file);

        DB::table('pembayaran')->insert([
            'invoice' => '',
            'manual' => 'N',
            'jumlah' => $request->jumlah,
            'bukti_pembayaran' => $nama_file,
            'status' => 'Menunggu Konfirmasi',
            'id_selected_class' => $request->id_selected_class,
            'tanggal_bayar' => NOW()
        ]);

        return redirect()->back()->with('success', 'Berhasil');
    }
    public function cetak_pdf($id, $tempo)
    {
        $kelas_bayar = DB::table('selected_class')->where(['id' => $id])->first();
        $list_bayar = DB::table('pembayaran')->where(['id_selected_class' => $id])->get();
        $kelas = Kelas::with('program_belajar')->find($kelas_bayar->id_kelas);
        $siswa = Siswa::whereId($kelas_bayar->id_siswa)->first();
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get('tanggal')->toArray();

        $pdf = PDF::loadview('pdf', compact('kelas_bayar', 'list_bayar', 'kelas', 'siswa', 'slot_kelas', 'id', 'tempo'));
        // return $pdf->stream();
        return $pdf->download('INV-' . date('dmY') . '-' . $siswa->id . $kelas->id . '.pdf');
    }
    function tanggal_indo($tanggal)
    {
        $bulan = array(
            1 =>   'Januari',
            'Februari',
            'Maret',
            'April',
            'Mei',
            'Juni',
            'Juli',
            'Agustus',
            'September',
            'Oktober',
            'November',
            'Desember'
        );
        $split = explode('-', $tanggal);
        return $split[2] . ' ' . $bulan[(int)$split[1]] . ' ' . $split[0];
    }
    public function list_sertifikat()
    {
        $selected = SelectedClass::where(['id_siswa' => Auth::user()->id, 'selesai' => 'true'])->where('nilai', '!=', 'C')->pluck('id_kelas')->toArray();
        $kelas = Kelas::with('pengajar', 'program_belajar')->whereIn('id', $selected)->get();
        return view('siswa.sertifikat', compact('kelas'));
    }
    public function sertifikat($kelas_id)
    {
        $kelas = Kelas::with('pengajar', 'program_belajar')->where('id', $kelas_id)->first();
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();


        $im = imagecreatefromjpeg('assets/certificate.jpg');


        // set bulan
        $array_bln    = array(1 => "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII");
        $bln        = $array_bln[date('n')];
        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(24);
        $box->setBox(680, 240, 450, 120);
        // $box->enableDebug();
        $box->setTextAlign('center', 'top');
        $box->draw("No : " . $kelas_id . "/RUANGROBOT/" . $bln . "/" . date('Y') . "\n\nDIBERIKAN KEPADA :");


        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(55);
        $box->setBox(500, 330, 800, 160);
        $box->setTextAlign('center', 'center');
        $box->draw(ucwords(Auth::user()->nama_siswa));

        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(24);
        $box->setBox(500, 490, 800, 200);
        $box->setTextAlign('center', 'top');
        $box->draw('Telah menyelesaikan pelatihan ' . strtoupper($kelas->program_belajar->nama_program_belajar) . ' di Ruang Robot yang dilaksanakan pada tanggal ' . $this->tanggal_indo(date('Y-m-d', strtotime($slot_kelas->first()->tanggal))) . ' - ' . $this->tanggal_indo(date('Y-m-d', strtotime($slot_kelas->last()->tanggal))) . ' dengan predikat');

        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(25);
        $box->setStrokeColor(new Color(0, 0, 0)); // Set stroke color
        $box->setStrokeSize(.6); // Stroke size in pixels
        $box->setBox(750, 610, 300, 70);
        $box->setTextAlign('center', 'center');
        $box->draw((Ceksiswa::get_grade(Auth::user()->id, $kelas_id) == 'A') ? 'SANGAT BAIK' : 'BAIK');

        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(25);
        $box->setBox(880, 690, 400, 460);
        $box->setTextAlign('center', 'top');
        $box->draw("Kediri, " . $this->tanggal_indo(date('Y-m-d', strtotime($slot_kelas->last()->tanggal))) . "\nRuang Robot\n\n\n\n\nJulian Sahertian, S.Pd., M.T.");

        header("Content-type: image/jpeg");
        header("Cache-Control: no-store, no-cache");
        $nama_ser = $kelas_id . "_" . $kelas->nama_kelas . '_' . ucwords(Auth::user()->nama_siswa);
        header('Content-Disposition: attachment; filename="' . $nama_ser . '.jpeg"');
        imagejpeg($im);
    }

    public function profil()
    {
        return view('siswa.profil');
    }
    public function profil_save(Request $request)
    {
        $id = Auth::user()->id;
        $siswa = Siswa::find($id);
        $siswa->nama_siswa = $request->nama_siswa;
        $siswa->bio = $request->bio;
        $siswa->notlep = $request->notlep;
        $siswa->sekolah = $request->sekolah;
        $siswa->tgl_lahir = $request->tgl_lahir;
        $siswa->alamat = $request->alamat;
        // $siswa->username = $request->username;
        if ($request->password != '')
            $siswa->password_real = $request->password;
        $siswa->password = Hash::make($request->password);
        $siswa->save();

        return redirect()->back()->with('success', 'Berhasil');
    }
    public function profil_save_pict(Request $request)
    {
        $file = $request->file('profil_pict');

        $nama_file = time() . "_" . $file->getClientOriginalName();

        $destinationPath = public_path('/profile_pict');
        $img = Image::make($file->getRealPath());
        $img->resize(500, 500, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath . '/' . $nama_file);

        // $tujuan_upload = 'profile_pict';
        // $file->move($tujuan_upload,$nama_file);

        \File::delete(public_path('profile_pict/' . Auth::user()->profile_pict));

        Siswa::where('id', Auth::user()->id)->update([
            'profile_pict' => $nama_file,
        ]);

        return redirect()->back()->with('success', 'Berhasil');
    }
}

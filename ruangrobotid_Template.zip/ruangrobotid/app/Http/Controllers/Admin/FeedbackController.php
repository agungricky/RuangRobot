<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DataTables;
use DB;

class FeedbackController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = DB::table('feedback_siswa')->orderBy('id', 'DESC')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('nama_kelas', function ($row) {
                    return DB::table('kelas')->where('id', $row->id_kelas)->first('nama_kelas')->nama_kelas;
                })
                ->addColumn('nama_siswa', function ($row) {
                    return DB::table('siswa')->where('id', $row->id_siswa)->first('nama_siswa')->nama_siswa;
                })
                ->addColumn('stars', function ($row) {
                    $a = '';
                    for ($i = 0; $i < $row->stars; $i++) {
                        $a .= '<i class="fas fa-star text-warning"></i>';
                    }
                    return $a;
                })
                ->addColumn('aksi', function ($row) {
                    return '<a href="' . route('admin.feedbackdelete', $row->id) . '" class="btn btn-danger delete"><i class="fas fa-trash"></i></a>';
                })
                ->rawColumns(['stars', 'aksi'])
                ->make(true);
        }
        return view('admin.feedback');
    }
    public function delete($id)
    {
        DB::table('feedback_siswa')->where('id', $id)->delete();

        return redirect()->back()->with('success', 'Berhasil Menghapus Feedback');
    }
}

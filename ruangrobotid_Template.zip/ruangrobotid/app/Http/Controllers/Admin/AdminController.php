<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin as Admins;
use App\Kelas;
use App\Siswa;
use App\Pengajar;
use Auth;
use Hash;
use DB;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * show dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pembayaran = DB::table('pembayaran')->orderBy('id', 'DESC')->limit(10)->get();
        $sesi_kelas = DB::table('sesi_kelas')->whereNotNull('materi')->orderBy('id', 'DESC')->limit(10)->get();
        $kelas = Kelas::count();
        $siswa = Siswa::count();
        $pengajar = Pengajar::count();
        $pembayarana = DB::table('pembayaran')->where('status', 'Pembayaran Diterima')->sum('jumlah');

        $pembayaran_report = DB::table('pembayaran')->selectRaw('year(tanggal_bayar) year, monthname(tanggal_bayar) month, sum(jumlah) data')
            ->where('status', 'Pembayaran Diterima')
            ->groupBy('year', 'month')
            ->orderBy('year', 'desc')
            ->get();
        return view('admin.dashboard', compact('pembayaran', 'sesi_kelas', 'kelas', 'siswa', 'pembayarana', 'pembayaran_report', 'pengajar'));
    }
    public function profil()
    {
        return view('admin.editprofil');
    }
    public function profil_save(Request $request)
    {
        $id = Auth::user()->id;
        $admin = Admins::find($id);
        $admin->nama = $request->nama;
        $admin->username = $request->username;
        if ($request->password != '')
            $admin->password = Hash::make($request->password);
        $admin->save();

        return redirect()->back()->with('success', 'Berhasil');
        // $flight->save();
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\ProgramBelajar;
use Illuminate\Http\Request;
use DataTables;

class ProgramBelajarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = ProgramBelajar::get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('nama_program_belajar', function ($row) {
                    return '<span class="font-weight-bold font-italic">' . $row->nama_program_belajar . '</span>';
                })
                // ->addColumn('deskripsi', function($row){
                //     return substr($row->deskripsi,0,15).'...';
                // })
                ->addColumn('level', function ($row) {
                    if ($row->level == 'mudah') {
                        return '<span class="badge badge-success">' . $row->level . '</span>';
                    }
                    if ($row->level == 'sedang') {
                        return '<span class="badge badge-warning text-dark">' . $row->level . '</span>';
                    }
                    if ($row->level == 'sulit') {
                        return '<span class="badge badge-danger">' . $row->level . '</span>';
                    }
                })
                ->addColumn('harga', function ($row) {
                    return '<span class="font-weight-bold text-success">Rp. ' . number_format($row->harga) . '</span>';
                })
                ->addColumn('poin', function ($row) {
                    return '<span class="text-success text-small font-weight-bold">M +' . $row->mekanik . ' <div class="bullet"></div> E +' . $row->elektronik . ' <div class="bullet"></div> P +' . $row->pemrograman . '</span>';
                })
                ->addColumn('action', function ($row) {
                    $btn = '<a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-sm btn-primary btn-icon-text edit"><i class="fas fa-edit btn-icon-append"></i> Edit</a>';
                    $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Delete" class="btn btn btn-sm btn-danger btn-icon-text delete"><i class="fas fa-trash btn-icon-prepend"></i> Delete</a>';
                    return $btn;
                })
                ->rawColumns(['action', 'level', 'poin', 'nama_program_belajar', 'harga'])
                ->make(true);
        }

        return view('admin.programbelajar');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = $request->id;
        ProgramBelajar::updateOrCreate(
            ['id' => $id],
            ['nama_program_belajar' => $request->program_belajar, 'harga' => $request->harga, 'deskripsi' => $request->deskripsi, 'level' => $request->level, 'mekanik' => $request->mekanik, 'elektronik' => $request->elektronik, 'pemrograman' => $request->pemrograman]
        );
        return response()->json(['success' => 'Berhasil menyimpan Program Belajar.']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProgramBelajar  $programBelajar
     * @return \Illuminate\Http\Response
     */
    public function show(ProgramBelajar $programBelajar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProgramBelajar  $programBelajar
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ProgramBelajar = ProgramBelajar::find($id);
        return response()->json($ProgramBelajar);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProgramBelajar  $programBelajar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBelajar $programBelajar)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProgramBelajar  $programBelajar
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kelas = ProgramBelajar::find($id)->delete();
        return response()->json(['success' => 'Berhasil menghapus data program belajar.']);
    }
}

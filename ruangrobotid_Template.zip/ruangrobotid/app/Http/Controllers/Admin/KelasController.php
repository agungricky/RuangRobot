<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Kelas;
use App\Pengajar;
use App\Siswa;
use App\ProgramBelajar;
use App\SelectedClass;
use App\SesiKelas;
use App\SiswaYangAbsen;

use Illuminate\Http\Request;
use DB;
use DataTables;
use Illuminate\Support\Facades\Hash;
use Ramsey\Uuid\Uuid;
use App\Helpers\Ceksiswa;
use PDF;
use GDText\Box;
use GDText\Color;
use ZipArchive;

class KelasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $slot_kelas;
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Kelas::with('pengajar', 'program_belajar')->orderBy('id', 'DESC')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('jenis_kelas', function ($row) {
                    if ($row->jenis_kelas == 'Kelas Privat') {
                        return '<span class="badge badge-danger">' . $row->jenis_kelas . '</span>';
                    } elseif ($row->jenis_kelas == 'Kelas Regular') {
                        return '<span class="badge badge-primary">' . $row->jenis_kelas . '</span>';
                    } elseif ($row->jenis_kelas == 'Kelas Ekskul') {
                        return '<span class="badge badge-warning text-dark">' . $row->jenis_kelas . '</span>';
                    } elseif ($row->jenis_kelas == 'Kelas Lomba') {
                        return '<span class="badge badge-info">' . $row->jenis_kelas . '</span>';
                    } elseif ($row->jenis_kelas == 'Kelas Online') {
                        return '<span class="badge badge-success">' . $row->jenis_kelas . '</span>';
                    } elseif ($row->jenis_kelas == 'Kelas Mandiri') {
                        return '<span class="badge text-light" style="background:#9b59b6;">' . $row->jenis_kelas . '</span>';
                    }
                })
                ->addColumn('created_at', function ($row) {
                    return date('d-m-Y', strtotime($row->created_at));
                })
                ->addColumn('status', function ($row) {
                    return $row->status == '1' ? '<span class="badge badge-success">Complete</span>' : '<span class="badge badge-primary">On Going</span>';
                })
                ->addColumn('selengkapnya', function ($row) {
                    $btn = '<a href="' . route('admin.listsiswa', $row->id) . '" class="btn btn-sm btn-success btn-icon-text"><i class="fas fa-arrow-right btn-icon-append"></i> Selengkapnya</a> ';
                    return $btn;
                })
                ->addColumn('action', function ($row) {
                    $btn = ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Delete" class="btn btn btn-sm btn-danger btn-icon-text delete"><i class="fas fa-trash btn-icon-prepend"></i> Hapus</a>';
                    return $btn;
                })
                ->rawColumns(['action', 'selengkapnya', 'jenis_kelas', 'status'])
                ->make(true);
        }
        $data['pengajar'] = Pengajar::get();
        $data['program_belajar'] = ProgramBelajar::get();
        return view('admin.kelas', $data);
    }
    public function selesaikelas($id, $status)
    {
        if ($status == '1') {
            Kelas::where('id', $id)->update(['status' => '0']);
        } else {
            Kelas::where('id', $id)->update(['status' => '1']);
        }
        return redirect()->back()->with('success', 'Berhasil mengupdate status');
    }
    function tanggal_indo($tanggal)
    {
        $bulan = array(
            1 =>   'Januari',
            'Februari',
            'Maret',
            'April',
            'Mei',
            'Juni',
            'Juli',
            'Agustus',
            'September',
            'Oktober',
            'November',
            'Desember'
        );
        $split = explode('-', $tanggal);
        return $split[2] . ' ' . $bulan[(int)$split[1]] . ' ' . $split[0];
    }
    public function generatecert($id)
    {
        \File::deleteDirectory(public_path('compresedcert'));
        \File::makeDirectory(public_path('compresedcert'), 0777, true, true);
        $list = SelectedClass::where(['id_kelas' => $id, 'selesai' => 'true'])->get();
        foreach ($list as $key => $value) {
            $siswa = Siswa::where('id', $value->id_siswa)->first();
            self::sertifikat($id, $siswa->id, $siswa->nama_siswa);
        }
        $public_dir = public_path();
        $kelasz = Kelas::where('id', $id)->first('nama_kelas')->nama_kelas;
        $zipFileName = 'Sertifikat-' . str_replace('/','_',$kelasz) . '.zip';
        $zip = new ZipArchive;
        if ($zip->open($public_dir . '/compresedcert/' . $zipFileName, ZipArchive::CREATE) === TRUE) {
            $options = array('remove_all_path' => TRUE);
            $zip->addGlob(base_path() . '/public/cert/*.jpeg', GLOB_BRACE, $options);
            $zip->close();
        }
        $headers = array(
            'Content-Type' => 'application/octet-stream',
        );
        $filetopath = $public_dir . '/compresedcert/' . $zipFileName;
        \File::deleteDirectory(public_path('cert'));
        if (file_exists($filetopath)) {
            return response()->download($filetopath, $zipFileName, $headers);
        }
    }
    public function sertifikat($kelas_id, $id_siswa, $nama_siswa)
    {
        $kelas = Kelas::with('pengajar', 'program_belajar')->where('id', $kelas_id)->first();
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();


        $im = imagecreatefromjpeg('assets/certificate.jpg');


        // set bulan
        $array_bln  = array(1 => "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII");
        $bln        = $array_bln[date('n')];
        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(24);
        $box->setBox(680, 240, 450, 120);
        // $box->enableDebug();
        $box->setTextAlign('center', 'top');
        $box->draw("No : " . $kelas_id . "/RUANGROBOT/" . $bln . "/" . date('Y') . "\n\nDIBERIKAN KEPADA :");


        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(55);
        $box->setBox(500, 330, 800, 160);
        $box->setTextAlign('center', 'center');
        $box->draw(ucwords($nama_siswa));

        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(24);
        $box->setBox(500, 490, 800, 200);
        $box->setTextAlign('center', 'top');
        $box->draw('Telah menyelesaikan pelatihan ' . strtoupper($kelas->program_belajar->nama_program_belajar) . ' di Ruang Robot yang dilaksanakan pada tanggal ' . $this->tanggal_indo(date('Y-m-d', strtotime($slot_kelas->first()->tanggal))) . ' - ' . $this->tanggal_indo(date('Y-m-d', strtotime($slot_kelas->last()->tanggal))) . ' dengan predikat');

        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        // $box->setFontSize(35);
        // $box->setStrokeColor(new Color(0, 0, 0)); // Set stroke color
        // $box->setStrokeSize(.6); // Stroke size in pixels
        // $box->setBox(750, 580, 300, 70);
        $box->setFontSize(25);
        $box->setStrokeColor(new Color(0, 0, 0)); // Set stroke color
        $box->setStrokeSize(.6); // Stroke size in pixels
        $box->setBox(750, 610, 300, 70);
        $box->setTextAlign('center', 'center');
        $box->draw((Ceksiswa::get_grade($id_siswa, $kelas_id) == 'A') ? 'SANGAT BAIK' : 'BAIK');

        $box = new Box($im);
        $box->setFontFace('assets/arial.ttf');
        $box->setFontColor(new Color(0, 0, 0));
        $box->setFontSize(25);
        $box->setBox(880, 690, 400, 460);
        $box->setTextAlign('center', 'top');
        $box->draw("Kediri, " . $this->tanggal_indo(date('Y-m-d', strtotime($slot_kelas->last()->tanggal))) . "\nRuang Robot\n\n\n\n\nJulian Sahertian, S.Pd., M.T.");

        // header("Content-type: image/jpeg");
        // header("Cache-Control: no-store, no-cache");
        $nama_ser = $kelas_id . "_" . $kelas->nama_kelas . '_' . ucwords($nama_siswa) . '.jpeg';
        // header('Content-Disposition: attachment; filename="'.$nama_ser.'.jpeg"');
        // imagejpeg($im);
        $path = public_path('cert');
        if (!\File::isDirectory($path)) {
            \File::makeDirectory($path, 0777, true, true);
        }
        imagejpeg($im, base_path() . '/public/cert/' . str_replace('/','_',$nama_ser));
        imagedestroy($im);
    }
    public function listsiswasesiajax($id)
    {
        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();
        $this->slot_kelas = $slot_kelas->count();

        return Datatables::of($slot_kelas)
            ->addIndexColumn()
            ->addColumn('materi', function ($row) {
                return $row->materi != '' ? $row->materi : '-';
            })
            ->addColumn('jam', function ($row) {
                return $row->jamm . ' - ' . $row->jams;
            })
            ->addColumn('hari_tanggal', function ($row) {
                $daftar_hari = array(
                    'Sunday' => 'Minggu',
                    'Monday' => 'Senin',
                    'Tuesday' => 'Selasa',
                    'Wednesday' => 'Rabu',
                    'Thursday' => 'Kamis',
                    'Friday' => 'Jumat',
                    'Saturday' => 'Sabtu'
                );
                $namahari = date('l', strtotime($row->tanggal));
                return $daftar_hari[$namahari] . ', ' . date('d-m-Y', strtotime($row->tanggal));
            })
            ->addColumn('selengkapnya', function ($row) {
                $daftar_hari = array(
                    'Sunday' => 'Minggu',
                    'Monday' => 'Senin',
                    'Tuesday' => 'Selasa',
                    'Wednesday' => 'Rabu',
                    'Thursday' => 'Kamis',
                    'Friday' => 'Jumat',
                    'Saturday' => 'Sabtu'
                );
                $namahari = date('l', strtotime($row->tanggal));
                // if (Ceksiswa::isdate_terlewat(date('d-m-Y', strtotime($row->tanggal)), $row->materi) == 'Tidak Absen') {
                //     return '<a href="javascript:void(0)" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Pengajar Tidak Absen"><i class="fa fa-times"></i> Tidak Absen</a>';
                // } else
                $status = ["Silahkan Absen Sekarang", "Tidak Absen"];
                if (Ceksiswa::isdate_terlewat(date('d-m-Y', strtotime($row->tanggal)), $row->materi) == 'Silahkan Absen Sekarang') {
                    return '<a href="javascript:void(0)" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="top" title="Pengajar Hari Ini Waktunya Absen"><i class="fa fa-times"></i> Waktunya Absen</a>';
                } else if (Ceksiswa::isdate_terlewat(date('d-m-Y', strtotime($row->tanggal)), $row->materi) == 'Sudah Absen' || Ceksiswa::isdate_terlewat(date('d-m-Y', strtotime($row->tanggal)), $row->materi) == 'Sudah Absen hi') {
                    return '<a class="btn btn-success btn-sm detailbutton" href="javascript:void(0)" data-materi="' . $row->materi . '" data-hari="' . $daftar_hari[$namahari] . '" data-id="' . $row->id . '" data-tanggal="' . date('d-m-Y', strtotime($row->tanggal)) . '"><i class="fas fa-arrow-right"></i> Selengkapnya</a>';
                } else {
                    return '<a href="javascript:void(0)" class="btn btn-sm btn-warning  text-dark" data-toggle="tooltip" data-placement="top" title="Pengajar Belum Waktunya Absen"><i class="fa fa-times"></i> Belum Waktunya</a>';
                }
            })
            ->addColumn('action', function ($row) {
                $js = "return confirm('Yakin Ingin Menghapus Sesi?')";
                $btn = '<a class="btn btn-primary btn-sm edit_tanggal_btn" href="javascript:void(0)" data-id="' . $row->id . '" data-tanggal="' . date('Y-m-d', strtotime($row->tanggal)) . '" data-jamm="' . $row->jamm . '" data-jams="' . $row->jams . '"><i class="fas fa-edit"></i> Edit</a>';
                if ($this->slot_kelas > 1) {
                    $btn .= '<a class="btn btn-danger btn-sm deleteslot" href="' . route('admin.deletesesikelas', $row->id) . '"><i class="fas fa-trash"></i> Hapus</a>';
                }

                return $btn;
            })
            ->rawColumns(['action', 'selengkapnya'])
            ->make(true);
    }
    public function listsiswa($id)
    {
        $arr = SelectedClass::where('id_kelas', $id)->pluck('id_siswa')->toArray();
        $siswa = Siswa::whereIn('id', $arr)->get();

        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id);

        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();

        $pengajar = Pengajar::get();
        $program_belajar = ProgramBelajar::get();
        return view('admin.listsiswa', ['kls' => $kelas, 'id' => $id, 'siswa' => $siswa, 'slot_kelas' => $slot_kelas, 'pengajar' => $pengajar, 'program_belajar' => $program_belajar]);
    }
    public function savesiswaselected(Request $request)
    {
        $kelas = $request->id_kelas;
        foreach ($request->id as $r) {
            if (SelectedClass::where('id_siswa', $r)->where('id_kelas', $kelas)->exists()) {
                // skip
            } else {
                SelectedClass::insert(
                    ['id_siswa' => $r, 'id_kelas' => $kelas]
                );
            }
        }
        return redirect()->back()->with('success', 'Berhasil menambahkan siswa');
    }
    public function deletesiswa(Request $request)
    {
        $siswa = SelectedClass::where(['id_siswa' => $request->id_siswa, 'id_kelas' => $request->id_kelas])->first();
        DB::table('pembayaran')->where('id_selected_class', $siswa->id)->delete();
        $siswa = SelectedClass::where(['id_siswa' => $request->id_siswa, 'id_kelas' => $request->id_kelas])->delete();
        return redirect()->back()->with('success', 'Berhasil menghapus siswa');
    }
    public function deletesesikelas($id)
    {
        $slot_kelas = SesiKelas::find($id)->delete();
        $siswa_yang_absen = SiswaYangAbsen::where('id_sesi', $id)->delete();
        return redirect()->back()->with('success', 'Berhasil menghapus sesi');
    }
    public function saveeditedsesi(Request $request)
    {
        $sesi = SesiKelas::where('id', $request->id_sesinya)->update(['tanggal' => $request->tanggal_sesinya, 'jamm' => $request->jamm, 'jams' => $request->jams]);
        return response()->json(['success' => 'Berhasil menyimpan kelas.']);
    }
    public function savetambahedsesi(Request $request)
    {
        $sesii = SesiKelas::create([
            'id_kelas' => $request->id_kelas,
            'tanggal' => $request->tanggal_sesinya,
            'jamm' => $request->jamm,
            'jams' => $request->jams,
        ]);
        return response()->json(['success' => 'Berhasil menyimpan kelas.']);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = $request->id;
        $uuid = Uuid::uuid1();
        Kelas::updateOrCreate(
            ['id' => $id],
            [
                'uuid'  => $uuid,
                'program_belajar_id' => $request->program_belajar_id,
                'pengajar_id' => $request->pengajar_id,
                'nama_kelas' => $request->nama_kelas,
                'jenis_kelas' => $request->jenis_kelas,
                'gajipeg' => $request->gaji
            ]
        );

        foreach ($request->tanggal as $key => $tanggal) {
            $slot_kelas = DB::table('sesi_kelas')->insert([
                'id_kelas' => $uuid,
                'tanggal'  => $tanggal,
                'jamm'  => $request->get('jamm')[$key],
                'jams'  => $request->get('jams')[$key]
            ]);
        }
        return response()->json(['success' => 'Berhasil menyimpan kelas.']);
    }
    public function storetwo(Request $request)
    {
        $id = $request->id_kelas;
        Kelas::updateOrCreate(
            ['id' => $id],
            [
                'program_belajar_id' => $request->program_belajar_id,
                'pengajar_id' => $request->pengajar_id,
                'nama_kelas' => $request->nama_kelas,
                'jenis_kelas' => $request->jenis_kelas,
                'gajipeg' => $request->gaji
            ]
        );
        return response()->json(['success' => 'Berhasil menyimpan kelas.']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function show(Kelas $kelas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kelas = Kelas::find($id);
        return response()->json($kelas);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kelas $kelas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $uuid = Kelas::find($id)->first('uuid')->uuid;
        DB::table('sesi_kelas')->where('id_kelas', $uuid)->delete();
        $kelas = Kelas::find($id)->delete();
        if (DB::table('selected_class')->where('id_kelas', $id)->count() > 0) {
            $id_selected = DB::table('selected_class')->where('id_kelas', $id)->pluck('id');
            DB::table('pembayaran')->whereIn('id_selected_class', $id_selected)->delete();
            DB::table('selected_class')->where('id_kelas', $id)->delete();
        }
        return response()->json(['success' => 'Berhasil menghapus data kelas.']);
    }

    public function detailsesi(Request $request)
    {
        // $slot_kelas = DB::table('sesi_kelas')->find($request->id);
        $arr = SelectedClass::where('id_kelas', $request->id_kelas)->pluck('id_siswa')->toArray();
        $siswa = Siswa::whereIn('id', $arr)->get();

        $sesihadir = DB::table('siswa_yang_absen')->where('id_sesi', $request->id)->pluck('id_siswa')->toArray();

        foreach ($siswa as $hadir) {
            if (in_array($hadir->id, $sesihadir)) {
                echo '
                <label class="labela">
                <div class="card mb-2" style="box-shadow:none !important;border-left:4px solid #28a745!important">
                <div class="card-body" style="background: #f8f8f8;padding:15px;">
                    <span class="font-weight-bold"><i style="color: #28a745!important" class="fas fa-check-circle mr-3"></i>' . $hadir->nama_siswa . '</span>
                </div>
                </div>
                </label>';
            } else {
                echo '
                <label class="labela">
                <div class="card mb-2" style="box-shadow:none !important;border-left:4px solid #dc3545!important">
                <div class="card-body" style="background: #f8f8f8;padding:15px;">
                    <span class="font-weight-bold"><i style="color: #dc3545!important" class="fas fa-times-circle mr-3"></i>' . $hadir->nama_siswa . '</span>
                </div>
                </div>
                </label>';
            }
        }
    }
    public function selesaisiswa(Request $request)
    {

        $kls = Kelas::where('id', $request->id_kelas)->with('program_belajar')->first();

        if ($request->nilai == 'A') {
            $mekanik     = $kls->program_belajar->mekanik;
            $elektronik  = $kls->program_belajar->elektronik;
            $pemrograman = $kls->program_belajar->pemrograman;
        } else {
            $mekanik     = $kls->program_belajar->mekanik - 1;
            $elektronik  = $kls->program_belajar->elektronik - 1;
            $pemrograman = $kls->program_belajar->pemrograman - 1;
        }

        SelectedClass::where([
            'id_siswa' => $request->id_siswa,
            'id_kelas' => $request->id_kelas
        ])
            ->update([
                'selesai' => true,
                'nilai' => $request->nilai,
                'mekanik' => $mekanik,
                'elektronik' => $elektronik,
                'pemrograman' => $pemrograman,
            ]);
    }
    public function cetak_pdf_report($id)
    {
        $arr = SelectedClass::where('id_kelas', $id)->pluck('id_siswa')->toArray();
        $siswa = Siswa::whereIn('id', $arr)->get();

        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();

        $pdf = PDF::loadview('pdfjurnal', compact('kelas', 'slot_kelas', 'id', 'siswa'));
        return $pdf->stream();
        // return $pdf->download('Jurnal-'.date('dmY').'.pdf');
    }
    public function upload_banner(Request $request)
    {
        $file = $request->file('banner_gambar');
        $nama_file = time() . "_" . $file->getClientOriginalName();
        $tujuan_upload = 'banner';
        $file->move($tujuan_upload, $nama_file);
        Kelas::where('id', $request->id_kelas)->update(['banner' => $nama_file]);
        return redirect()->back();
    }
}

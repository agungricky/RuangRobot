<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\SelectedClass;
use App\Kelas;
use App\Siswa;
use App\Helpers\Ceksiswa;
use DataTables;
use DB;
use PDF;

class PembayaranController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $selected = Kelas::pluck('id')->toArray();
            $data = SelectedClass::with('kelas.program_belajar')->whereIn('id_kelas', $selected)->orderBy('id_kelas', 'desc')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('pembayaran', function ($row) {
                    $list_bayar = DB::table('pembayaran')->where(['id_selected_class' => $row->id])->get();
                    
                    return 'Total Biaya : '.number_format($row->kelas->program_belajar->harga).'<br>Biaya Lunas : '.number_format($list_bayar->where('status','Pembayaran Diterima')->sum('jumlah') ?? 0);
                })
                ->addColumn('nama_kelas', function ($row) {
                    return Ceksiswa::get_detail_pembayaran($row->id, 'nama');
                })
                ->addColumn('harga', function ($row) {
                    return 'Rp. ' . number_format(Ceksiswa::get_detail_pembayaran($row->id, 'pb'));
                })
                ->addColumn('nama_siswa', function ($row) {
                    return Ceksiswa::get_detail_pembayaran($row->id, 'nama_siswa') ?? "";
                })
                ->addColumn('lunas', function ($row) {
                    if ($row->sudahbayar == 0) {
                        return '<span class="badge badge-warning text-dark">Belum Lunas</span>';
                    } else {
                        return '<span class="badge badge-success">Lunas</span>';
                    }
                })
                ->addColumn('action', function ($row) {
                    $btn = '<a href="' . route('admin.detail-pembayaran', $row->id) . '" class="btn btn-sm btn-primary">Selengkapnya</a>';
                    return $btn;
                })
                ->rawColumns(['action', 'pembayaran', 'nama_kelas', 'harga', 'nama_siswa', 'lunas'])
                ->make(true);
        }
        return view('admin.pembayaran');
    }
    public function detail_pembayaran($id)
    {
        $kelas_bayar = DB::table('selected_class')->where(['id' => $id])->first();
        $list_bayar = DB::table('pembayaran')->where(['id_selected_class' => $id])->get();
        $kelas = Kelas::with('program_belajar')->find($kelas_bayar->id_kelas);
        $siswa = Siswa::whereId($kelas_bayar->id_siswa)->first();
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get('tanggal')->toArray();

        $totalComentarios = count($slot_kelas);
        $mitadComentarios = (int)ceil($totalComentarios / 2);
        $slice = array_slice($slot_kelas, $mitadComentarios - 1, 1);

        $slice = $slice[0]->tanggal ?? '';
        return view('admin.pembayaran-detail', compact('kelas_bayar', 'list_bayar', 'kelas', 'siswa', 'slot_kelas', 'id', 'slice'));
    }
    public function update_pembayaran(Request $request)
    {
        $list_bayar = DB::table('pembayaran')->where(['id' => $request->id])->update([
            'status' => $request->status
        ]);
        return redirect()->back();
    }
    public function delete_pembayaran($id)
    {
        $list_bayar = DB::table('pembayaran')->where(['id' => $id])->delete();
        return redirect()->back();
    }
    public function update_lunas(Request $request)
    {
        if (isset($request->lunas)) {
            $sudahbayar = '1';
        } else {
            $sudahbayar = '0';
        }
        $kelas_bayar = DB::table('selected_class')->where('id', $request->id)->update(['sudahbayar' => $sudahbayar]);
        // dd($kelas_bayar);
        return redirect()->back();
    }
    public function pembayaran_manual_admin(Request $request)
    {
        DB::table('pembayaran')->insert([
            'invoice' => '',
            'manual' => 'Y',
            'jumlah' => $request->jumlah,
            'bukti_pembayaran' => '',
            'status' => 'Pembayaran Diterima',
            'id_selected_class' => $request->id_selected_class,
            'tanggal_bayar' => $request->tanggal_bayar,
        ]);

        return redirect()->back();
    }
    public function cetak_pdf($id, $tempo)
    {
        $kelas_bayar = DB::table('selected_class')->where(['id' => $id])->first();
        $list_bayar = DB::table('pembayaran')->where(['id_selected_class' => $id])->get();
        $kelas = Kelas::with('program_belajar')->find($kelas_bayar->id_kelas);
        $siswa = Siswa::whereId($kelas_bayar->id_siswa)->first();
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get('tanggal')->toArray();

        $pdf = PDF::loadview('pdf', compact('kelas_bayar', 'list_bayar', 'kelas', 'siswa', 'slot_kelas', 'id', 'tempo'));
        // return $pdf->stream();
        return $pdf->download('INV-' . date('dmY') . '-' . $siswa->id . $kelas->id . '.pdf');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Kelas;
use App\Pengajar;
use App\SesiKelas;

class GajiController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index()
    {
        $data = Kelas::with('pengajar', 'program_belajar')->orderBy('id', 'DESC')->get();

        $dataperpengajar = [];
        foreach (Pengajar::all() as $pengajar) {
            $gajis = 0;

            $id_kelas = Kelas::where(['pengajar_id' => $pengajar->id, 'sudah_digaji' => '0'])->get();
            foreach ($id_kelas as $key => $value) {
                $gaji = SesiKelas::where('id_kelas', $value->uuid)->where('materi', '!=', 'NULL')->count();
                $gajis = $gajis + $gaji * $value->gajipeg;
            }
            array_push($dataperpengajar, [$pengajar->nama_pengajar => $gajis]);
        }
        return view('admin.gajipengajar', compact('data', 'dataperpengajar'));
    }
    public function indexaction(Request $request)
    {
        Kelas::find($request->id_kelas)->update(['sudah_digaji' => 1]);
        return redirect()->back();
    }
}

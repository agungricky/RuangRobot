<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Siswa;
use App\SelectedClass;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\Hash;
use App\Helpers\CekSiswa;
use Illuminate\Support\Str;

class SiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Siswa::orderBy('id', 'DESC')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('nama_siswa', function ($row) {
                    return '<a class="font-weight-bold" href="' . route('profileall', ['siswa', $row->id]) . '">' . $row->nama_siswa . '</a>';
                })
                ->addColumn('mekanika', function ($row) {
                    return '+' . Ceksiswa::check_point($row->id, 'mekanik') . ' Poin';
                })
                ->addColumn('elektronika', function ($row) {
                    return '+' . Ceksiswa::check_point($row->id, 'elektronik') . ' Poin';
                })
                ->addColumn('pemrogramana', function ($row) {
                    return '+' . Ceksiswa::check_point($row->id, 'pemrograman') . ' Poin';
                })
                ->addColumn('action', function ($row) {
                    $btn = ' <a href="' . route('admin.siswaedit', ['id' => $row->id]) . '" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Edit" class="btn btn-sm btn-primary btn-icon-text"><i class="fas fa-edit btn-icon-append"></i></a>';
                    $btn .= ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Delete" class="btn btn btn-sm btn-danger btn-icon-text delete"><i class="fas fa-trash btn-icon-prepend"></i></a>';
                    return $btn;
                })
                ->rawColumns(['action', 'elektronika', 'mekanika', 'pemrogramana', 'nama_siswa'])
                ->make(true);
        }
        return view('admin.siswa');
    }

    public function buatbaru()
    {
        return view('admin.addsiswa');
    }
    public function cekusernameada(Request $request)
    {
        $cek = Siswa::where('username', $request->username)->count();
        return ($cek > 0) ? 'ada' : 'tidak';
    }
    public function buatbaruaksi(Request $request)
    {
        $size = count(collect($request)->get('nama'));
        for ($i = 0; $i < $size; $i++) {
            if (!empty($request->get('nama')[$i])) {
                // $password = Str::random(4);
                $password = 'ruangrobot';
                Siswa::Create([
                    'nama_siswa' => $request->get('nama')[$i],
                    'notlep' => $request->get('notlep')[$i],
                    'sekolah' => $request->get('sekolah')[$i],
                    'tgl_lahir' => $request->get('tgllahir')[$i],
                    'alamat' => $request->get('alamat')[$i],
                    'username' => $request->get('username')[$i],
                    'password_real' => $password,
                    'password' => Hash::make($password)
                ]);
            }
        }
        return redirect()->route('siswa.index');
    }

    public function editsiswa($id)
    {
        $siswa = Siswa::find($id);
        return view('admin.editsiswa', ['siswa' => $siswa, 'id' => $id]);
    }
    public function editsiswaaksi(Request $request)
    {
        $real_passwd = Hash::make($request->get('password'));
        $id = $request->id;
        Siswa::updateOrCreate(
            ['id' => $id],
            [
                'nama_siswa' => $request->get('nama'),
                'notlep' => $request->get('notlep'),
                'sekolah' => $request->get('sekolah'),
                'tgl_lahir' => $request->get('tgl_lahir'),
                'alamat' => $request->get('alamat'),
                'username' => $request->get('username'),
                'password_real' => $request->get('password'),
                'password' => $real_passwd,
            ]
        );
        return redirect()->route('siswa.index');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function show(Siswa $siswa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function edit(Siswa $siswa)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Siswa $siswa)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $siswa = Siswa::find($id)->delete();
        return response()->json(['success' => 'Berhasil menghapus data siswa.']);
    }
}

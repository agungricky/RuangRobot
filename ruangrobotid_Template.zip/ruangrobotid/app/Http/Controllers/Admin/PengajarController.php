<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Pengajar;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class PengajarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Pengajar::get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('nama_pengajar', function ($row) {
                    return '<a class="font-weight-bold" href="' . route('profileall', ['pengajar', $row->id]) . '">' . $row->nama_pengajar . '</a>';
                })
                ->addColumn('action', function ($row) {
                    $btn = ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Edit" class="btn btn btn-sm btn-primary btn-icon-text edit"><i class="fas fa-edit btn-icon-prepend"></i> Edit</a>';
                    $btn .= ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Delete" class="btn btn btn-sm btn-danger btn-icon-text delete"><i class="fas fa-trash btn-icon-prepend"></i> Delete</a>';
                    return $btn;
                })
                ->rawColumns(['action', 'nama_pengajar'])
                ->make(true);
        }

        return view('admin.pengajar');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = $request->id;
        if ($request->id == '') {
            $validator = Validator::make($request->all(), [
                'username' => 'required|unique:pengajar',
            ]);
            if ($validator->fails()) {
                return abort(500, 'ada');
            }
            // $real_passwd =Str::random(4);
            $real_passwd = 'ruangrobot';
            Pengajar::updateOrCreate(
                ['id' => $id],
                ['nama_pengajar' => $request->nama_pengajar, 'alamat' => $request->alamat, 'notlep' => $request->notlep, 'username' => $request->username, 'password' => Hash::make($real_passwd), 'real_passwd' => $real_passwd]
            );
            return response()->json(['success' => 'Berhasil menyimpan pengajar.']);
        } else {
            Pengajar::updateOrCreate(
                ['id' => $id],
                ['nama_pengajar' => $request->nama_pengajar, 'alamat' => $request->alamat, 'notlep' => $request->notlep, 'username' => $request->username, 'password' => Hash::make($request->password), 'real_passwd' => $request->password]
            );
            return response()->json(['success' => 'Berhasil menyimpan pengajar.']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function show(Pengajar $pengajar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pengajar = Pengajar::find($id);
        return response()->json($pengajar);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pengajar $pengajar)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pengajar = Pengajar::find($id)->delete();
        return response()->json(['success' => 'Berhasil menghapus data pengajar.']);
    }
}

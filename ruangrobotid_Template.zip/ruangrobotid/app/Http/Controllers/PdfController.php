<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PdfController extends Controller
{
    public function createPDF(){
        $view = view('pdf', [
            'content' => 'Lorem ipsum dolor'
            ]);
            $html = $view->render();
            
            $pdf = new TCPDF();
            $pdf::AddPage();
            $pdf::writeHTML($html);
            
            $pdf_path = env('STORAGE_PATH') . '/pdf_name.pdf';
            $pdf_out = $pdf::Output($pdf_path, 'F');
    }
}

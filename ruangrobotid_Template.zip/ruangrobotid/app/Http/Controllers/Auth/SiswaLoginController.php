<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Route;
use App\Models\Siswa;
use Illuminate\Support\Facades\Hash;

class SiswaLoginController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest:siswa', ['except' => ['logout']]);
    }
    public function register()
    {
        return view('siswa.siswa_register');
    }
    public function registeraction(Request $request)
    {
        $this->validate($request, [
            'nama_siswa'   => ['required', 'string', 'max:100'],
            'alamat'   => ['required', 'string', 'max:255'],
            'notlep'   => ['required', 'string', 'max:30'],
            'email'   => ['required', 'email', 'max:255', 'unique:siswa'],
            'password' => ['required', 'string', 'min:5', 'confirmed'],
        ]);
        Siswa::create([
            'nama_siswa' => $request->nama_siswa,
            'alamat'    => $request->alamat,
            'notlep'    => $request->notlep,
            'email'     => $request->email,
            'password'  => Hash::make($request->password),
            'poin'      => 0,
        ]);
        return redirect()->route('siswa.login');
    }
    public function login()
    {
        return view('auth.login');
    }
    public function loginaction(Request $request)
    {
        $this->validate($request, [
            'email'   => 'required',
            'password' => 'required|min:1'
        ]);
        if (Auth::guard('siswa')->attempt(['username' => $request->email, 'password' => $request->password], $request->remember)) {
            // if successful, then redirect to their intended location
            return redirect()->intended(route('siswa.dashboard'));
        }
        // if unsuccessful, then redirect back to the login with the form data
        return redirect()->back()->withInput($request->only('email', 'remember'));
    }
    public function logout()
    {
        Auth::guard('siswa')->logout();
        return redirect()->route('login');
    }
}

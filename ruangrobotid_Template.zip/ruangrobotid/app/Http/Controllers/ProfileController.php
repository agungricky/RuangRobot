<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Siswa;
use App\Pengajar;
use App\SelectedClass;
use App\Kelas;

use Auth;

class ProfileController extends Controller
{
    public function index($users, $id)
    {
        if ($users == 'siswa') {
            $user = SelectedClass::where(['id_siswa' => $id, 'selesai' => true])->get();
            $mekanik = $elektronik = $pemrograman = 0;
            foreach ($user as $poin) {
                $mekanik      += $poin->mekanik;
                $pemrograman  += $poin->pemrograman;
                $elektronik  += $poin->elektronik;
            }
            $max = max($mekanik, $elektronik, $pemrograman);

            $siswa = Siswa::whereId($id)->first();
            $selected = SelectedClass::where(['id_siswa' => $id, 'selesai' => true])->pluck('id_kelas')->toArray();
            $kelas = Kelas::with('pengajar', 'program_belajar')->whereIn('id', $selected)->get();
            return view('profile', compact('siswa', 'kelas', 'id', 'mekanik', 'elektronik', 'pemrograman', 'max', 'users'));
        } elseif ($users == 'pengajar') {
            $kelas = Kelas::with('program_belajar')->where('pengajar_id', $id)->get();
            $mekanik = $elektronik = $pemrograman = 0;
            foreach ($kelas as $poin) {
                $mekanik      += $poin->program_belajar->mekanik;
                $pemrograman  += $poin->program_belajar->pemrograman;
                $elektronik  += $poin->program_belajar->elektronik;
            }
            $max = max($mekanik, $elektronik, $pemrograman);
            $pengajar = Pengajar::where('id', $id)->first();
            return view('profile', compact('pengajar', 'kelas', 'id', 'mekanik', 'elektronik', 'pemrograman', 'max', 'users'));
        }
    }
}

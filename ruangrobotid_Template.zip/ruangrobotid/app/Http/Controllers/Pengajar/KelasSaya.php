<?php

namespace App\Http\Controllers\Pengajar;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Kelas;
use App\Pengajar;
use App\Siswa;
use App\ProgramBelajar;
use App\SelectedClass;
use App\SesiKelas;
use DataTables;
use DB;
use Hash;
use PDF;
use Image;

class KelasSaya extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:pengajar');
    }
    public function index(Request $request)
    {
        $idpengajar = Auth::user()->id;
        $kelas2 = Kelas::where(['pengajar_id' => $idpengajar, 'status' => '1'])->with('pengajar', 'program_belajar')->orderBy('id', 'DESC')->get();
        $kelas = Kelas::where(['pengajar_id' => $idpengajar, 'status' => '0'])->with('pengajar', 'program_belajar')->orderBy('id', 'DESC')->get();
        return view('pengajar.kelassaya', compact('kelas', 'kelas2'));
    }
    public function getsiswa(Request $request)
    {
        if ($request->ajax()) {
            $arr = SelectedClass::where('id_kelas', $request->id)->pluck('id_siswa')->toArray();
            $data = Siswa::whereIn('id', $arr)->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $btn = ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-sm btn-gradient-info btn-icon-text edit"><i class="mdi mdi-file-check btn-icon-append"></i> Edit</a>';
                    $btn .= ' <a href="javascript:void(0)" data-toggle="tooltip" data-id="' . $row->id . '" data-original-title="Delete" class="btn btn btn-sm btn-gradient-danger btn-icon-text delete"><i class="mdi mdi-delete-forever btn-icon-prepend"></i> Delete</a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
    }
    public function detail($id)
    {
        $arr = SelectedClass::where('id_kelas', $id)->pluck('id_siswa')->toArray();
        $siswa = Siswa::whereIn('id', $arr)->get();
        // $siswa = Siswa::whereIn('id', $arr)->paginate(4);

        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();
        $cek_absen = DB::table('sesi_kelas_sementara')->where('id', $kelas->id)->get();
        if ($cek_absen->count() > 0) {
            $materi = $cek_absen->first()->materi;
            $id_siswa_yang_absen_sementara = [];
            
            if(is_countable(json_decode($cek_absen->first()->absen))){
            foreach (json_decode($cek_absen->first()->absen) as $ids) {
                $idsnya = explode(',', $ids);
                $id_siswa_yang_absen_sementara = array_merge($id_siswa_yang_absen_sementara, [$idsnya[0]]);
            }}
        } else {
            $materi = '';
            $id_siswa_yang_absen_sementara = [];
        }
        return view('pengajar.detailkelas', ['kelas' => $kelas, 'slot_kelas' => $slot_kelas, 'siswa' => $siswa, 'id' => $id, 'materi' => $materi, 'id_siswa_yang_absen_sementara' => $id_siswa_yang_absen_sementara]);
    }
    public function saveabsen(Request $request)
    {
        if ($request->opsi_simpan == 'simpan_sementara') {
            if (DB::table('sesi_kelas_sementara')->where(['id' => $request->id_kelas])->count() > 0) {
                DB::table('sesi_kelas_sementara')->where(['id' => $request->id_kelas])->update([
                    'materi' => $request->materi != '' ? $request->materi : '',
                    'absen'  => json_encode($request->id),
                ]);
            } else {
                DB::table('sesi_kelas_sementara')->where(['id' => $request->id_kelas])->insert([
                    'id' => $request->id_kelas,
                    'materi' => ($request->materi == '') ? '' : $request->materi,
                    'absen'  => json_encode($request->id),
                ]);
            }
        } else if ($request->opsi_simpan == 'submit_final') {
            DB::table('sesi_kelas_sementara')->where(['id' => $request->id_kelas])->delete();
            $affected = DB::table('sesi_kelas')
                ->where('id', $request->idsesi)
                ->update(['materi' => ($request->materi == '') ? '' : $request->materi]);

            foreach ($request->id as $absen_siswa) {
                $absen_siswa = explode(',', $absen_siswa);
                DB::table('siswa_yang_absen')->insert([
                    'id_sesi'   => $request->idsesi,
                    'uuid'   => $request->uuid,
                    'id_siswa'  => $absen_siswa[0],
                    'nama'      => $absen_siswa[1],
                    'sekolah'   => $absen_siswa[2]
                ]);
            }
        }
        return redirect()->back();
    }
    public function progres($id_siswa, $id_kelas, $nama_siswa)
    {
        $slot_kelas = DB::table('siswa_yang_absen')->where('id_kelas', $id_kelas)->get();

        return view('pengajar.progress', ['slot_kelas' => $slot_kelas, 'id_siswa' => $id_siswa, 'nama_siswa' => $nama_siswa]);
    }
    public function detailsesi(Request $request)
    {
        // $slot_kelas = DB::table('sesi_kelas')->find($request->id);
        $arr = SelectedClass::where('id_kelas', $request->id_kelas)->pluck('id_siswa')->toArray();
        $siswa = Siswa::whereIn('id', $arr)->get();

        $sesihadir = DB::table('siswa_yang_absen')->where('id_sesi', $request->id)->pluck('id_siswa')->toArray();

        foreach ($siswa as $hadir) {
            if (in_array($hadir->id, $sesihadir)) {
                echo '
                <label class="labela">
                <div class="card mb-2" style="box-shadow:none !important;border-left:4px solid #28a745!important">
                <div class="card-body" style="background: #f8f8f8;padding:15px;">
                    <span class="font-weight-bold"><i style="color: #28a745!important" class="fas fa-check-circle mr-3"></i>' . $hadir->nama_siswa . '</span>
                </div>
                </div>
                </label>';
            } else {
                echo '
                <label class="labela">
                <div class="card mb-2" style="box-shadow:none !important;border-left:4px solid #dc3545!important">
                <div class="card-body" style="background: #f8f8f8;padding:15px;">
                    <span class="font-weight-bold"><i style="color: #dc3545!important" class="fas fa-times-circle mr-3"></i>' . $hadir->nama_siswa . '</span>
                </div>
                </div>
                </label>';
            }
        }
    }
    public function selesaikelasnyaaa(Request $request)
    {
        Kelas::where('id', $request->id_kelas)->update(['status' => '1']);

        return redirect()->back()->with('success', 'Berhasil');
    }
    public function selesaisiswa(Request $request)
    {

        $kls = Kelas::where('id', $request->id_kelas)->with('program_belajar')->first();

        if ($request->nilai == 'A') {
            $mekanik     = $kls->program_belajar->mekanik;
            $elektronik  = $kls->program_belajar->elektronik;
            $pemrograman = $kls->program_belajar->pemrograman;
        } elseif ($request->nilai == 'B') {
            $mekanik     = $kls->program_belajar->mekanik <= 0 ? 0 : $kls->program_belajar->mekanik - 1;
            $elektronik  = $kls->program_belajar->elektronik <= 0 ? 0 : $kls->program_belajar->elektronik - 1;
            $pemrograman = $kls->program_belajar->pemrograman <= 0 ? 0 : $kls->program_belajar->pemrograman - 1;
        } elseif ($request->nilai == 'C') {
            $mekanik     = 0;
            $elektronik  = 0;
            $pemrograman = 0;
        }

        SelectedClass::where([
            'id_siswa' => $request->id_siswa,
            'id_kelas' => $request->id_kelas
        ])
            ->update([
                'selesai' => true,
                'nilai' => $request->nilai,
                'mekanik' => $mekanik,
                'elektronik' => $elektronik,
                'pemrograman' => $pemrograman,
            ]);
    }
    public function gajisaya()
    {
        $idpengajar = Auth::user()->id;
        $gajisaya = Kelas::where('pengajar_id', $idpengajar)->with('pengajar')->get();

        $gajis = 0;
        $id_kelas = Kelas::where(['pengajar_id' => $idpengajar, 'sudah_digaji' => '0'])->get();
        foreach ($id_kelas as $key => $value) {
            $gaji = SesiKelas::where('id_kelas', $value->uuid)->where('materi', '!=', 'NULL')->count();
            $gajis = $gajis + $gaji * $value->gajipeg;
        }
        return view('pengajar.gajisaya', compact('gajisaya', 'gajis'));
    }
    public function gajisayacetak($id)
    {
        $kelas = Kelas::with('pengajar', 'program_belajar')->find($id);
        $slot_kelas = DB::table('sesi_kelas')->where('id_kelas', $kelas->uuid)->orderBy('tanggal')->get();

        $pdf = PDF::loadview('pdfgaji', compact('kelas', 'slot_kelas', 'id'));
        // return $pdf->stream();
        return $pdf->download('Struk Gaji-' . date('dmY') . '.pdf');
    }

    public function profil()
    {
        return view('pengajar.profil');
    }
    public function profil_save(Request $request)
    {
        $id = Auth::user()->id;
        $pengajar = Pengajar::find($id);
        $pengajar->nama_pengajar = $request->nama_pengajar;
        $pengajar->alamat = $request->alamat;
        $pengajar->notlep = $request->notlep;
        $pengajar->bio = $request->bio;
        // $pengajar->username = $request->username;
        if ($request->password != '') {
            $pengajar->real_passwd = $request->password;
            $pengajar->password = Hash::make($request->password);
        }
        $pengajar->save();

        return redirect()->back()->with('success', 'Berhasil');
    }
    public function profil_save_pict(Request $request)
    {
        $file = $request->file('profil_pict');

        $nama_file = time() . "_" . $file->getClientOriginalName();

        $destinationPath = './profile_pict';
        $img = Image::make($file->getRealPath());
        $img->resize(500, 500, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath . '/' . $nama_file);
        // $tujuan_upload = 'profile_pict';
        // $file->move($tujuan_upload,$nama_file);

        \File::delete('./profile_pict/' . Auth::user()->profile_pict);

        Pengajar::where('id', Auth::user()->id)->update([
            'profile_pict' => $nama_file,
        ]);

        return redirect()->back()->with('success', 'Berhasil');
    }
}

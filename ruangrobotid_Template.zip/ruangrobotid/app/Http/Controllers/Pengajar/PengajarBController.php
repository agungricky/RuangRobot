<?php

namespace App\Http\Controllers\Pengajar;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Kelas;
use Auth;
use DB;
use Carbon\Carbon;

class PengajarBController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:pengajar');
    }
    public function index()
    {
        $kelas = Kelas::with('program_belajar')->where('pengajar_id', Auth::user()->id)->get();
        $mekanik = $elektronik = $pemrograman = 0;
        foreach ($kelas as $poin) {
            $mekanik      += $poin->program_belajar->mekanik;
            $pemrograman  += $poin->program_belajar->pemrograman;
            $elektronik  += $poin->program_belajar->elektronik;
        }
        $max = max($mekanik, $elektronik, $pemrograman);



        return view('pengajar.dashboard', compact('mekanik', 'elektronik', 'pemrograman', 'max', 'kelas'));
    }
    public function jadwal()
    {
        $perhari = DB::table('sesi_kelas')
            ->join('kelas', 'sesi_kelas.id_kelas', '=', 'sesi_kelas.id_kelas')
            ->select(
                DB::raw('date(sesi_kelas.tanggal) tanggal'),
                'kelas.nama_kelas',
                'sesi_kelas.jamm',
                'sesi_kelas.jams',
            )
            ->where('kelas.pengajar_id', Auth::user()->id)
            ->orderBy('tanggal', 'DESC')
            ->get()
            ->groupBy('tanggal');

        return view('pengajar.jadwal', compact('perhari'));
    }
}

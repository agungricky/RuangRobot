<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SelectedClass extends Model
{
    protected $table = 'selected_class';
    protected $fillable = ['id_kelas','id_siswa','selesai','nilai','mekanik','elektronik','pemrograman','sudahbayar'];
    public $timestamps = false;
    
    public function kelas()
    {
        return $this->belongsTo('App\Kelas','id_kelas');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    protected $table = 'siswa';
    protected $fillable = ['nama_siswa','bio','notlep','sekolah','tgl_lahir','alamat','username','password_real','password'];
}

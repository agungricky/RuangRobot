<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;

class Kelas extends Model
{
    // use SoftDeletes;

    protected $table = 'kelas';
    // protected $dates = ['deleted_at'];
    protected $fillable = ['uuid','program_belajar_id','pengajar_id','nama_kelas','jenis_kelas','gajipeg','sudah_digaji','banner','created_at'];
    public function pengajar()
    {
        return $this->belongsTo('App\Pengajar');
    }
    public function program_belajar()
    {
        return $this->belongsTo('App\ProgramBelajar');
    }
}

<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('landing');
})->name('home');


Route::get('reset', function () {
    Artisan::call('route:clear');
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
});

Route::get('profile/{user}/{id}', 'ProfileController@index')->name('profileall');

// Route::get('login', function(){
//     return view('auth.login');
// })->name('base.login');
Route::prefix('siswa')->group(function () {
    // Route::get('register', 'Auth\SiswaLoginController@register')->name('siswa.register');
    // Route::post('register', 'Auth\SiswaLoginController@registeraction')->name('siswa.register.submit');
    // Route::get('login', 'Auth\SiswaLoginController@login')->name('siswa.login');
    Route::get('/', 'Auth\SiswaLoginController@login')->name('siswa.login');
    Route::post('login', 'Auth\SiswaLoginController@loginaction')->name('siswa.login.submit');
    Route::get('logout/', 'Auth\SiswaLoginController@logout')->name('siswa.logout');

    Route::get('dashboard', 'Siswa\SiswaController@index')->name('siswa.dashboard');
    Route::get('jadwal', 'Siswa\SiswaController@jadwal')->name('siswa.jadwal');
    Route::get('/daftar-kelas', 'Siswa\SiswaController@daftarkelas')->name('siswa.daftarkelas');
    Route::get('/detail-kelas/{id}', 'Siswa\SiswaController@detail_kelas')->name('siswa.detailkelas');
    Route::post('/feedback-save', 'Siswa\SiswaController@feedback_save')->name('siswa.feedback_save');
    Route::get('pembayaran', 'Siswa\SiswaController@pembayaran')->name('siswa.pembayaran');
    Route::get('/upload-bukti/{id_selected}', 'Siswa\SiswaController@upload_bukti')->name('siswa.uploadbukti');
    Route::post('/upload-bukti', 'Siswa\SiswaController@upload_bukti_action')->name('siswa.uploadbuktiaction');
    Route::get('cetak-pdf/{id}/{tempo}', 'Siswa\SiswaController@cetak_pdf')->name('siswa.pembayaran_cetak');

    Route::get('/sertifikat', 'Siswa\SiswaController@list_sertifikat')->name('siswa.sertifikat');
    Route::get('/cetak-sertifikat/{id_kelas}', 'Siswa\SiswaController@sertifikat')->name('siswa.sertifikat_cetak');
    Route::get('/profil-saya', 'Siswa\SiswaController@profil')->name('siswa.profil');
    Route::post('/profil-saya', 'Siswa\SiswaController@profil_save')->name('siswa.profil_save');
    Route::post('/profil-saya-pict', 'Siswa\SiswaController@profil_save_pict')->name('siswa.profil_save_pict');
});


Route::prefix('admin')->group(function () {
    Route::get('/', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
    Route::post('/', 'Auth\AdminLoginController@login')->name('admin.login.submit');
    Route::get('logout/', 'Auth\AdminLoginController@logout')->name('admin.logout');

    Route::get('dashboard', 'Admin\AdminController@index')->name('admin.dashboard');
    Route::resource('programbelajar', 'Admin\ProgramBelajarController');
    Route::resource('kelas', 'Admin\KelasController');
    Route::post('kelas/storetwo', 'Admin\KelasController@storetwo')->name('kelas.storetwo');
    Route::get('kelas/list-siswa/{id}', 'Admin\KelasController@listsiswa')->name('admin.listsiswa');
    Route::post('kelas/list-siswa', 'Admin\KelasController@savesiswaselected')->name('admin.listsiswasave');
    Route::get('getdetailsesi', 'Admin\KelasController@detailsesi')->name('admin.getdetailsesi');
    Route::post('selesaisiswa', 'Admin\KelasController@selesaisiswa')->name('admin.selesaisiswa');
    Route::get('selesaikelas/{idkelas}/{status}', 'Admin\KelasController@selesaikelas')->name('admin.selesaikelas');

    Route::get('generatecert/{idkelas}', 'Admin\KelasController@generatecert')->name('admin.generatecert');

    Route::post('kelas/list-siswa-delete', 'Admin\KelasController@deletesiswa')->name('admin.listsiswadelete');
    Route::get('kelas/sesi-kelas-delete/{id}', 'Admin\KelasController@deletesesikelas')->name('admin.deletesesikelas');
    Route::post('kelas/list-siswa-edit-sesi', 'Admin\KelasController@saveeditedsesi')->name('admin.saveeditedsesi');
    Route::post('kelas/list-siswa-tambah-sesi', 'Admin\KelasController@savetambahedsesi')->name('admin.savetambahedsesi');
    Route::get('kelas/listsiswasesiajax/{id}', 'Admin\KelasController@listsiswasesiajax')->name('admin.listsiswasesiajax');
    Route::post('/ganti-banner', 'Admin\KelasController@upload_banner')->name('admin.uploadbanneraction');
    Route::get('/feedback-siswa', 'Admin\FeedbackController@index')->name('admin.feedback');
    Route::get('/feedback-siswa/{id}', 'Admin\FeedbackController@delete')->name('admin.feedbackdelete');


    Route::resource('pengajar', 'Admin\PengajarController');

    Route::get('siswa/cekusername', 'Admin\SiswaController@cekusernameada')->name('admin.cekusernameada');
    Route::get('siswa/tambah-siswa', 'Admin\SiswaController@buatbaru')->name('admin.siswacreate');
    Route::post('siswa/tambah-siswa', 'Admin\SiswaController@buatbaruaksi')->name('admin.siswacreateaksi');
    Route::get('siswa/edit-siswa/{id}', 'Admin\SiswaController@editsiswa')->name('admin.siswaedit');
    Route::post('siswa/edit-siswa', 'Admin\SiswaController@editsiswaaksi')->name('admin.editsiswaaksi');
    Route::resource('siswa', 'Admin\SiswaController');

    Route::get('pembayaran', 'Admin\PembayaranController@index')->name('admin.pembayaran');
    Route::get('detail-pembayaran/{id}', 'Admin\PembayaranController@detail_pembayaran')->name('admin.detail-pembayaran');
    Route::post('update-pembayaran', 'Admin\PembayaranController@update_pembayaran')->name('admin.update-pembayaran');
    Route::get('delete-pembayaran/{id}', 'Admin\PembayaranController@delete_pembayaran')->name('admin.delete-pembayaran');
    Route::post('pembayaran-manual-admin', 'Admin\PembayaranController@pembayaran_manual_admin')->name('admin.pembayaran_manual_admin');
    Route::get('cetak-pdf/{id}/{tempo}', 'Admin\PembayaranController@cetak_pdf')->name('admin.pembayaran_cetak');
    Route::get('cetak-pdf-report/{id}', 'Admin\KelasController@cetak_pdf_report')->name('admin.report_cetak');

    Route::post('update-lunas', 'Admin\PembayaranController@update_lunas')->name('admin.update-lunas');

    Route::get('gaji-pengajar', 'Admin\GajiController@index')->name('admin.gajipengajar');
    Route::post('gaji-pengajar', 'Admin\GajiController@indexaction')->name('admin.gajipengajaraction');

    Route::get('/profil', 'Admin\AdminController@profil')->name('admin.editprofil');
    Route::post('/profil', 'Admin\AdminController@profil_save')->name('admin.editprofilsave');
});

Route::prefix('pengajar')->group(function () {
    Route::get('/', 'Auth\TeacherLoginController@showLoginForm')->name('pengajar.login');
    Route::post('/', 'Auth\TeacherLoginController@login')->name('pengajar.login.submit');
    Route::get('logout/', 'Auth\TeacherLoginController@logout')->name('pengajar.logout');
    Route::get('dashboard', 'Pengajar\PengajarBController@index')->name('pengajar.dashboard');
    Route::resource('kelassaya', 'Pengajar\KelasSaya');
    Route::get('kelassaya/detail/{id}', 'Pengajar\KelasSaya@detail')->name('pengajar.detailkelas');
    Route::get('kelassaya/getsiswa/{id}', 'Pengajar\KelasSaya@getsiswa')->name('pengajar.ajaxgetsiswa');
    Route::post('kelassaya/saveabsen', 'Pengajar\KelasSaya@saveabsen')->name('pengajar.saveabsen');
    Route::post('kelassaya/selesaikelasnyaaa', 'Pengajar\KelasSaya@selesaikelasnyaaa')->name('pengajar.selesaikelasnyaaa');
    Route::get('progressiswa/{id_siswa}/{id_kelas}/{nama_siswa}', 'Pengajar\KelasSaya@progres')->name('pengajar.progressiswa');
    Route::get('jadwal', 'Pengajar\PengajarBController@jadwal')->name('pengajar.jadwal');

    Route::get('getdetailsesi', 'Pengajar\KelasSaya@detailsesi')->name('pengajar.getdetailsesi');
    Route::post('selesaisiswa', 'Pengajar\KelasSaya@selesaisiswa')->name('pengajar.selesaisiswa');

    Route::get('gaji-saya', 'Pengajar\KelasSaya@gajisaya')->name('pengajar.gajisaya');
    Route::get('gaji-saya-cetak/{id}', 'Pengajar\KelasSaya@gajisayacetak')->name('pengajar.gajisayacetak');
    Route::get('profil-saya', 'Pengajar\KelasSaya@profil')->name('pengajar.profil');
    Route::post('profil-saya', 'Pengajar\KelasSaya@profil_save')->name('pengajar.profil_save');
    Route::post('profil-saya-pict', 'Pengajar\KelasSaya@profil_save_pict')->name('pengajar.profil_save_pict');
});

Auth::routes();

// Route::get('/', 'PdfController@createPDF')->name('home');
